# Case Study 14: Race Condition Demonstration in xv6

This project now runs the demonstration inside the xv6 RISC-V operating system. Two xv6 processes enter a test-only kernel free list from two QEMU harts. The unlocked operation reproduces a duplicate page allocation; xv6's `acquire()` and `release()` spinlock protects the same read-and-update sequence in the corrected run.

## Run it

In Windows PowerShell, start the existing Ubuntu WSL distribution:

```powershell
wsl -d Ubuntu-24.04
```

From the Ubuntu shell, build and boot the xv6 image with two harts:

```bash
cd "/mnt/c/Users/HP/Documents/OS record/OS CASE STUDY/case_study_14_rebuild/xv6-riscv"
make clean
make -j4 DETFLAGS= qemu CPUS=2
```

At the xv6 `$` prompt, run:

```text
racetest
```

Exit QEMU's nographic console with **Ctrl+A**, then **X**.

See `GUIDE_Run_and_Explain_Case_Study_14.md` for setup, code walkthrough, expected output, and troubleshooting. The captured QEMU result is in `evidence/xv6_qemu_run.txt`.

## Code locations

- `xv6-riscv/kernel/racecheck.c` - kernel-side controlled race, xv6 spinlock fix, and invariant audit
- `xv6-riscv/user/racetest.c` - xv6 user program that starts and joins the two worker processes
- `xv6-riscv/kernel/kalloc.c` - xv6's production physical-page allocator and its `kmem.lock`
- `xv6-riscv/kernel/syscall.c`, `kernel/syscall.h`, `user/usys.pl`, and `user/user.h` - syscall wiring for the test

The demonstration uses a separate test-only free list in the xv6 kernel so the unsafe case cannot corrupt the live allocator. It runs on xv6, uses xv6's real spinlock implementation, and mirrors the `kmem.freelist` pop pattern in `kernel/kalloc.c`. It does not remove the production allocator's lock.

The Office report and presentation under `output/` were left unchanged during this code correction. Treat the xv6 source and captured run evidence in this folder as the current implementation.
