
user/_racetest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <run_case>:

enum { UNLOCKED = 0, SPINLOCK = 1, WORKERS = 2 };

static int
run_case(int mode)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	1800                	addi	s0,sp,48
   a:	84aa                	mv	s1,a0
  if (raceinit(mode) < 0) {
   c:	440000ef          	jal	44c <raceinit>
  10:	06054463          	bltz	a0,78 <run_case+0x78>
    printf("racetest: could not initialize the kernel test\n");
    return -1;
  }

  printf("racetest: starting %s case with two xv6 processes\n",
  14:	00001597          	auipc	a1,0x1
  18:	99c58593          	addi	a1,a1,-1636 # 9b0 <malloc+0x110>
  1c:	e489                	bnez	s1,26 <run_case+0x26>
  1e:	00001597          	auipc	a1,0x1
  22:	98258593          	addi	a1,a1,-1662 # 9a0 <malloc+0x100>
  26:	00001517          	auipc	a0,0x1
  2a:	9ca50513          	addi	a0,a0,-1590 # 9f0 <malloc+0x150>
  2e:	7be000ef          	jal	7ec <printf>
         mode == UNLOCKED ? "unlocked" : "spinlock");

  int children = 0;
  for (int worker = 0; worker < WORKERS; worker++) {
    int pid = fork();
  32:	36a000ef          	jal	39c <fork>
    if (pid < 0) {
  36:	04054963          	bltz	a0,88 <run_case+0x88>
      printf("racetest: fork failed\n");
      return -1;
    }
    if (pid == 0) {
  3a:	c125                	beqz	a0,9a <run_case+0x9a>
    int pid = fork();
  3c:	360000ef          	jal	39c <fork>
    if (pid < 0) {
  40:	04054463          	bltz	a0,88 <run_case+0x88>
    if (pid == 0) {
  44:	c931                	beqz	a0,98 <run_case+0x98>
    children++;
  }

  for (int i = 0; i < children; i++) {
    int status;
    if (wait(&status) < 0 || status != 0) {
  46:	fdc40513          	addi	a0,s0,-36
  4a:	362000ef          	jal	3ac <wait>
  4e:	04054c63          	bltz	a0,a6 <run_case+0xa6>
  52:	fdc42783          	lw	a5,-36(s0)
  56:	eba1                	bnez	a5,a6 <run_case+0xa6>
  58:	fdc40513          	addi	a0,s0,-36
  5c:	350000ef          	jal	3ac <wait>
  60:	04054363          	bltz	a0,a6 <run_case+0xa6>
  64:	fdc42783          	lw	a5,-36(s0)
  68:	ef9d                	bnez	a5,a6 <run_case+0xa6>
      printf("racetest: worker process failed\n");
      return -1;
    }
  }

  return racereport();
  6a:	3f2000ef          	jal	45c <racereport>
}
  6e:	70a2                	ld	ra,40(sp)
  70:	7402                	ld	s0,32(sp)
  72:	64e2                	ld	s1,24(sp)
  74:	6145                	addi	sp,sp,48
  76:	8082                	ret
    printf("racetest: could not initialize the kernel test\n");
  78:	00001517          	auipc	a0,0x1
  7c:	94850513          	addi	a0,a0,-1720 # 9c0 <malloc+0x120>
  80:	76c000ef          	jal	7ec <printf>
    return -1;
  84:	557d                	li	a0,-1
  86:	b7e5                	j	6e <run_case+0x6e>
      printf("racetest: fork failed\n");
  88:	00001517          	auipc	a0,0x1
  8c:	9a050513          	addi	a0,a0,-1632 # a28 <malloc+0x188>
  90:	75c000ef          	jal	7ec <printf>
      return -1;
  94:	557d                	li	a0,-1
  96:	bfe1                	j	6e <run_case+0x6e>
  98:	4505                	li	a0,1
      int result = raceworker(worker);
  9a:	3ba000ef          	jal	454 <raceworker>
      exit(result == 0 ? 0 : 1);
  9e:	00a03533          	snez	a0,a0
  a2:	302000ef          	jal	3a4 <exit>
      printf("racetest: worker process failed\n");
  a6:	00001517          	auipc	a0,0x1
  aa:	99a50513          	addi	a0,a0,-1638 # a40 <malloc+0x1a0>
  ae:	73e000ef          	jal	7ec <printf>
      return -1;
  b2:	557d                	li	a0,-1
  b4:	bf6d                	j	6e <run_case+0x6e>

00000000000000b6 <main>:

int
main(void)
{
  b6:	1101                	addi	sp,sp,-32
  b8:	ec06                	sd	ra,24(sp)
  ba:	e822                	sd	s0,16(sp)
  bc:	e426                	sd	s1,8(sp)
  be:	1000                	addi	s0,sp,32
  printf("Case Study 14: xv6 kernel free-list race demonstration\n");
  c0:	00001517          	auipc	a0,0x1
  c4:	9a850513          	addi	a0,a0,-1624 # a68 <malloc+0x1c8>
  c8:	724000ef          	jal	7ec <printf>
  printf("Run xv6 with two harts (make qemu CPUS=2).\n");
  cc:	00001517          	auipc	a0,0x1
  d0:	9d450513          	addi	a0,a0,-1580 # aa0 <malloc+0x200>
  d4:	718000ef          	jal	7ec <printf>

  int unsafe_ok = run_case(UNLOCKED) == 0;
  d8:	4501                	li	a0,0
  da:	f27ff0ef          	jal	0 <run_case>
  de:	84aa                	mv	s1,a0
  int safe_ok = run_case(SPINLOCK) == 0;
  e0:	4505                	li	a0,1
  e2:	f1fff0ef          	jal	0 <run_case>

  if (unsafe_ok && safe_ok) {
  e6:	8cc9                	or	s1,s1,a0
  e8:	2481                	sext.w	s1,s1
  ea:	c891                	beqz	s1,fe <main+0x48>
    printf("XV6 RACE DEMO: PASS (inconsistency reproduced; spinlock fixed it)\n");
    exit(0);
  }

  printf("XV6 RACE DEMO: FAIL (see kernel report above)\n");
  ec:	00001517          	auipc	a0,0x1
  f0:	a2c50513          	addi	a0,a0,-1492 # b18 <malloc+0x278>
  f4:	6f8000ef          	jal	7ec <printf>
  exit(1);
  f8:	4505                	li	a0,1
  fa:	2aa000ef          	jal	3a4 <exit>
    printf("XV6 RACE DEMO: PASS (inconsistency reproduced; spinlock fixed it)\n");
  fe:	00001517          	auipc	a0,0x1
 102:	9d250513          	addi	a0,a0,-1582 # ad0 <malloc+0x230>
 106:	6e6000ef          	jal	7ec <printf>
    exit(0);
 10a:	4501                	li	a0,0
 10c:	298000ef          	jal	3a4 <exit>

0000000000000110 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 110:	1141                	addi	sp,sp,-16
 112:	e406                	sd	ra,8(sp)
 114:	e022                	sd	s0,0(sp)
 116:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 118:	f9fff0ef          	jal	b6 <main>
  exit(r);
 11c:	288000ef          	jal	3a4 <exit>

0000000000000120 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 120:	1141                	addi	sp,sp,-16
 122:	e422                	sd	s0,8(sp)
 124:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 126:	87aa                	mv	a5,a0
 128:	0585                	addi	a1,a1,1
 12a:	0785                	addi	a5,a5,1
 12c:	fff5c703          	lbu	a4,-1(a1)
 130:	fee78fa3          	sb	a4,-1(a5)
 134:	fb75                	bnez	a4,128 <strcpy+0x8>
    ;
  return os;
}
 136:	6422                	ld	s0,8(sp)
 138:	0141                	addi	sp,sp,16
 13a:	8082                	ret

000000000000013c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 13c:	1141                	addi	sp,sp,-16
 13e:	e422                	sd	s0,8(sp)
 140:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 142:	00054783          	lbu	a5,0(a0)
 146:	cb91                	beqz	a5,15a <strcmp+0x1e>
 148:	0005c703          	lbu	a4,0(a1)
 14c:	00f71763          	bne	a4,a5,15a <strcmp+0x1e>
    p++, q++;
 150:	0505                	addi	a0,a0,1
 152:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 154:	00054783          	lbu	a5,0(a0)
 158:	fbe5                	bnez	a5,148 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 15a:	0005c503          	lbu	a0,0(a1)
}
 15e:	40a7853b          	subw	a0,a5,a0
 162:	6422                	ld	s0,8(sp)
 164:	0141                	addi	sp,sp,16
 166:	8082                	ret

0000000000000168 <strlen>:

uint
strlen(const char *s)
{
 168:	1141                	addi	sp,sp,-16
 16a:	e422                	sd	s0,8(sp)
 16c:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 16e:	00054783          	lbu	a5,0(a0)
 172:	cf91                	beqz	a5,18e <strlen+0x26>
 174:	0505                	addi	a0,a0,1
 176:	87aa                	mv	a5,a0
 178:	86be                	mv	a3,a5
 17a:	0785                	addi	a5,a5,1
 17c:	fff7c703          	lbu	a4,-1(a5)
 180:	ff65                	bnez	a4,178 <strlen+0x10>
 182:	40a6853b          	subw	a0,a3,a0
 186:	2505                	addiw	a0,a0,1
    ;
  return n;
}
 188:	6422                	ld	s0,8(sp)
 18a:	0141                	addi	sp,sp,16
 18c:	8082                	ret
  for (n = 0; s[n]; n++)
 18e:	4501                	li	a0,0
 190:	bfe5                	j	188 <strlen+0x20>

0000000000000192 <memset>:

void *
memset(void *dst, int c, uint n)
{
 192:	1141                	addi	sp,sp,-16
 194:	e422                	sd	s0,8(sp)
 196:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 198:	ca19                	beqz	a2,1ae <memset+0x1c>
 19a:	87aa                	mv	a5,a0
 19c:	1602                	slli	a2,a2,0x20
 19e:	9201                	srli	a2,a2,0x20
 1a0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 1a4:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 1a8:	0785                	addi	a5,a5,1
 1aa:	fee79de3          	bne	a5,a4,1a4 <memset+0x12>
  }
  return dst;
}
 1ae:	6422                	ld	s0,8(sp)
 1b0:	0141                	addi	sp,sp,16
 1b2:	8082                	ret

00000000000001b4 <strchr>:

char *
strchr(const char *s, char c)
{
 1b4:	1141                	addi	sp,sp,-16
 1b6:	e422                	sd	s0,8(sp)
 1b8:	0800                	addi	s0,sp,16
  for (; *s; s++)
 1ba:	00054783          	lbu	a5,0(a0)
 1be:	cb99                	beqz	a5,1d4 <strchr+0x20>
    if (*s == c)
 1c0:	00f58763          	beq	a1,a5,1ce <strchr+0x1a>
  for (; *s; s++)
 1c4:	0505                	addi	a0,a0,1
 1c6:	00054783          	lbu	a5,0(a0)
 1ca:	fbfd                	bnez	a5,1c0 <strchr+0xc>
      return (char *)s;
  return 0;
 1cc:	4501                	li	a0,0
}
 1ce:	6422                	ld	s0,8(sp)
 1d0:	0141                	addi	sp,sp,16
 1d2:	8082                	ret
  return 0;
 1d4:	4501                	li	a0,0
 1d6:	bfe5                	j	1ce <strchr+0x1a>

00000000000001d8 <gets>:

char *
gets(char *buf, int max)
{
 1d8:	711d                	addi	sp,sp,-96
 1da:	ec86                	sd	ra,88(sp)
 1dc:	e8a2                	sd	s0,80(sp)
 1de:	e4a6                	sd	s1,72(sp)
 1e0:	e0ca                	sd	s2,64(sp)
 1e2:	fc4e                	sd	s3,56(sp)
 1e4:	f852                	sd	s4,48(sp)
 1e6:	f456                	sd	s5,40(sp)
 1e8:	f05a                	sd	s6,32(sp)
 1ea:	ec5e                	sd	s7,24(sp)
 1ec:	1080                	addi	s0,sp,96
 1ee:	8baa                	mv	s7,a0
 1f0:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 1f2:	892a                	mv	s2,a0
 1f4:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if (cc < 1)
      break;
    buf[i++] = c;
    if (c == '\n' || c == '\r')
 1f6:	4aa9                	li	s5,10
 1f8:	4b35                	li	s6,13
  for (i = 0; i + 1 < max;) {
 1fa:	89a6                	mv	s3,s1
 1fc:	2485                	addiw	s1,s1,1
 1fe:	0344d663          	bge	s1,s4,22a <gets+0x52>
    cc = read(0, &c, 1);
 202:	4605                	li	a2,1
 204:	faf40593          	addi	a1,s0,-81
 208:	4501                	li	a0,0
 20a:	1b2000ef          	jal	3bc <read>
    if (cc < 1)
 20e:	00a05e63          	blez	a0,22a <gets+0x52>
    buf[i++] = c;
 212:	faf44783          	lbu	a5,-81(s0)
 216:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 21a:	01578763          	beq	a5,s5,228 <gets+0x50>
 21e:	0905                	addi	s2,s2,1
 220:	fd679de3          	bne	a5,s6,1fa <gets+0x22>
    buf[i++] = c;
 224:	89a6                	mv	s3,s1
 226:	a011                	j	22a <gets+0x52>
 228:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 22a:	99de                	add	s3,s3,s7
 22c:	00098023          	sb	zero,0(s3)
  return buf;
}
 230:	855e                	mv	a0,s7
 232:	60e6                	ld	ra,88(sp)
 234:	6446                	ld	s0,80(sp)
 236:	64a6                	ld	s1,72(sp)
 238:	6906                	ld	s2,64(sp)
 23a:	79e2                	ld	s3,56(sp)
 23c:	7a42                	ld	s4,48(sp)
 23e:	7aa2                	ld	s5,40(sp)
 240:	7b02                	ld	s6,32(sp)
 242:	6be2                	ld	s7,24(sp)
 244:	6125                	addi	sp,sp,96
 246:	8082                	ret

0000000000000248 <stat>:

int
stat(const char *n, struct stat *st)
{
 248:	1101                	addi	sp,sp,-32
 24a:	ec06                	sd	ra,24(sp)
 24c:	e822                	sd	s0,16(sp)
 24e:	e04a                	sd	s2,0(sp)
 250:	1000                	addi	s0,sp,32
 252:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 254:	4581                	li	a1,0
 256:	18e000ef          	jal	3e4 <open>
  if (fd < 0)
 25a:	02054263          	bltz	a0,27e <stat+0x36>
 25e:	e426                	sd	s1,8(sp)
 260:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 262:	85ca                	mv	a1,s2
 264:	198000ef          	jal	3fc <fstat>
 268:	892a                	mv	s2,a0
  close(fd);
 26a:	8526                	mv	a0,s1
 26c:	160000ef          	jal	3cc <close>
  return r;
 270:	64a2                	ld	s1,8(sp)
}
 272:	854a                	mv	a0,s2
 274:	60e2                	ld	ra,24(sp)
 276:	6442                	ld	s0,16(sp)
 278:	6902                	ld	s2,0(sp)
 27a:	6105                	addi	sp,sp,32
 27c:	8082                	ret
    return -1;
 27e:	597d                	li	s2,-1
 280:	bfcd                	j	272 <stat+0x2a>

0000000000000282 <atoi>:

int
atoi(const char *s)
{
 282:	1141                	addi	sp,sp,-16
 284:	e422                	sd	s0,8(sp)
 286:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 288:	00054683          	lbu	a3,0(a0)
 28c:	fd06879b          	addiw	a5,a3,-48
 290:	0ff7f793          	zext.b	a5,a5
 294:	4625                	li	a2,9
 296:	02f66863          	bltu	a2,a5,2c6 <atoi+0x44>
 29a:	872a                	mv	a4,a0
  n = 0;
 29c:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 29e:	0705                	addi	a4,a4,1
 2a0:	0025179b          	slliw	a5,a0,0x2
 2a4:	9fa9                	addw	a5,a5,a0
 2a6:	0017979b          	slliw	a5,a5,0x1
 2aa:	9fb5                	addw	a5,a5,a3
 2ac:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 2b0:	00074683          	lbu	a3,0(a4)
 2b4:	fd06879b          	addiw	a5,a3,-48
 2b8:	0ff7f793          	zext.b	a5,a5
 2bc:	fef671e3          	bgeu	a2,a5,29e <atoi+0x1c>
  return n;
}
 2c0:	6422                	ld	s0,8(sp)
 2c2:	0141                	addi	sp,sp,16
 2c4:	8082                	ret
  n = 0;
 2c6:	4501                	li	a0,0
 2c8:	bfe5                	j	2c0 <atoi+0x3e>

00000000000002ca <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 2ca:	1141                	addi	sp,sp,-16
 2cc:	e422                	sd	s0,8(sp)
 2ce:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2d0:	02b57463          	bgeu	a0,a1,2f8 <memmove+0x2e>
    while (n-- > 0)
 2d4:	00c05f63          	blez	a2,2f2 <memmove+0x28>
 2d8:	1602                	slli	a2,a2,0x20
 2da:	9201                	srli	a2,a2,0x20
 2dc:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2e0:	872a                	mv	a4,a0
      *dst++ = *src++;
 2e2:	0585                	addi	a1,a1,1
 2e4:	0705                	addi	a4,a4,1
 2e6:	fff5c683          	lbu	a3,-1(a1)
 2ea:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 2ee:	fef71ae3          	bne	a4,a5,2e2 <memmove+0x18>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2f2:	6422                	ld	s0,8(sp)
 2f4:	0141                	addi	sp,sp,16
 2f6:	8082                	ret
    dst += n;
 2f8:	00c50733          	add	a4,a0,a2
    src += n;
 2fc:	95b2                	add	a1,a1,a2
    while (n-- > 0)
 2fe:	fec05ae3          	blez	a2,2f2 <memmove+0x28>
 302:	fff6079b          	addiw	a5,a2,-1
 306:	1782                	slli	a5,a5,0x20
 308:	9381                	srli	a5,a5,0x20
 30a:	fff7c793          	not	a5,a5
 30e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 310:	15fd                	addi	a1,a1,-1
 312:	177d                	addi	a4,a4,-1
 314:	0005c683          	lbu	a3,0(a1)
 318:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 31c:	fee79ae3          	bne	a5,a4,310 <memmove+0x46>
 320:	bfc9                	j	2f2 <memmove+0x28>

0000000000000322 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 322:	1141                	addi	sp,sp,-16
 324:	e422                	sd	s0,8(sp)
 326:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 328:	ca05                	beqz	a2,358 <memcmp+0x36>
 32a:	fff6069b          	addiw	a3,a2,-1
 32e:	1682                	slli	a3,a3,0x20
 330:	9281                	srli	a3,a3,0x20
 332:	0685                	addi	a3,a3,1
 334:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 336:	00054783          	lbu	a5,0(a0)
 33a:	0005c703          	lbu	a4,0(a1)
 33e:	00e79863          	bne	a5,a4,34e <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 342:	0505                	addi	a0,a0,1
    p2++;
 344:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 346:	fed518e3          	bne	a0,a3,336 <memcmp+0x14>
  }
  return 0;
 34a:	4501                	li	a0,0
 34c:	a019                	j	352 <memcmp+0x30>
      return *p1 - *p2;
 34e:	40e7853b          	subw	a0,a5,a4
}
 352:	6422                	ld	s0,8(sp)
 354:	0141                	addi	sp,sp,16
 356:	8082                	ret
  return 0;
 358:	4501                	li	a0,0
 35a:	bfe5                	j	352 <memcmp+0x30>

000000000000035c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 35c:	1141                	addi	sp,sp,-16
 35e:	e406                	sd	ra,8(sp)
 360:	e022                	sd	s0,0(sp)
 362:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 364:	f67ff0ef          	jal	2ca <memmove>
}
 368:	60a2                	ld	ra,8(sp)
 36a:	6402                	ld	s0,0(sp)
 36c:	0141                	addi	sp,sp,16
 36e:	8082                	ret

0000000000000370 <sbrk>:

char *
sbrk(int n)
{
 370:	1141                	addi	sp,sp,-16
 372:	e406                	sd	ra,8(sp)
 374:	e022                	sd	s0,0(sp)
 376:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 378:	4585                	li	a1,1
 37a:	0b2000ef          	jal	42c <sys_sbrk>
}
 37e:	60a2                	ld	ra,8(sp)
 380:	6402                	ld	s0,0(sp)
 382:	0141                	addi	sp,sp,16
 384:	8082                	ret

0000000000000386 <sbrklazy>:

char *
sbrklazy(int n)
{
 386:	1141                	addi	sp,sp,-16
 388:	e406                	sd	ra,8(sp)
 38a:	e022                	sd	s0,0(sp)
 38c:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 38e:	4589                	li	a1,2
 390:	09c000ef          	jal	42c <sys_sbrk>
}
 394:	60a2                	ld	ra,8(sp)
 396:	6402                	ld	s0,0(sp)
 398:	0141                	addi	sp,sp,16
 39a:	8082                	ret

000000000000039c <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 39c:	4885                	li	a7,1
 ecall
 39e:	00000073          	ecall
 ret
 3a2:	8082                	ret

00000000000003a4 <exit>:
.global exit
exit:
 li a7, SYS_exit
 3a4:	4889                	li	a7,2
 ecall
 3a6:	00000073          	ecall
 ret
 3aa:	8082                	ret

00000000000003ac <wait>:
.global wait
wait:
 li a7, SYS_wait
 3ac:	488d                	li	a7,3
 ecall
 3ae:	00000073          	ecall
 ret
 3b2:	8082                	ret

00000000000003b4 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3b4:	4891                	li	a7,4
 ecall
 3b6:	00000073          	ecall
 ret
 3ba:	8082                	ret

00000000000003bc <read>:
.global read
read:
 li a7, SYS_read
 3bc:	4895                	li	a7,5
 ecall
 3be:	00000073          	ecall
 ret
 3c2:	8082                	ret

00000000000003c4 <write>:
.global write
write:
 li a7, SYS_write
 3c4:	48c1                	li	a7,16
 ecall
 3c6:	00000073          	ecall
 ret
 3ca:	8082                	ret

00000000000003cc <close>:
.global close
close:
 li a7, SYS_close
 3cc:	48d5                	li	a7,21
 ecall
 3ce:	00000073          	ecall
 ret
 3d2:	8082                	ret

00000000000003d4 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3d4:	4899                	li	a7,6
 ecall
 3d6:	00000073          	ecall
 ret
 3da:	8082                	ret

00000000000003dc <exec>:
.global exec
exec:
 li a7, SYS_exec
 3dc:	489d                	li	a7,7
 ecall
 3de:	00000073          	ecall
 ret
 3e2:	8082                	ret

00000000000003e4 <open>:
.global open
open:
 li a7, SYS_open
 3e4:	48bd                	li	a7,15
 ecall
 3e6:	00000073          	ecall
 ret
 3ea:	8082                	ret

00000000000003ec <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3ec:	48c5                	li	a7,17
 ecall
 3ee:	00000073          	ecall
 ret
 3f2:	8082                	ret

00000000000003f4 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3f4:	48c9                	li	a7,18
 ecall
 3f6:	00000073          	ecall
 ret
 3fa:	8082                	ret

00000000000003fc <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3fc:	48a1                	li	a7,8
 ecall
 3fe:	00000073          	ecall
 ret
 402:	8082                	ret

0000000000000404 <link>:
.global link
link:
 li a7, SYS_link
 404:	48cd                	li	a7,19
 ecall
 406:	00000073          	ecall
 ret
 40a:	8082                	ret

000000000000040c <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 40c:	48d1                	li	a7,20
 ecall
 40e:	00000073          	ecall
 ret
 412:	8082                	ret

0000000000000414 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 414:	48a5                	li	a7,9
 ecall
 416:	00000073          	ecall
 ret
 41a:	8082                	ret

000000000000041c <dup>:
.global dup
dup:
 li a7, SYS_dup
 41c:	48a9                	li	a7,10
 ecall
 41e:	00000073          	ecall
 ret
 422:	8082                	ret

0000000000000424 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 424:	48ad                	li	a7,11
 ecall
 426:	00000073          	ecall
 ret
 42a:	8082                	ret

000000000000042c <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 42c:	48b1                	li	a7,12
 ecall
 42e:	00000073          	ecall
 ret
 432:	8082                	ret

0000000000000434 <pause>:
.global pause
pause:
 li a7, SYS_pause
 434:	48b5                	li	a7,13
 ecall
 436:	00000073          	ecall
 ret
 43a:	8082                	ret

000000000000043c <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 43c:	48b9                	li	a7,14
 ecall
 43e:	00000073          	ecall
 ret
 442:	8082                	ret

0000000000000444 <sync>:
.global sync
sync:
 li a7, SYS_sync
 444:	48d9                	li	a7,22
 ecall
 446:	00000073          	ecall
 ret
 44a:	8082                	ret

000000000000044c <raceinit>:
.global raceinit
raceinit:
 li a7, SYS_raceinit
 44c:	48dd                	li	a7,23
 ecall
 44e:	00000073          	ecall
 ret
 452:	8082                	ret

0000000000000454 <raceworker>:
.global raceworker
raceworker:
 li a7, SYS_raceworker
 454:	48e1                	li	a7,24
 ecall
 456:	00000073          	ecall
 ret
 45a:	8082                	ret

000000000000045c <racereport>:
.global racereport
racereport:
 li a7, SYS_racereport
 45c:	48e5                	li	a7,25
 ecall
 45e:	00000073          	ecall
 ret
 462:	8082                	ret

0000000000000464 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 464:	1101                	addi	sp,sp,-32
 466:	ec06                	sd	ra,24(sp)
 468:	e822                	sd	s0,16(sp)
 46a:	1000                	addi	s0,sp,32
 46c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 470:	4605                	li	a2,1
 472:	fef40593          	addi	a1,s0,-17
 476:	f4fff0ef          	jal	3c4 <write>
}
 47a:	60e2                	ld	ra,24(sp)
 47c:	6442                	ld	s0,16(sp)
 47e:	6105                	addi	sp,sp,32
 480:	8082                	ret

0000000000000482 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 482:	715d                	addi	sp,sp,-80
 484:	e486                	sd	ra,72(sp)
 486:	e0a2                	sd	s0,64(sp)
 488:	f84a                	sd	s2,48(sp)
 48a:	0880                	addi	s0,sp,80
 48c:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 48e:	c299                	beqz	a3,494 <printint+0x12>
 490:	0805c363          	bltz	a1,516 <printint+0x94>
  neg = 0;
 494:	4881                	li	a7,0
 496:	fb840693          	addi	a3,s0,-72
    x = -xx;
  } else {
    x = xx;
  }

  i = 0;
 49a:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
 49c:	00000517          	auipc	a0,0x0
 4a0:	6b450513          	addi	a0,a0,1716 # b50 <digits>
 4a4:	883e                	mv	a6,a5
 4a6:	2785                	addiw	a5,a5,1
 4a8:	02c5f733          	remu	a4,a1,a2
 4ac:	972a                	add	a4,a4,a0
 4ae:	00074703          	lbu	a4,0(a4)
 4b2:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
 4b6:	872e                	mv	a4,a1
 4b8:	02c5d5b3          	divu	a1,a1,a2
 4bc:	0685                	addi	a3,a3,1
 4be:	fec773e3          	bgeu	a4,a2,4a4 <printint+0x22>
  if (neg)
 4c2:	00088b63          	beqz	a7,4d8 <printint+0x56>
    buf[i++] = '-';
 4c6:	fd078793          	addi	a5,a5,-48
 4ca:	97a2                	add	a5,a5,s0
 4cc:	02d00713          	li	a4,45
 4d0:	fee78423          	sb	a4,-24(a5)
 4d4:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
 4d8:	02f05a63          	blez	a5,50c <printint+0x8a>
 4dc:	fc26                	sd	s1,56(sp)
 4de:	f44e                	sd	s3,40(sp)
 4e0:	fb840713          	addi	a4,s0,-72
 4e4:	00f704b3          	add	s1,a4,a5
 4e8:	fff70993          	addi	s3,a4,-1
 4ec:	99be                	add	s3,s3,a5
 4ee:	37fd                	addiw	a5,a5,-1
 4f0:	1782                	slli	a5,a5,0x20
 4f2:	9381                	srli	a5,a5,0x20
 4f4:	40f989b3          	sub	s3,s3,a5
    putc(fd, buf[i]);
 4f8:	fff4c583          	lbu	a1,-1(s1)
 4fc:	854a                	mv	a0,s2
 4fe:	f67ff0ef          	jal	464 <putc>
  while (--i >= 0)
 502:	14fd                	addi	s1,s1,-1
 504:	ff349ae3          	bne	s1,s3,4f8 <printint+0x76>
 508:	74e2                	ld	s1,56(sp)
 50a:	79a2                	ld	s3,40(sp)
}
 50c:	60a6                	ld	ra,72(sp)
 50e:	6406                	ld	s0,64(sp)
 510:	7942                	ld	s2,48(sp)
 512:	6161                	addi	sp,sp,80
 514:	8082                	ret
    x = -xx;
 516:	40b005b3          	neg	a1,a1
    neg = 1;
 51a:	4885                	li	a7,1
    x = -xx;
 51c:	bfad                	j	496 <printint+0x14>

000000000000051e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 51e:	711d                	addi	sp,sp,-96
 520:	ec86                	sd	ra,88(sp)
 522:	e8a2                	sd	s0,80(sp)
 524:	e0ca                	sd	s2,64(sp)
 526:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 528:	0005c903          	lbu	s2,0(a1)
 52c:	28090663          	beqz	s2,7b8 <vprintf+0x29a>
 530:	e4a6                	sd	s1,72(sp)
 532:	fc4e                	sd	s3,56(sp)
 534:	f852                	sd	s4,48(sp)
 536:	f456                	sd	s5,40(sp)
 538:	f05a                	sd	s6,32(sp)
 53a:	ec5e                	sd	s7,24(sp)
 53c:	e862                	sd	s8,16(sp)
 53e:	e466                	sd	s9,8(sp)
 540:	8b2a                	mv	s6,a0
 542:	8a2e                	mv	s4,a1
 544:	8bb2                	mv	s7,a2
  state = 0;
 546:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 548:	4481                	li	s1,0
 54a:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 54c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 550:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 554:	06c00c93          	li	s9,108
 558:	a005                	j	578 <vprintf+0x5a>
        putc(fd, c0);
 55a:	85ca                	mv	a1,s2
 55c:	855a                	mv	a0,s6
 55e:	f07ff0ef          	jal	464 <putc>
 562:	a019                	j	568 <vprintf+0x4a>
    } else if (state == '%') {
 564:	03598263          	beq	s3,s5,588 <vprintf+0x6a>
  for (i = 0; fmt[i]; i++) {
 568:	2485                	addiw	s1,s1,1
 56a:	8726                	mv	a4,s1
 56c:	009a07b3          	add	a5,s4,s1
 570:	0007c903          	lbu	s2,0(a5)
 574:	22090a63          	beqz	s2,7a8 <vprintf+0x28a>
    c0 = fmt[i] & 0xff;
 578:	0009079b          	sext.w	a5,s2
    if (state == 0) {
 57c:	fe0994e3          	bnez	s3,564 <vprintf+0x46>
      if (c0 == '%') {
 580:	fd579de3          	bne	a5,s5,55a <vprintf+0x3c>
        state = '%';
 584:	89be                	mv	s3,a5
 586:	b7cd                	j	568 <vprintf+0x4a>
        c1 = fmt[i + 1] & 0xff;
 588:	00ea06b3          	add	a3,s4,a4
 58c:	0016c683          	lbu	a3,1(a3)
      c1 = c2 = 0;
 590:	8636                	mv	a2,a3
      if (c1)
 592:	c681                	beqz	a3,59a <vprintf+0x7c>
        c2 = fmt[i + 2] & 0xff;
 594:	9752                	add	a4,a4,s4
 596:	00274603          	lbu	a2,2(a4)
      if (c0 == 'd') {
 59a:	05878363          	beq	a5,s8,5e0 <vprintf+0xc2>
      } else if (c0 == 'l' && c1 == 'd') {
 59e:	05978d63          	beq	a5,s9,5f8 <vprintf+0xda>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if (c0 == 'u') {
 5a2:	07500713          	li	a4,117
 5a6:	0ee78763          	beq	a5,a4,694 <vprintf+0x176>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if (c0 == 'x') {
 5aa:	07800713          	li	a4,120
 5ae:	12e78963          	beq	a5,a4,6e0 <vprintf+0x1c2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if (c0 == 'p') {
 5b2:	07000713          	li	a4,112
 5b6:	14e78e63          	beq	a5,a4,712 <vprintf+0x1f4>
        printptr(fd, va_arg(ap, uint64));
      } else if (c0 == 'c') {
 5ba:	06300713          	li	a4,99
 5be:	18e78e63          	beq	a5,a4,75a <vprintf+0x23c>
        putc(fd, va_arg(ap, uint32));
      } else if (c0 == 's') {
 5c2:	07300713          	li	a4,115
 5c6:	1ae78463          	beq	a5,a4,76e <vprintf+0x250>
        if ((s = va_arg(ap, char *)) == 0)
          s = "(null)";
        for (; *s; s++)
          putc(fd, *s);
      } else if (c0 == '%') {
 5ca:	02500713          	li	a4,37
 5ce:	04e79563          	bne	a5,a4,618 <vprintf+0xfa>
        putc(fd, '%');
 5d2:	02500593          	li	a1,37
 5d6:	855a                	mv	a0,s6
 5d8:	e8dff0ef          	jal	464 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 5dc:	4981                	li	s3,0
 5de:	b769                	j	568 <vprintf+0x4a>
        printint(fd, va_arg(ap, int), 10, 1);
 5e0:	008b8913          	addi	s2,s7,8
 5e4:	4685                	li	a3,1
 5e6:	4629                	li	a2,10
 5e8:	000ba583          	lw	a1,0(s7)
 5ec:	855a                	mv	a0,s6
 5ee:	e95ff0ef          	jal	482 <printint>
 5f2:	8bca                	mv	s7,s2
      state = 0;
 5f4:	4981                	li	s3,0
 5f6:	bf8d                	j	568 <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'd') {
 5f8:	06400793          	li	a5,100
 5fc:	02f68963          	beq	a3,a5,62e <vprintf+0x110>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 600:	06c00793          	li	a5,108
 604:	04f68263          	beq	a3,a5,648 <vprintf+0x12a>
      } else if (c0 == 'l' && c1 == 'u') {
 608:	07500793          	li	a5,117
 60c:	0af68063          	beq	a3,a5,6ac <vprintf+0x18e>
      } else if (c0 == 'l' && c1 == 'x') {
 610:	07800793          	li	a5,120
 614:	0ef68263          	beq	a3,a5,6f8 <vprintf+0x1da>
        putc(fd, '%');
 618:	02500593          	li	a1,37
 61c:	855a                	mv	a0,s6
 61e:	e47ff0ef          	jal	464 <putc>
        putc(fd, c0);
 622:	85ca                	mv	a1,s2
 624:	855a                	mv	a0,s6
 626:	e3fff0ef          	jal	464 <putc>
      state = 0;
 62a:	4981                	li	s3,0
 62c:	bf35                	j	568 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 62e:	008b8913          	addi	s2,s7,8
 632:	4685                	li	a3,1
 634:	4629                	li	a2,10
 636:	000bb583          	ld	a1,0(s7)
 63a:	855a                	mv	a0,s6
 63c:	e47ff0ef          	jal	482 <printint>
        i += 1;
 640:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 642:	8bca                	mv	s7,s2
      state = 0;
 644:	4981                	li	s3,0
        i += 1;
 646:	b70d                	j	568 <vprintf+0x4a>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 648:	06400793          	li	a5,100
 64c:	02f60763          	beq	a2,a5,67a <vprintf+0x15c>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 650:	07500793          	li	a5,117
 654:	06f60963          	beq	a2,a5,6c6 <vprintf+0x1a8>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 658:	07800793          	li	a5,120
 65c:	faf61ee3          	bne	a2,a5,618 <vprintf+0xfa>
        printint(fd, va_arg(ap, uint64), 16, 0);
 660:	008b8913          	addi	s2,s7,8
 664:	4681                	li	a3,0
 666:	4641                	li	a2,16
 668:	000bb583          	ld	a1,0(s7)
 66c:	855a                	mv	a0,s6
 66e:	e15ff0ef          	jal	482 <printint>
        i += 2;
 672:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 674:	8bca                	mv	s7,s2
      state = 0;
 676:	4981                	li	s3,0
        i += 2;
 678:	bdc5                	j	568 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 1);
 67a:	008b8913          	addi	s2,s7,8
 67e:	4685                	li	a3,1
 680:	4629                	li	a2,10
 682:	000bb583          	ld	a1,0(s7)
 686:	855a                	mv	a0,s6
 688:	dfbff0ef          	jal	482 <printint>
        i += 2;
 68c:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 68e:	8bca                	mv	s7,s2
      state = 0;
 690:	4981                	li	s3,0
        i += 2;
 692:	bdd9                	j	568 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 10, 0);
 694:	008b8913          	addi	s2,s7,8
 698:	4681                	li	a3,0
 69a:	4629                	li	a2,10
 69c:	000be583          	lwu	a1,0(s7)
 6a0:	855a                	mv	a0,s6
 6a2:	de1ff0ef          	jal	482 <printint>
 6a6:	8bca                	mv	s7,s2
      state = 0;
 6a8:	4981                	li	s3,0
 6aa:	bd7d                	j	568 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6ac:	008b8913          	addi	s2,s7,8
 6b0:	4681                	li	a3,0
 6b2:	4629                	li	a2,10
 6b4:	000bb583          	ld	a1,0(s7)
 6b8:	855a                	mv	a0,s6
 6ba:	dc9ff0ef          	jal	482 <printint>
        i += 1;
 6be:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 6c0:	8bca                	mv	s7,s2
      state = 0;
 6c2:	4981                	li	s3,0
        i += 1;
 6c4:	b555                	j	568 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6c6:	008b8913          	addi	s2,s7,8
 6ca:	4681                	li	a3,0
 6cc:	4629                	li	a2,10
 6ce:	000bb583          	ld	a1,0(s7)
 6d2:	855a                	mv	a0,s6
 6d4:	dafff0ef          	jal	482 <printint>
        i += 2;
 6d8:	2489                	addiw	s1,s1,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6da:	8bca                	mv	s7,s2
      state = 0;
 6dc:	4981                	li	s3,0
        i += 2;
 6de:	b569                	j	568 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint32), 16, 0);
 6e0:	008b8913          	addi	s2,s7,8
 6e4:	4681                	li	a3,0
 6e6:	4641                	li	a2,16
 6e8:	000be583          	lwu	a1,0(s7)
 6ec:	855a                	mv	a0,s6
 6ee:	d95ff0ef          	jal	482 <printint>
 6f2:	8bca                	mv	s7,s2
      state = 0;
 6f4:	4981                	li	s3,0
 6f6:	bd8d                	j	568 <vprintf+0x4a>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6f8:	008b8913          	addi	s2,s7,8
 6fc:	4681                	li	a3,0
 6fe:	4641                	li	a2,16
 700:	000bb583          	ld	a1,0(s7)
 704:	855a                	mv	a0,s6
 706:	d7dff0ef          	jal	482 <printint>
        i += 1;
 70a:	2485                	addiw	s1,s1,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 70c:	8bca                	mv	s7,s2
      state = 0;
 70e:	4981                	li	s3,0
        i += 1;
 710:	bda1                	j	568 <vprintf+0x4a>
 712:	e06a                	sd	s10,0(sp)
        printptr(fd, va_arg(ap, uint64));
 714:	008b8d13          	addi	s10,s7,8
 718:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 71c:	03000593          	li	a1,48
 720:	855a                	mv	a0,s6
 722:	d43ff0ef          	jal	464 <putc>
  putc(fd, 'x');
 726:	07800593          	li	a1,120
 72a:	855a                	mv	a0,s6
 72c:	d39ff0ef          	jal	464 <putc>
 730:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 732:	00000b97          	auipc	s7,0x0
 736:	41eb8b93          	addi	s7,s7,1054 # b50 <digits>
 73a:	03c9d793          	srli	a5,s3,0x3c
 73e:	97de                	add	a5,a5,s7
 740:	0007c583          	lbu	a1,0(a5)
 744:	855a                	mv	a0,s6
 746:	d1fff0ef          	jal	464 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 74a:	0992                	slli	s3,s3,0x4
 74c:	397d                	addiw	s2,s2,-1
 74e:	fe0916e3          	bnez	s2,73a <vprintf+0x21c>
        printptr(fd, va_arg(ap, uint64));
 752:	8bea                	mv	s7,s10
      state = 0;
 754:	4981                	li	s3,0
 756:	6d02                	ld	s10,0(sp)
 758:	bd01                	j	568 <vprintf+0x4a>
        putc(fd, va_arg(ap, uint32));
 75a:	008b8913          	addi	s2,s7,8
 75e:	000bc583          	lbu	a1,0(s7)
 762:	855a                	mv	a0,s6
 764:	d01ff0ef          	jal	464 <putc>
 768:	8bca                	mv	s7,s2
      state = 0;
 76a:	4981                	li	s3,0
 76c:	bbf5                	j	568 <vprintf+0x4a>
        if ((s = va_arg(ap, char *)) == 0)
 76e:	008b8993          	addi	s3,s7,8
 772:	000bb903          	ld	s2,0(s7)
 776:	00090f63          	beqz	s2,794 <vprintf+0x276>
        for (; *s; s++)
 77a:	00094583          	lbu	a1,0(s2)
 77e:	c195                	beqz	a1,7a2 <vprintf+0x284>
          putc(fd, *s);
 780:	855a                	mv	a0,s6
 782:	ce3ff0ef          	jal	464 <putc>
        for (; *s; s++)
 786:	0905                	addi	s2,s2,1
 788:	00094583          	lbu	a1,0(s2)
 78c:	f9f5                	bnez	a1,780 <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
 78e:	8bce                	mv	s7,s3
      state = 0;
 790:	4981                	li	s3,0
 792:	bbd9                	j	568 <vprintf+0x4a>
          s = "(null)";
 794:	00000917          	auipc	s2,0x0
 798:	3b490913          	addi	s2,s2,948 # b48 <malloc+0x2a8>
        for (; *s; s++)
 79c:	02800593          	li	a1,40
 7a0:	b7c5                	j	780 <vprintf+0x262>
        if ((s = va_arg(ap, char *)) == 0)
 7a2:	8bce                	mv	s7,s3
      state = 0;
 7a4:	4981                	li	s3,0
 7a6:	b3c9                	j	568 <vprintf+0x4a>
 7a8:	64a6                	ld	s1,72(sp)
 7aa:	79e2                	ld	s3,56(sp)
 7ac:	7a42                	ld	s4,48(sp)
 7ae:	7aa2                	ld	s5,40(sp)
 7b0:	7b02                	ld	s6,32(sp)
 7b2:	6be2                	ld	s7,24(sp)
 7b4:	6c42                	ld	s8,16(sp)
 7b6:	6ca2                	ld	s9,8(sp)
    }
  }
}
 7b8:	60e6                	ld	ra,88(sp)
 7ba:	6446                	ld	s0,80(sp)
 7bc:	6906                	ld	s2,64(sp)
 7be:	6125                	addi	sp,sp,96
 7c0:	8082                	ret

00000000000007c2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7c2:	715d                	addi	sp,sp,-80
 7c4:	ec06                	sd	ra,24(sp)
 7c6:	e822                	sd	s0,16(sp)
 7c8:	1000                	addi	s0,sp,32
 7ca:	e010                	sd	a2,0(s0)
 7cc:	e414                	sd	a3,8(s0)
 7ce:	e818                	sd	a4,16(s0)
 7d0:	ec1c                	sd	a5,24(s0)
 7d2:	03043023          	sd	a6,32(s0)
 7d6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7da:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7de:	8622                	mv	a2,s0
 7e0:	d3fff0ef          	jal	51e <vprintf>
}
 7e4:	60e2                	ld	ra,24(sp)
 7e6:	6442                	ld	s0,16(sp)
 7e8:	6161                	addi	sp,sp,80
 7ea:	8082                	ret

00000000000007ec <printf>:

void
printf(const char *fmt, ...)
{
 7ec:	711d                	addi	sp,sp,-96
 7ee:	ec06                	sd	ra,24(sp)
 7f0:	e822                	sd	s0,16(sp)
 7f2:	1000                	addi	s0,sp,32
 7f4:	e40c                	sd	a1,8(s0)
 7f6:	e810                	sd	a2,16(s0)
 7f8:	ec14                	sd	a3,24(s0)
 7fa:	f018                	sd	a4,32(s0)
 7fc:	f41c                	sd	a5,40(s0)
 7fe:	03043823          	sd	a6,48(s0)
 802:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 806:	00840613          	addi	a2,s0,8
 80a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 80e:	85aa                	mv	a1,a0
 810:	4505                	li	a0,1
 812:	d0dff0ef          	jal	51e <vprintf>
}
 816:	60e2                	ld	ra,24(sp)
 818:	6442                	ld	s0,16(sp)
 81a:	6125                	addi	sp,sp,96
 81c:	8082                	ret

000000000000081e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 81e:	1141                	addi	sp,sp,-16
 820:	e422                	sd	s0,8(sp)
 822:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 824:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 828:	00000797          	auipc	a5,0x0
 82c:	7d87b783          	ld	a5,2008(a5) # 1000 <freep>
 830:	a02d                	j	85a <free+0x3c>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if (bp + bp->s.size == p->s.ptr) {
    bp->s.size += p->s.ptr->s.size;
 832:	4618                	lw	a4,8(a2)
 834:	9f2d                	addw	a4,a4,a1
 836:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 83a:	6398                	ld	a4,0(a5)
 83c:	6310                	ld	a2,0(a4)
 83e:	a83d                	j	87c <free+0x5e>
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
    p->s.size += bp->s.size;
 840:	ff852703          	lw	a4,-8(a0)
 844:	9f31                	addw	a4,a4,a2
 846:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 848:	ff053683          	ld	a3,-16(a0)
 84c:	a091                	j	890 <free+0x72>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 84e:	6398                	ld	a4,0(a5)
 850:	00e7e463          	bltu	a5,a4,858 <free+0x3a>
 854:	00e6ea63          	bltu	a3,a4,868 <free+0x4a>
{
 858:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 85a:	fed7fae3          	bgeu	a5,a3,84e <free+0x30>
 85e:	6398                	ld	a4,0(a5)
 860:	00e6e463          	bltu	a3,a4,868 <free+0x4a>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 864:	fee7eae3          	bltu	a5,a4,858 <free+0x3a>
  if (bp + bp->s.size == p->s.ptr) {
 868:	ff852583          	lw	a1,-8(a0)
 86c:	6390                	ld	a2,0(a5)
 86e:	02059813          	slli	a6,a1,0x20
 872:	01c85713          	srli	a4,a6,0x1c
 876:	9736                	add	a4,a4,a3
 878:	fae60de3          	beq	a2,a4,832 <free+0x14>
    bp->s.ptr = p->s.ptr->s.ptr;
 87c:	fec53823          	sd	a2,-16(a0)
  if (p + p->s.size == bp) {
 880:	4790                	lw	a2,8(a5)
 882:	02061593          	slli	a1,a2,0x20
 886:	01c5d713          	srli	a4,a1,0x1c
 88a:	973e                	add	a4,a4,a5
 88c:	fae68ae3          	beq	a3,a4,840 <free+0x22>
    p->s.ptr = bp->s.ptr;
 890:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 892:	00000717          	auipc	a4,0x0
 896:	76f73723          	sd	a5,1902(a4) # 1000 <freep>
}
 89a:	6422                	ld	s0,8(sp)
 89c:	0141                	addi	sp,sp,16
 89e:	8082                	ret

00000000000008a0 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 8a0:	7139                	addi	sp,sp,-64
 8a2:	fc06                	sd	ra,56(sp)
 8a4:	f822                	sd	s0,48(sp)
 8a6:	f426                	sd	s1,40(sp)
 8a8:	ec4e                	sd	s3,24(sp)
 8aa:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 8ac:	02051493          	slli	s1,a0,0x20
 8b0:	9081                	srli	s1,s1,0x20
 8b2:	04bd                	addi	s1,s1,15
 8b4:	8091                	srli	s1,s1,0x4
 8b6:	0014899b          	addiw	s3,s1,1
 8ba:	0485                	addi	s1,s1,1
  if ((prevp = freep) == 0) {
 8bc:	00000517          	auipc	a0,0x0
 8c0:	74453503          	ld	a0,1860(a0) # 1000 <freep>
 8c4:	c915                	beqz	a0,8f8 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 8c6:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 8c8:	4798                	lw	a4,8(a5)
 8ca:	08977a63          	bgeu	a4,s1,95e <malloc+0xbe>
 8ce:	f04a                	sd	s2,32(sp)
 8d0:	e852                	sd	s4,16(sp)
 8d2:	e456                	sd	s5,8(sp)
 8d4:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 8d6:	8a4e                	mv	s4,s3
 8d8:	0009871b          	sext.w	a4,s3
 8dc:	6685                	lui	a3,0x1
 8de:	00d77363          	bgeu	a4,a3,8e4 <malloc+0x44>
 8e2:	6a05                	lui	s4,0x1
 8e4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8e8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 8ec:	00000917          	auipc	s2,0x0
 8f0:	71490913          	addi	s2,s2,1812 # 1000 <freep>
  if (p == SBRK_ERROR)
 8f4:	5afd                	li	s5,-1
 8f6:	a081                	j	936 <malloc+0x96>
 8f8:	f04a                	sd	s2,32(sp)
 8fa:	e852                	sd	s4,16(sp)
 8fc:	e456                	sd	s5,8(sp)
 8fe:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 900:	00000797          	auipc	a5,0x0
 904:	71078793          	addi	a5,a5,1808 # 1010 <base>
 908:	00000717          	auipc	a4,0x0
 90c:	6ef73c23          	sd	a5,1784(a4) # 1000 <freep>
 910:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 912:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 916:	b7c1                	j	8d6 <malloc+0x36>
        prevp->s.ptr = p->s.ptr;
 918:	6398                	ld	a4,0(a5)
 91a:	e118                	sd	a4,0(a0)
 91c:	a8a9                	j	976 <malloc+0xd6>
  hp->s.size = nu;
 91e:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 922:	0541                	addi	a0,a0,16
 924:	efbff0ef          	jal	81e <free>
  return freep;
 928:	00093503          	ld	a0,0(s2)
      if ((p = morecore(nunits)) == 0)
 92c:	c12d                	beqz	a0,98e <malloc+0xee>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 92e:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 930:	4798                	lw	a4,8(a5)
 932:	02977263          	bgeu	a4,s1,956 <malloc+0xb6>
    if (p == freep)
 936:	00093703          	ld	a4,0(s2)
 93a:	853e                	mv	a0,a5
 93c:	fef719e3          	bne	a4,a5,92e <malloc+0x8e>
  p = sbrk(nu * sizeof(Header));
 940:	8552                	mv	a0,s4
 942:	a2fff0ef          	jal	370 <sbrk>
  if (p == SBRK_ERROR)
 946:	fd551ce3          	bne	a0,s5,91e <malloc+0x7e>
        return 0;
 94a:	4501                	li	a0,0
 94c:	7902                	ld	s2,32(sp)
 94e:	6a42                	ld	s4,16(sp)
 950:	6aa2                	ld	s5,8(sp)
 952:	6b02                	ld	s6,0(sp)
 954:	a03d                	j	982 <malloc+0xe2>
 956:	7902                	ld	s2,32(sp)
 958:	6a42                	ld	s4,16(sp)
 95a:	6aa2                	ld	s5,8(sp)
 95c:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 95e:	fae48de3          	beq	s1,a4,918 <malloc+0x78>
        p->s.size -= nunits;
 962:	4137073b          	subw	a4,a4,s3
 966:	c798                	sw	a4,8(a5)
        p += p->s.size;
 968:	02071693          	slli	a3,a4,0x20
 96c:	01c6d713          	srli	a4,a3,0x1c
 970:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 972:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 976:	00000717          	auipc	a4,0x0
 97a:	68a73523          	sd	a0,1674(a4) # 1000 <freep>
      return (void *)(p + 1);
 97e:	01078513          	addi	a0,a5,16
  }
}
 982:	70e2                	ld	ra,56(sp)
 984:	7442                	ld	s0,48(sp)
 986:	74a2                	ld	s1,40(sp)
 988:	69e2                	ld	s3,24(sp)
 98a:	6121                	addi	sp,sp,64
 98c:	8082                	ret
 98e:	7902                	ld	s2,32(sp)
 990:	6a42                	ld	s4,16(sp)
 992:	6aa2                	ld	s5,8(sp)
 994:	6b02                	ld	s6,0(sp)
 996:	b7f5                	j	982 <malloc+0xe2>
