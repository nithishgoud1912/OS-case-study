
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000b117          	auipc	sp,0xb
    80000004:	49813103          	ld	sp,1176(sp) # 8000b498 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	03e000ef          	jal	80000054 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e422                	sd	s0,8(sp)
    80000020:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000022:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000026:	577d                	li	a4,-1
    80000028:	177e                	slli	a4,a4,0x3f
    8000002a:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002c:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000030:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000034:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    80000038:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003c:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000040:	000f4737          	lui	a4,0xf4
    80000044:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000048:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004a:	14d79073          	csrw	stimecmp,a5
}
    8000004e:	6422                	ld	s0,8(sp)
    80000050:	0141                	addi	sp,sp,16
    80000052:	8082                	ret

0000000080000054 <start>:
{
    80000054:	1141                	addi	sp,sp,-16
    80000056:	e406                	sd	ra,8(sp)
    80000058:	e022                	sd	s0,0(sp)
    8000005a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    8000005c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000060:	7779                	lui	a4,0xffffe
    80000062:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffd9f7f>
    80000066:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000068:	6705                	lui	a4,0x1
    8000006a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000006e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000070:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000074:	00001797          	auipc	a5,0x1
    80000078:	d7a78793          	addi	a5,a5,-646 # 80000dee <main>
    8000007c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000080:	4781                	li	a5,0
    80000082:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    80000086:	67c1                	lui	a5,0x10
    80000088:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    8000008e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000092:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    80000096:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009a:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    8000009e:	57fd                	li	a5,-1
    800000a0:	83a9                	srli	a5,a5,0xa
    800000a2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000a6:	47bd                	li	a5,15
    800000a8:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000ac:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b0:	4705                	li	a4,1
    800000b2:	1776                	slli	a4,a4,0x3d
    800000b4:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000b6:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000ba:	f63ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000be:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c2:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c4:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c6:	30200073          	mret
}
    800000ca:	60a2                	ld	ra,8(sp)
    800000cc:	6402                	ld	s0,0(sp)
    800000ce:	0141                	addi	sp,sp,16
    800000d0:	8082                	ret

00000000800000d2 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d2:	7119                	addi	sp,sp,-128
    800000d4:	fc86                	sd	ra,120(sp)
    800000d6:	f8a2                	sd	s0,112(sp)
    800000d8:	f4a6                	sd	s1,104(sp)
    800000da:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000dc:	06c05a63          	blez	a2,80000150 <consolewrite+0x7e>
    800000e0:	f0ca                	sd	s2,96(sp)
    800000e2:	ecce                	sd	s3,88(sp)
    800000e4:	e8d2                	sd	s4,80(sp)
    800000e6:	e4d6                	sd	s5,72(sp)
    800000e8:	e0da                	sd	s6,64(sp)
    800000ea:	fc5e                	sd	s7,56(sp)
    800000ec:	f862                	sd	s8,48(sp)
    800000ee:	f466                	sd	s9,40(sp)
    800000f0:	8aaa                	mv	s5,a0
    800000f2:	8b2e                	mv	s6,a1
    800000f4:	8a32                	mv	s4,a2
  int i = 0;
    800000f6:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000f8:	02000c13          	li	s8,32
    800000fc:	02000c93          	li	s9,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000100:	5bfd                	li	s7,-1
    80000102:	a035                	j	8000012e <consolewrite+0x5c>
    if (nn > n - i)
    80000104:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000108:	86ce                	mv	a3,s3
    8000010a:	01648633          	add	a2,s1,s6
    8000010e:	85d6                	mv	a1,s5
    80000110:	f8040513          	addi	a0,s0,-128
    80000114:	172020ef          	jal	80002286 <either_copyin>
    80000118:	03750e63          	beq	a0,s7,80000154 <consolewrite+0x82>
      break;
    uartwrite(buf, nn);
    8000011c:	85ce                	mv	a1,s3
    8000011e:	f8040513          	addi	a0,s0,-128
    80000122:	786000ef          	jal	800008a8 <uartwrite>
    i += nn;
    80000126:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    8000012a:	0144da63          	bge	s1,s4,8000013e <consolewrite+0x6c>
    if (nn > n - i)
    8000012e:	409a093b          	subw	s2,s4,s1
    80000132:	0009079b          	sext.w	a5,s2
    80000136:	fcfc57e3          	bge	s8,a5,80000104 <consolewrite+0x32>
    8000013a:	8966                	mv	s2,s9
    8000013c:	b7e1                	j	80000104 <consolewrite+0x32>
    8000013e:	7906                	ld	s2,96(sp)
    80000140:	69e6                	ld	s3,88(sp)
    80000142:	6a46                	ld	s4,80(sp)
    80000144:	6aa6                	ld	s5,72(sp)
    80000146:	6b06                	ld	s6,64(sp)
    80000148:	7be2                	ld	s7,56(sp)
    8000014a:	7c42                	ld	s8,48(sp)
    8000014c:	7ca2                	ld	s9,40(sp)
    8000014e:	a819                	j	80000164 <consolewrite+0x92>
  int i = 0;
    80000150:	4481                	li	s1,0
    80000152:	a809                	j	80000164 <consolewrite+0x92>
    80000154:	7906                	ld	s2,96(sp)
    80000156:	69e6                	ld	s3,88(sp)
    80000158:	6a46                	ld	s4,80(sp)
    8000015a:	6aa6                	ld	s5,72(sp)
    8000015c:	6b06                	ld	s6,64(sp)
    8000015e:	7be2                	ld	s7,56(sp)
    80000160:	7c42                	ld	s8,48(sp)
    80000162:	7ca2                	ld	s9,40(sp)
  }

  return i;
}
    80000164:	8526                	mv	a0,s1
    80000166:	70e6                	ld	ra,120(sp)
    80000168:	7446                	ld	s0,112(sp)
    8000016a:	74a6                	ld	s1,104(sp)
    8000016c:	6109                	addi	sp,sp,128
    8000016e:	8082                	ret

0000000080000170 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000170:	711d                	addi	sp,sp,-96
    80000172:	ec86                	sd	ra,88(sp)
    80000174:	e8a2                	sd	s0,80(sp)
    80000176:	e4a6                	sd	s1,72(sp)
    80000178:	e0ca                	sd	s2,64(sp)
    8000017a:	fc4e                	sd	s3,56(sp)
    8000017c:	f852                	sd	s4,48(sp)
    8000017e:	f456                	sd	s5,40(sp)
    80000180:	f05a                	sd	s6,32(sp)
    80000182:	1080                	addi	s0,sp,96
    80000184:	8aaa                	mv	s5,a0
    80000186:	8a2e                	mv	s4,a1
    80000188:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    8000018a:	00060b1b          	sext.w	s6,a2
  acquire(&cons.lock);
    8000018e:	00013517          	auipc	a0,0x13
    80000192:	35250513          	addi	a0,a0,850 # 800134e0 <cons>
    80000196:	1fb000ef          	jal	80000b90 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    8000019a:	00013497          	auipc	s1,0x13
    8000019e:	34648493          	addi	s1,s1,838 # 800134e0 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a2:	00013917          	auipc	s2,0x13
    800001a6:	3d690913          	addi	s2,s2,982 # 80013578 <cons+0x98>
  while (n > 0) {
    800001aa:	0d305463          	blez	s3,80000272 <consoleread+0x102>
    while (cons.r == cons.w) {
    800001ae:	0984a783          	lw	a5,152(s1)
    800001b2:	09c4a703          	lw	a4,156(s1)
    800001b6:	0af71963          	bne	a4,a5,80000268 <consoleread+0xf8>
      if (killed(myproc())) {
    800001ba:	6e8010ef          	jal	800018a2 <myproc>
    800001be:	743010ef          	jal	80002100 <killed>
    800001c2:	e925                	bnez	a0,80000232 <consoleread+0xc2>
      sleep_prepare(&cons.r);
    800001c4:	854a                	mv	a0,s2
    800001c6:	4e1010ef          	jal	80001ea6 <sleep_prepare>
      release(&cons.lock);
    800001ca:	8526                	mv	a0,s1
    800001cc:	251000ef          	jal	80000c1c <release>
      sleep();
    800001d0:	513010ef          	jal	80001ee2 <sleep>
      acquire(&cons.lock);
    800001d4:	8526                	mv	a0,s1
    800001d6:	1bb000ef          	jal	80000b90 <acquire>
    while (cons.r == cons.w) {
    800001da:	0984a783          	lw	a5,152(s1)
    800001de:	09c4a703          	lw	a4,156(s1)
    800001e2:	fcf70ce3          	beq	a4,a5,800001ba <consoleread+0x4a>
    800001e6:	ec5e                	sd	s7,24(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001e8:	00013717          	auipc	a4,0x13
    800001ec:	2f870713          	addi	a4,a4,760 # 800134e0 <cons>
    800001f0:	0017869b          	addiw	a3,a5,1
    800001f4:	08d72c23          	sw	a3,152(a4)
    800001f8:	07f7f693          	andi	a3,a5,127
    800001fc:	9736                	add	a4,a4,a3
    800001fe:	01874703          	lbu	a4,24(a4)
    80000202:	00070b9b          	sext.w	s7,a4

    if (c == C('D')) { // end-of-file
    80000206:	4691                	li	a3,4
    80000208:	04db8663          	beq	s7,a3,80000254 <consoleread+0xe4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    8000020c:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000210:	4685                	li	a3,1
    80000212:	faf40613          	addi	a2,s0,-81
    80000216:	85d2                	mv	a1,s4
    80000218:	8556                	mv	a0,s5
    8000021a:	020020ef          	jal	8000223a <either_copyout>
    8000021e:	57fd                	li	a5,-1
    80000220:	04f50863          	beq	a0,a5,80000270 <consoleread+0x100>
      break;

    dst++;
    80000224:	0a05                	addi	s4,s4,1
    --n;
    80000226:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    80000228:	47a9                	li	a5,10
    8000022a:	04fb8d63          	beq	s7,a5,80000284 <consoleread+0x114>
    8000022e:	6be2                	ld	s7,24(sp)
    80000230:	bfad                	j	800001aa <consoleread+0x3a>
        release(&cons.lock);
    80000232:	00013517          	auipc	a0,0x13
    80000236:	2ae50513          	addi	a0,a0,686 # 800134e0 <cons>
    8000023a:	1e3000ef          	jal	80000c1c <release>
        return -1;
    8000023e:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000240:	60e6                	ld	ra,88(sp)
    80000242:	6446                	ld	s0,80(sp)
    80000244:	64a6                	ld	s1,72(sp)
    80000246:	6906                	ld	s2,64(sp)
    80000248:	79e2                	ld	s3,56(sp)
    8000024a:	7a42                	ld	s4,48(sp)
    8000024c:	7aa2                	ld	s5,40(sp)
    8000024e:	7b02                	ld	s6,32(sp)
    80000250:	6125                	addi	sp,sp,96
    80000252:	8082                	ret
      if (n < target) {
    80000254:	0009871b          	sext.w	a4,s3
    80000258:	01677a63          	bgeu	a4,s6,8000026c <consoleread+0xfc>
        cons.r--;
    8000025c:	00013717          	auipc	a4,0x13
    80000260:	30f72e23          	sw	a5,796(a4) # 80013578 <cons+0x98>
    80000264:	6be2                	ld	s7,24(sp)
    80000266:	a031                	j	80000272 <consoleread+0x102>
    80000268:	ec5e                	sd	s7,24(sp)
    8000026a:	bfbd                	j	800001e8 <consoleread+0x78>
    8000026c:	6be2                	ld	s7,24(sp)
    8000026e:	a011                	j	80000272 <consoleread+0x102>
    80000270:	6be2                	ld	s7,24(sp)
  release(&cons.lock);
    80000272:	00013517          	auipc	a0,0x13
    80000276:	26e50513          	addi	a0,a0,622 # 800134e0 <cons>
    8000027a:	1a3000ef          	jal	80000c1c <release>
  return target - n;
    8000027e:	413b053b          	subw	a0,s6,s3
    80000282:	bf7d                	j	80000240 <consoleread+0xd0>
    80000284:	6be2                	ld	s7,24(sp)
    80000286:	b7f5                	j	80000272 <consoleread+0x102>

0000000080000288 <consputc>:
{
    80000288:	1141                	addi	sp,sp,-16
    8000028a:	e406                	sd	ra,8(sp)
    8000028c:	e022                	sd	s0,0(sp)
    8000028e:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000290:	10000793          	li	a5,256
    80000294:	00f50863          	beq	a0,a5,800002a4 <consputc+0x1c>
    uartputc_sync(c);
    80000298:	696000ef          	jal	8000092e <uartputc_sync>
}
    8000029c:	60a2                	ld	ra,8(sp)
    8000029e:	6402                	ld	s0,0(sp)
    800002a0:	0141                	addi	sp,sp,16
    800002a2:	8082                	ret
    uartputc_sync('\b');
    800002a4:	4521                	li	a0,8
    800002a6:	688000ef          	jal	8000092e <uartputc_sync>
    uartputc_sync(' ');
    800002aa:	02000513          	li	a0,32
    800002ae:	680000ef          	jal	8000092e <uartputc_sync>
    uartputc_sync('\b');
    800002b2:	4521                	li	a0,8
    800002b4:	67a000ef          	jal	8000092e <uartputc_sync>
    800002b8:	b7d5                	j	8000029c <consputc+0x14>

00000000800002ba <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ba:	1101                	addi	sp,sp,-32
    800002bc:	ec06                	sd	ra,24(sp)
    800002be:	e822                	sd	s0,16(sp)
    800002c0:	e426                	sd	s1,8(sp)
    800002c2:	1000                	addi	s0,sp,32
    800002c4:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c6:	00013517          	auipc	a0,0x13
    800002ca:	21a50513          	addi	a0,a0,538 # 800134e0 <cons>
    800002ce:	0c3000ef          	jal	80000b90 <acquire>

  switch (c) {
    800002d2:	47d5                	li	a5,21
    800002d4:	08f48f63          	beq	s1,a5,80000372 <consoleintr+0xb8>
    800002d8:	0297c563          	blt	a5,s1,80000302 <consoleintr+0x48>
    800002dc:	47a1                	li	a5,8
    800002de:	0ef48463          	beq	s1,a5,800003c6 <consoleintr+0x10c>
    800002e2:	47c1                	li	a5,16
    800002e4:	10f49563          	bne	s1,a5,800003ee <consoleintr+0x134>
  case C('P'): // Print process list.
    procdump();
    800002e8:	7eb010ef          	jal	800022d2 <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ec:	00013517          	auipc	a0,0x13
    800002f0:	1f450513          	addi	a0,a0,500 # 800134e0 <cons>
    800002f4:	129000ef          	jal	80000c1c <release>
}
    800002f8:	60e2                	ld	ra,24(sp)
    800002fa:	6442                	ld	s0,16(sp)
    800002fc:	64a2                	ld	s1,8(sp)
    800002fe:	6105                	addi	sp,sp,32
    80000300:	8082                	ret
  switch (c) {
    80000302:	07f00793          	li	a5,127
    80000306:	0cf48063          	beq	s1,a5,800003c6 <consoleintr+0x10c>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    8000030a:	00013717          	auipc	a4,0x13
    8000030e:	1d670713          	addi	a4,a4,470 # 800134e0 <cons>
    80000312:	0a072783          	lw	a5,160(a4)
    80000316:	09872703          	lw	a4,152(a4)
    8000031a:	9f99                	subw	a5,a5,a4
    8000031c:	07f00713          	li	a4,127
    80000320:	fcf766e3          	bltu	a4,a5,800002ec <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000324:	47b5                	li	a5,13
    80000326:	0cf48763          	beq	s1,a5,800003f4 <consoleintr+0x13a>
      consputc(c);
    8000032a:	8526                	mv	a0,s1
    8000032c:	f5dff0ef          	jal	80000288 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000330:	00013797          	auipc	a5,0x13
    80000334:	1b078793          	addi	a5,a5,432 # 800134e0 <cons>
    80000338:	0a07a683          	lw	a3,160(a5)
    8000033c:	0016871b          	addiw	a4,a3,1
    80000340:	0007061b          	sext.w	a2,a4
    80000344:	0ae7a023          	sw	a4,160(a5)
    80000348:	07f6f693          	andi	a3,a3,127
    8000034c:	97b6                	add	a5,a5,a3
    8000034e:	00978c23          	sb	s1,24(a5)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000352:	47a9                	li	a5,10
    80000354:	0cf48563          	beq	s1,a5,8000041e <consoleintr+0x164>
    80000358:	4791                	li	a5,4
    8000035a:	0cf48263          	beq	s1,a5,8000041e <consoleintr+0x164>
    8000035e:	00013797          	auipc	a5,0x13
    80000362:	21a7a783          	lw	a5,538(a5) # 80013578 <cons+0x98>
    80000366:	9f1d                	subw	a4,a4,a5
    80000368:	08000793          	li	a5,128
    8000036c:	f8f710e3          	bne	a4,a5,800002ec <consoleintr+0x32>
    80000370:	a07d                	j	8000041e <consoleintr+0x164>
    80000372:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    80000374:	00013717          	auipc	a4,0x13
    80000378:	16c70713          	addi	a4,a4,364 # 800134e0 <cons>
    8000037c:	0a072783          	lw	a5,160(a4)
    80000380:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000384:	00013497          	auipc	s1,0x13
    80000388:	15c48493          	addi	s1,s1,348 # 800134e0 <cons>
    while (cons.e != cons.w &&
    8000038c:	4929                	li	s2,10
    8000038e:	02f70863          	beq	a4,a5,800003be <consoleintr+0x104>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000392:	37fd                	addiw	a5,a5,-1
    80000394:	07f7f713          	andi	a4,a5,127
    80000398:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    8000039a:	01874703          	lbu	a4,24(a4)
    8000039e:	03270263          	beq	a4,s2,800003c2 <consoleintr+0x108>
      cons.e--;
    800003a2:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003a6:	10000513          	li	a0,256
    800003aa:	edfff0ef          	jal	80000288 <consputc>
    while (cons.e != cons.w &&
    800003ae:	0a04a783          	lw	a5,160(s1)
    800003b2:	09c4a703          	lw	a4,156(s1)
    800003b6:	fcf71ee3          	bne	a4,a5,80000392 <consoleintr+0xd8>
    800003ba:	6902                	ld	s2,0(sp)
    800003bc:	bf05                	j	800002ec <consoleintr+0x32>
    800003be:	6902                	ld	s2,0(sp)
    800003c0:	b735                	j	800002ec <consoleintr+0x32>
    800003c2:	6902                	ld	s2,0(sp)
    800003c4:	b725                	j	800002ec <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003c6:	00013717          	auipc	a4,0x13
    800003ca:	11a70713          	addi	a4,a4,282 # 800134e0 <cons>
    800003ce:	0a072783          	lw	a5,160(a4)
    800003d2:	09c72703          	lw	a4,156(a4)
    800003d6:	f0f70be3          	beq	a4,a5,800002ec <consoleintr+0x32>
      cons.e--;
    800003da:	37fd                	addiw	a5,a5,-1
    800003dc:	00013717          	auipc	a4,0x13
    800003e0:	1af72223          	sw	a5,420(a4) # 80013580 <cons+0xa0>
      consputc(BACKSPACE);
    800003e4:	10000513          	li	a0,256
    800003e8:	ea1ff0ef          	jal	80000288 <consputc>
    800003ec:	b701                	j	800002ec <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003ee:	ee048fe3          	beqz	s1,800002ec <consoleintr+0x32>
    800003f2:	bf21                	j	8000030a <consoleintr+0x50>
      consputc(c);
    800003f4:	4529                	li	a0,10
    800003f6:	e93ff0ef          	jal	80000288 <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003fa:	00013797          	auipc	a5,0x13
    800003fe:	0e678793          	addi	a5,a5,230 # 800134e0 <cons>
    80000402:	0a07a703          	lw	a4,160(a5)
    80000406:	0017069b          	addiw	a3,a4,1
    8000040a:	0006861b          	sext.w	a2,a3
    8000040e:	0ad7a023          	sw	a3,160(a5)
    80000412:	07f77713          	andi	a4,a4,127
    80000416:	97ba                	add	a5,a5,a4
    80000418:	4729                	li	a4,10
    8000041a:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000041e:	00013797          	auipc	a5,0x13
    80000422:	14c7af23          	sw	a2,350(a5) # 8001357c <cons+0x9c>
        wakeup(&cons.r);
    80000426:	00013517          	auipc	a0,0x13
    8000042a:	15250513          	addi	a0,a0,338 # 80013578 <cons+0x98>
    8000042e:	2e5010ef          	jal	80001f12 <wakeup>
    80000432:	bd6d                	j	800002ec <consoleintr+0x32>

0000000080000434 <consoleinit>:

void
consoleinit(void)
{
    80000434:	1141                	addi	sp,sp,-16
    80000436:	e406                	sd	ra,8(sp)
    80000438:	e022                	sd	s0,0(sp)
    8000043a:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    8000043c:	00008597          	auipc	a1,0x8
    80000440:	bc458593          	addi	a1,a1,-1084 # 80008000 <etext>
    80000444:	00013517          	auipc	a0,0x13
    80000448:	09c50513          	addi	a0,a0,156 # 800134e0 <cons>
    8000044c:	6ce000ef          	jal	80000b1a <initlock>

  uartinit();
    80000450:	400000ef          	jal	80000850 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000454:	00023797          	auipc	a5,0x23
    80000458:	29478793          	addi	a5,a5,660 # 800236e8 <devsw>
    8000045c:	00000717          	auipc	a4,0x0
    80000460:	d1470713          	addi	a4,a4,-748 # 80000170 <consoleread>
    80000464:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000466:	00000717          	auipc	a4,0x0
    8000046a:	c6c70713          	addi	a4,a4,-916 # 800000d2 <consolewrite>
    8000046e:	ef98                	sd	a4,24(a5)
}
    80000470:	60a2                	ld	ra,8(sp)
    80000472:	6402                	ld	s0,0(sp)
    80000474:	0141                	addi	sp,sp,16
    80000476:	8082                	ret

0000000080000478 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000478:	7139                	addi	sp,sp,-64
    8000047a:	fc06                	sd	ra,56(sp)
    8000047c:	f822                	sd	s0,48(sp)
    8000047e:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    80000480:	c219                	beqz	a2,80000486 <printint+0xe>
    80000482:	08054063          	bltz	a0,80000502 <printint+0x8a>
    x = -xx;
  else
    x = xx;
    80000486:	4881                	li	a7,0
    80000488:	fc840693          	addi	a3,s0,-56

  i = 0;
    8000048c:	4781                	li	a5,0
  do {
    buf[i++] = digits[x % base];
    8000048e:	00008617          	auipc	a2,0x8
    80000492:	45260613          	addi	a2,a2,1106 # 800088e0 <digits>
    80000496:	883e                	mv	a6,a5
    80000498:	2785                	addiw	a5,a5,1
    8000049a:	02b57733          	remu	a4,a0,a1
    8000049e:	9732                	add	a4,a4,a2
    800004a0:	00074703          	lbu	a4,0(a4)
    800004a4:	00e68023          	sb	a4,0(a3)
  } while ((x /= base) != 0);
    800004a8:	872a                	mv	a4,a0
    800004aa:	02b55533          	divu	a0,a0,a1
    800004ae:	0685                	addi	a3,a3,1
    800004b0:	feb773e3          	bgeu	a4,a1,80000496 <printint+0x1e>

  if (sign)
    800004b4:	00088a63          	beqz	a7,800004c8 <printint+0x50>
    buf[i++] = '-';
    800004b8:	1781                	addi	a5,a5,-32
    800004ba:	97a2                	add	a5,a5,s0
    800004bc:	02d00713          	li	a4,45
    800004c0:	fee78423          	sb	a4,-24(a5)
    800004c4:	0028079b          	addiw	a5,a6,2

  while (--i >= 0)
    800004c8:	02f05963          	blez	a5,800004fa <printint+0x82>
    800004cc:	f426                	sd	s1,40(sp)
    800004ce:	f04a                	sd	s2,32(sp)
    800004d0:	fc840713          	addi	a4,s0,-56
    800004d4:	00f704b3          	add	s1,a4,a5
    800004d8:	fff70913          	addi	s2,a4,-1
    800004dc:	993e                	add	s2,s2,a5
    800004de:	37fd                	addiw	a5,a5,-1
    800004e0:	1782                	slli	a5,a5,0x20
    800004e2:	9381                	srli	a5,a5,0x20
    800004e4:	40f90933          	sub	s2,s2,a5
    consputc(buf[i]);
    800004e8:	fff4c503          	lbu	a0,-1(s1)
    800004ec:	d9dff0ef          	jal	80000288 <consputc>
  while (--i >= 0)
    800004f0:	14fd                	addi	s1,s1,-1
    800004f2:	ff249be3          	bne	s1,s2,800004e8 <printint+0x70>
    800004f6:	74a2                	ld	s1,40(sp)
    800004f8:	7902                	ld	s2,32(sp)
}
    800004fa:	70e2                	ld	ra,56(sp)
    800004fc:	7442                	ld	s0,48(sp)
    800004fe:	6121                	addi	sp,sp,64
    80000500:	8082                	ret
    x = -xx;
    80000502:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    80000506:	4885                	li	a7,1
    x = -xx;
    80000508:	b741                	j	80000488 <printint+0x10>

000000008000050a <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    8000050a:	7131                	addi	sp,sp,-192
    8000050c:	fc86                	sd	ra,120(sp)
    8000050e:	f8a2                	sd	s0,112(sp)
    80000510:	e8d2                	sd	s4,80(sp)
    80000512:	0100                	addi	s0,sp,128
    80000514:	8a2a                	mv	s4,a0
    80000516:	e40c                	sd	a1,8(s0)
    80000518:	e810                	sd	a2,16(s0)
    8000051a:	ec14                	sd	a3,24(s0)
    8000051c:	f018                	sd	a4,32(s0)
    8000051e:	f41c                	sd	a5,40(s0)
    80000520:	03043823          	sd	a6,48(s0)
    80000524:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    80000528:	0000b797          	auipc	a5,0xb
    8000052c:	f8c7a783          	lw	a5,-116(a5) # 8000b4b4 <panicking>
    80000530:	c3a1                	beqz	a5,80000570 <printk+0x66>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000532:	00840793          	addi	a5,s0,8
    80000536:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    8000053a:	000a4503          	lbu	a0,0(s4)
    8000053e:	28050763          	beqz	a0,800007cc <printk+0x2c2>
    80000542:	f4a6                	sd	s1,104(sp)
    80000544:	f0ca                	sd	s2,96(sp)
    80000546:	ecce                	sd	s3,88(sp)
    80000548:	e4d6                	sd	s5,72(sp)
    8000054a:	e0da                	sd	s6,64(sp)
    8000054c:	f862                	sd	s8,48(sp)
    8000054e:	f466                	sd	s9,40(sp)
    80000550:	f06a                	sd	s10,32(sp)
    80000552:	ec6e                	sd	s11,24(sp)
    80000554:	4981                	li	s3,0
    if (cx != '%') {
    80000556:	02500a93          	li	s5,37
    c1 = c2 = 0;
    if (c0)
      c1 = fmt[i + 1] & 0xff;
    if (c1)
      c2 = fmt[i + 2] & 0xff;
    if (c0 == 'd') {
    8000055a:	06400b13          	li	s6,100
      printint(va_arg(ap, int), 10, 1);
    } else if (c0 == 'l' && c1 == 'd') {
    8000055e:	06c00c13          	li	s8,108
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    80000562:	07500c93          	li	s9,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    80000566:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    8000056a:	07000d93          	li	s11,112
    8000056e:	a01d                	j	80000594 <printk+0x8a>
    acquire(&pr.lock);
    80000570:	00013517          	auipc	a0,0x13
    80000574:	01850513          	addi	a0,a0,24 # 80013588 <pr>
    80000578:	618000ef          	jal	80000b90 <acquire>
    8000057c:	bf5d                	j	80000532 <printk+0x28>
      consputc(cx);
    8000057e:	d0bff0ef          	jal	80000288 <consputc>
      continue;
    80000582:	84ce                	mv	s1,s3
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000584:	0014899b          	addiw	s3,s1,1
    80000588:	013a07b3          	add	a5,s4,s3
    8000058c:	0007c503          	lbu	a0,0(a5)
    80000590:	20050b63          	beqz	a0,800007a6 <printk+0x29c>
    if (cx != '%') {
    80000594:	ff5515e3          	bne	a0,s5,8000057e <printk+0x74>
    i++;
    80000598:	0019849b          	addiw	s1,s3,1
    c0 = fmt[i + 0] & 0xff;
    8000059c:	009a07b3          	add	a5,s4,s1
    800005a0:	0007c903          	lbu	s2,0(a5)
    if (c0)
    800005a4:	20090b63          	beqz	s2,800007ba <printk+0x2b0>
      c1 = fmt[i + 1] & 0xff;
    800005a8:	0017c783          	lbu	a5,1(a5)
    c1 = c2 = 0;
    800005ac:	86be                	mv	a3,a5
    if (c1)
    800005ae:	c789                	beqz	a5,800005b8 <printk+0xae>
      c2 = fmt[i + 2] & 0xff;
    800005b0:	009a0733          	add	a4,s4,s1
    800005b4:	00274683          	lbu	a3,2(a4)
    if (c0 == 'd') {
    800005b8:	03690963          	beq	s2,s6,800005ea <printk+0xe0>
    } else if (c0 == 'l' && c1 == 'd') {
    800005bc:	05890363          	beq	s2,s8,80000602 <printk+0xf8>
    } else if (c0 == 'u') {
    800005c0:	0d990663          	beq	s2,s9,8000068c <printk+0x182>
    } else if (c0 == 'x') {
    800005c4:	11a90d63          	beq	s2,s10,800006de <printk+0x1d4>
    } else if (c0 == 'p') {
    800005c8:	15b90663          	beq	s2,s11,80000714 <printk+0x20a>
      printptr(va_arg(ap, uint64));
    } else if (c0 == 'c') {
    800005cc:	06300793          	li	a5,99
    800005d0:	18f90563          	beq	s2,a5,8000075a <printk+0x250>
      consputc(va_arg(ap, uint));
    } else if (c0 == 's') {
    800005d4:	07300793          	li	a5,115
    800005d8:	18f90b63          	beq	s2,a5,8000076e <printk+0x264>
      if ((s = va_arg(ap, char *)) == 0)
        s = "(null)";
      for (; *s; s++)
        consputc(*s);
    } else if (c0 == '%') {
    800005dc:	03591b63          	bne	s2,s5,80000612 <printk+0x108>
      consputc('%');
    800005e0:	02500513          	li	a0,37
    800005e4:	ca5ff0ef          	jal	80000288 <consputc>
    800005e8:	bf71                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, int), 10, 1);
    800005ea:	f8843783          	ld	a5,-120(s0)
    800005ee:	00878713          	addi	a4,a5,8
    800005f2:	f8e43423          	sd	a4,-120(s0)
    800005f6:	4605                	li	a2,1
    800005f8:	45a9                	li	a1,10
    800005fa:	4388                	lw	a0,0(a5)
    800005fc:	e7dff0ef          	jal	80000478 <printint>
    80000600:	b751                	j	80000584 <printk+0x7a>
    } else if (c0 == 'l' && c1 == 'd') {
    80000602:	01678f63          	beq	a5,s6,80000620 <printk+0x116>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    80000606:	03878b63          	beq	a5,s8,8000063c <printk+0x132>
    } else if (c0 == 'l' && c1 == 'u') {
    8000060a:	09978e63          	beq	a5,s9,800006a6 <printk+0x19c>
    } else if (c0 == 'l' && c1 == 'x') {
    8000060e:	0fa78563          	beq	a5,s10,800006f8 <printk+0x1ee>
    } else if (c0 == 0) {
      break;
    } else {
      // Print unknown % sequence to draw attention.
      consputc('%');
    80000612:	8556                	mv	a0,s5
    80000614:	c75ff0ef          	jal	80000288 <consputc>
      consputc(c0);
    80000618:	854a                	mv	a0,s2
    8000061a:	c6fff0ef          	jal	80000288 <consputc>
    8000061e:	b79d                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000620:	f8843783          	ld	a5,-120(s0)
    80000624:	00878713          	addi	a4,a5,8
    80000628:	f8e43423          	sd	a4,-120(s0)
    8000062c:	4605                	li	a2,1
    8000062e:	45a9                	li	a1,10
    80000630:	6388                	ld	a0,0(a5)
    80000632:	e47ff0ef          	jal	80000478 <printint>
      i += 1;
    80000636:	0029849b          	addiw	s1,s3,2
    8000063a:	b7a9                	j	80000584 <printk+0x7a>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    8000063c:	06400793          	li	a5,100
    80000640:	02f68863          	beq	a3,a5,80000670 <printk+0x166>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    80000644:	07500793          	li	a5,117
    80000648:	06f68d63          	beq	a3,a5,800006c2 <printk+0x1b8>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    8000064c:	07800793          	li	a5,120
    80000650:	fcf691e3          	bne	a3,a5,80000612 <printk+0x108>
      printint(va_arg(ap, uint64), 16, 0);
    80000654:	f8843783          	ld	a5,-120(s0)
    80000658:	00878713          	addi	a4,a5,8
    8000065c:	f8e43423          	sd	a4,-120(s0)
    80000660:	4601                	li	a2,0
    80000662:	45c1                	li	a1,16
    80000664:	6388                	ld	a0,0(a5)
    80000666:	e13ff0ef          	jal	80000478 <printint>
      i += 2;
    8000066a:	0039849b          	addiw	s1,s3,3
    8000066e:	bf19                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 1);
    80000670:	f8843783          	ld	a5,-120(s0)
    80000674:	00878713          	addi	a4,a5,8
    80000678:	f8e43423          	sd	a4,-120(s0)
    8000067c:	4605                	li	a2,1
    8000067e:	45a9                	li	a1,10
    80000680:	6388                	ld	a0,0(a5)
    80000682:	df7ff0ef          	jal	80000478 <printint>
      i += 2;
    80000686:	0039849b          	addiw	s1,s3,3
    8000068a:	bded                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint32), 10, 0);
    8000068c:	f8843783          	ld	a5,-120(s0)
    80000690:	00878713          	addi	a4,a5,8
    80000694:	f8e43423          	sd	a4,-120(s0)
    80000698:	4601                	li	a2,0
    8000069a:	45a9                	li	a1,10
    8000069c:	0007e503          	lwu	a0,0(a5)
    800006a0:	dd9ff0ef          	jal	80000478 <printint>
    800006a4:	b5c5                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006a6:	f8843783          	ld	a5,-120(s0)
    800006aa:	00878713          	addi	a4,a5,8
    800006ae:	f8e43423          	sd	a4,-120(s0)
    800006b2:	4601                	li	a2,0
    800006b4:	45a9                	li	a1,10
    800006b6:	6388                	ld	a0,0(a5)
    800006b8:	dc1ff0ef          	jal	80000478 <printint>
      i += 1;
    800006bc:	0029849b          	addiw	s1,s3,2
    800006c0:	b5d1                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 10, 0);
    800006c2:	f8843783          	ld	a5,-120(s0)
    800006c6:	00878713          	addi	a4,a5,8
    800006ca:	f8e43423          	sd	a4,-120(s0)
    800006ce:	4601                	li	a2,0
    800006d0:	45a9                	li	a1,10
    800006d2:	6388                	ld	a0,0(a5)
    800006d4:	da5ff0ef          	jal	80000478 <printint>
      i += 2;
    800006d8:	0039849b          	addiw	s1,s3,3
    800006dc:	b565                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint32), 16, 0);
    800006de:	f8843783          	ld	a5,-120(s0)
    800006e2:	00878713          	addi	a4,a5,8
    800006e6:	f8e43423          	sd	a4,-120(s0)
    800006ea:	4601                	li	a2,0
    800006ec:	45c1                	li	a1,16
    800006ee:	0007e503          	lwu	a0,0(a5)
    800006f2:	d87ff0ef          	jal	80000478 <printint>
    800006f6:	b579                	j	80000584 <printk+0x7a>
      printint(va_arg(ap, uint64), 16, 0);
    800006f8:	f8843783          	ld	a5,-120(s0)
    800006fc:	00878713          	addi	a4,a5,8
    80000700:	f8e43423          	sd	a4,-120(s0)
    80000704:	4601                	li	a2,0
    80000706:	45c1                	li	a1,16
    80000708:	6388                	ld	a0,0(a5)
    8000070a:	d6fff0ef          	jal	80000478 <printint>
      i += 1;
    8000070e:	0029849b          	addiw	s1,s3,2
    80000712:	bd8d                	j	80000584 <printk+0x7a>
    80000714:	fc5e                	sd	s7,56(sp)
      printptr(va_arg(ap, uint64));
    80000716:	f8843783          	ld	a5,-120(s0)
    8000071a:	00878713          	addi	a4,a5,8
    8000071e:	f8e43423          	sd	a4,-120(s0)
    80000722:	0007b983          	ld	s3,0(a5)
  consputc('0');
    80000726:	03000513          	li	a0,48
    8000072a:	b5fff0ef          	jal	80000288 <consputc>
  consputc('x');
    8000072e:	07800513          	li	a0,120
    80000732:	b57ff0ef          	jal	80000288 <consputc>
    80000736:	4941                	li	s2,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    80000738:	00008b97          	auipc	s7,0x8
    8000073c:	1a8b8b93          	addi	s7,s7,424 # 800088e0 <digits>
    80000740:	03c9d793          	srli	a5,s3,0x3c
    80000744:	97de                	add	a5,a5,s7
    80000746:	0007c503          	lbu	a0,0(a5)
    8000074a:	b3fff0ef          	jal	80000288 <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    8000074e:	0992                	slli	s3,s3,0x4
    80000750:	397d                	addiw	s2,s2,-1
    80000752:	fe0917e3          	bnez	s2,80000740 <printk+0x236>
    80000756:	7be2                	ld	s7,56(sp)
    80000758:	b535                	j	80000584 <printk+0x7a>
      consputc(va_arg(ap, uint));
    8000075a:	f8843783          	ld	a5,-120(s0)
    8000075e:	00878713          	addi	a4,a5,8
    80000762:	f8e43423          	sd	a4,-120(s0)
    80000766:	4388                	lw	a0,0(a5)
    80000768:	b21ff0ef          	jal	80000288 <consputc>
    8000076c:	bd21                	j	80000584 <printk+0x7a>
      if ((s = va_arg(ap, char *)) == 0)
    8000076e:	f8843783          	ld	a5,-120(s0)
    80000772:	00878713          	addi	a4,a5,8
    80000776:	f8e43423          	sd	a4,-120(s0)
    8000077a:	0007b903          	ld	s2,0(a5)
    8000077e:	00090d63          	beqz	s2,80000798 <printk+0x28e>
      for (; *s; s++)
    80000782:	00094503          	lbu	a0,0(s2)
    80000786:	de050fe3          	beqz	a0,80000584 <printk+0x7a>
        consputc(*s);
    8000078a:	affff0ef          	jal	80000288 <consputc>
      for (; *s; s++)
    8000078e:	0905                	addi	s2,s2,1
    80000790:	00094503          	lbu	a0,0(s2)
    80000794:	f97d                	bnez	a0,8000078a <printk+0x280>
    80000796:	b3fd                	j	80000584 <printk+0x7a>
        s = "(null)";
    80000798:	00008917          	auipc	s2,0x8
    8000079c:	87090913          	addi	s2,s2,-1936 # 80008008 <etext+0x8>
      for (; *s; s++)
    800007a0:	02800513          	li	a0,40
    800007a4:	b7dd                	j	8000078a <printk+0x280>
    800007a6:	74a6                	ld	s1,104(sp)
    800007a8:	7906                	ld	s2,96(sp)
    800007aa:	69e6                	ld	s3,88(sp)
    800007ac:	6aa6                	ld	s5,72(sp)
    800007ae:	6b06                	ld	s6,64(sp)
    800007b0:	7c42                	ld	s8,48(sp)
    800007b2:	7ca2                	ld	s9,40(sp)
    800007b4:	7d02                	ld	s10,32(sp)
    800007b6:	6de2                	ld	s11,24(sp)
    800007b8:	a811                	j	800007cc <printk+0x2c2>
    800007ba:	74a6                	ld	s1,104(sp)
    800007bc:	7906                	ld	s2,96(sp)
    800007be:	69e6                	ld	s3,88(sp)
    800007c0:	6aa6                	ld	s5,72(sp)
    800007c2:	6b06                	ld	s6,64(sp)
    800007c4:	7c42                	ld	s8,48(sp)
    800007c6:	7ca2                	ld	s9,40(sp)
    800007c8:	7d02                	ld	s10,32(sp)
    800007ca:	6de2                	ld	s11,24(sp)
    }
  }
  va_end(ap);

  if (panicking == 0)
    800007cc:	0000b797          	auipc	a5,0xb
    800007d0:	ce87a783          	lw	a5,-792(a5) # 8000b4b4 <panicking>
    800007d4:	c799                	beqz	a5,800007e2 <printk+0x2d8>
    release(&pr.lock);

  return 0;
}
    800007d6:	4501                	li	a0,0
    800007d8:	70e6                	ld	ra,120(sp)
    800007da:	7446                	ld	s0,112(sp)
    800007dc:	6a46                	ld	s4,80(sp)
    800007de:	6129                	addi	sp,sp,192
    800007e0:	8082                	ret
    release(&pr.lock);
    800007e2:	00013517          	auipc	a0,0x13
    800007e6:	da650513          	addi	a0,a0,-602 # 80013588 <pr>
    800007ea:	432000ef          	jal	80000c1c <release>
  return 0;
    800007ee:	b7e5                	j	800007d6 <printk+0x2cc>

00000000800007f0 <panic>:

void
panic(char *s)
{
    800007f0:	1101                	addi	sp,sp,-32
    800007f2:	ec06                	sd	ra,24(sp)
    800007f4:	e822                	sd	s0,16(sp)
    800007f6:	e426                	sd	s1,8(sp)
    800007f8:	e04a                	sd	s2,0(sp)
    800007fa:	1000                	addi	s0,sp,32
    800007fc:	84aa                	mv	s1,a0
  panicking = 1;
    800007fe:	4905                	li	s2,1
    80000800:	0000b797          	auipc	a5,0xb
    80000804:	cb27aa23          	sw	s2,-844(a5) # 8000b4b4 <panicking>
  printk("panic: ");
    80000808:	00008517          	auipc	a0,0x8
    8000080c:	81050513          	addi	a0,a0,-2032 # 80008018 <etext+0x18>
    80000810:	cfbff0ef          	jal	8000050a <printk>
  printk("%s\n", s);
    80000814:	85a6                	mv	a1,s1
    80000816:	00008517          	auipc	a0,0x8
    8000081a:	80a50513          	addi	a0,a0,-2038 # 80008020 <etext+0x20>
    8000081e:	cedff0ef          	jal	8000050a <printk>
  panicked = 1; // freeze uart output from other CPUs
    80000822:	0000b797          	auipc	a5,0xb
    80000826:	c927a723          	sw	s2,-882(a5) # 8000b4b0 <panicked>
  for (;;)
    8000082a:	a001                	j	8000082a <panic+0x3a>

000000008000082c <printkinit>:
    ;
}

void
printkinit(void)
{
    8000082c:	1141                	addi	sp,sp,-16
    8000082e:	e406                	sd	ra,8(sp)
    80000830:	e022                	sd	s0,0(sp)
    80000832:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000834:	00007597          	auipc	a1,0x7
    80000838:	7f458593          	addi	a1,a1,2036 # 80008028 <etext+0x28>
    8000083c:	00013517          	auipc	a0,0x13
    80000840:	d4c50513          	addi	a0,a0,-692 # 80013588 <pr>
    80000844:	2d6000ef          	jal	80000b1a <initlock>
}
    80000848:	60a2                	ld	ra,8(sp)
    8000084a:	6402                	ld	s0,0(sp)
    8000084c:	0141                	addi	sp,sp,16
    8000084e:	8082                	ret

0000000080000850 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    80000850:	1141                	addi	sp,sp,-16
    80000852:	e406                	sd	ra,8(sp)
    80000854:	e022                	sd	s0,0(sp)
    80000856:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000858:	100007b7          	lui	a5,0x10000
    8000085c:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000860:	10000737          	lui	a4,0x10000
    80000864:	f8000693          	li	a3,-128
    80000868:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    8000086c:	468d                	li	a3,3
    8000086e:	10000637          	lui	a2,0x10000
    80000872:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    80000876:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    8000087a:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    8000087e:	10000737          	lui	a4,0x10000
    80000882:	461d                	li	a2,7
    80000884:	00c70123          	sb	a2,2(a4) # 10000002 <_entry-0x6ffffffe>

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    80000888:	00d780a3          	sb	a3,1(a5)

  initsleeplock(&tx_lock, "uart");
    8000088c:	00007597          	auipc	a1,0x7
    80000890:	7a458593          	addi	a1,a1,1956 # 80008030 <etext+0x30>
    80000894:	00013517          	auipc	a0,0x13
    80000898:	d0c50513          	addi	a0,a0,-756 # 800135a0 <tx_lock>
    8000089c:	44b030ef          	jal	800044e6 <initsleeplock>
}
    800008a0:	60a2                	ld	ra,8(sp)
    800008a2:	6402                	ld	s0,0(sp)
    800008a4:	0141                	addi	sp,sp,16
    800008a6:	8082                	ret

00000000800008a8 <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008a8:	7139                	addi	sp,sp,-64
    800008aa:	fc06                	sd	ra,56(sp)
    800008ac:	f822                	sd	s0,48(sp)
    800008ae:	f04a                	sd	s2,32(sp)
    800008b0:	e456                	sd	s5,8(sp)
    800008b2:	0080                	addi	s0,sp,64
    800008b4:	8aaa                	mv	s5,a0
    800008b6:	892e                	mv	s2,a1
  acquiresleep(&tx_lock);
    800008b8:	00013517          	auipc	a0,0x13
    800008bc:	ce850513          	addi	a0,a0,-792 # 800135a0 <tx_lock>
    800008c0:	45d030ef          	jal	8000451c <acquiresleep>

  int i = 0;
  while (i < n) {
    800008c4:	05205963          	blez	s2,80000916 <uartwrite+0x6e>
    800008c8:	f426                	sd	s1,40(sp)
    800008ca:	ec4e                	sd	s3,24(sp)
    800008cc:	e852                	sd	s4,16(sp)
    800008ce:	e05a                	sd	s6,0(sp)
  int i = 0;
    800008d0:	4481                	li	s1,0
    sleep_prepare(&tx_chan);
    800008d2:	0000ba17          	auipc	s4,0xb
    800008d6:	be6a0a13          	addi	s4,s4,-1050 # 8000b4b8 <tx_chan>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    800008da:	100009b7          	lui	s3,0x10000
    800008de:	0995                	addi	s3,s3,5 # 10000005 <_entry-0x6ffffffb>
      WriteReg(THR, buf[i]);
    800008e0:	10000b37          	lui	s6,0x10000
    800008e4:	a811                	j	800008f8 <uartwrite+0x50>
    800008e6:	009a87b3          	add	a5,s5,s1
    800008ea:	0007c783          	lbu	a5,0(a5)
    800008ee:	00fb0023          	sb	a5,0(s6) # 10000000 <_entry-0x70000000>
      i += 1;
    800008f2:	2485                	addiw	s1,s1,1
  while (i < n) {
    800008f4:	0124dd63          	bge	s1,s2,8000090e <uartwrite+0x66>
    sleep_prepare(&tx_chan);
    800008f8:	8552                	mv	a0,s4
    800008fa:	5ac010ef          	jal	80001ea6 <sleep_prepare>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    800008fe:	0009c783          	lbu	a5,0(s3)
    80000902:	0207f793          	andi	a5,a5,32
    80000906:	f3e5                	bnez	a5,800008e6 <uartwrite+0x3e>
    } else {
      sleep();
    80000908:	5da010ef          	jal	80001ee2 <sleep>
    8000090c:	b7e5                	j	800008f4 <uartwrite+0x4c>
    8000090e:	74a2                	ld	s1,40(sp)
    80000910:	69e2                	ld	s3,24(sp)
    80000912:	6a42                	ld	s4,16(sp)
    80000914:	6b02                	ld	s6,0(sp)
    }
  }

  releasesleep(&tx_lock);
    80000916:	00013517          	auipc	a0,0x13
    8000091a:	c8a50513          	addi	a0,a0,-886 # 800135a0 <tx_lock>
    8000091e:	453030ef          	jal	80004570 <releasesleep>
}
    80000922:	70e2                	ld	ra,56(sp)
    80000924:	7442                	ld	s0,48(sp)
    80000926:	7902                	ld	s2,32(sp)
    80000928:	6aa2                	ld	s5,8(sp)
    8000092a:	6121                	addi	sp,sp,64
    8000092c:	8082                	ret

000000008000092e <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000092e:	1101                	addi	sp,sp,-32
    80000930:	ec06                	sd	ra,24(sp)
    80000932:	e822                	sd	s0,16(sp)
    80000934:	e426                	sd	s1,8(sp)
    80000936:	1000                	addi	s0,sp,32
    80000938:	84aa                	mv	s1,a0
  if (panicking == 0)
    8000093a:	0000b797          	auipc	a5,0xb
    8000093e:	b7a7a783          	lw	a5,-1158(a5) # 8000b4b4 <panicking>
    80000942:	cf95                	beqz	a5,8000097e <uartputc_sync+0x50>
    push_off();

  if (panicked) {
    80000944:	0000b797          	auipc	a5,0xb
    80000948:	b6c7a783          	lw	a5,-1172(a5) # 8000b4b0 <panicked>
    8000094c:	ef85                	bnez	a5,80000984 <uartputc_sync+0x56>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000094e:	10000737          	lui	a4,0x10000
    80000952:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000954:	00074783          	lbu	a5,0(a4)
    80000958:	0207f793          	andi	a5,a5,32
    8000095c:	dfe5                	beqz	a5,80000954 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000095e:	0ff4f513          	zext.b	a0,s1
    80000962:	100007b7          	lui	a5,0x10000
    80000966:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    8000096a:	0000b797          	auipc	a5,0xb
    8000096e:	b4a7a783          	lw	a5,-1206(a5) # 8000b4b4 <panicking>
    80000972:	cb91                	beqz	a5,80000986 <uartputc_sync+0x58>
    pop_off();
}
    80000974:	60e2                	ld	ra,24(sp)
    80000976:	6442                	ld	s0,16(sp)
    80000978:	64a2                	ld	s1,8(sp)
    8000097a:	6105                	addi	sp,sp,32
    8000097c:	8082                	ret
    push_off();
    8000097e:	1dc000ef          	jal	80000b5a <push_off>
    80000982:	b7c9                	j	80000944 <uartputc_sync+0x16>
    for (;;)
    80000984:	a001                	j	80000984 <uartputc_sync+0x56>
    pop_off();
    80000986:	24a000ef          	jal	80000bd0 <pop_off>
}
    8000098a:	b7ed                	j	80000974 <uartputc_sync+0x46>

000000008000098c <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    8000098c:	1101                	addi	sp,sp,-32
    8000098e:	ec06                	sd	ra,24(sp)
    80000990:	e822                	sd	s0,16(sp)
    80000992:	e426                	sd	s1,8(sp)
    80000994:	e04a                	sd	s2,0(sp)
    80000996:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    80000998:	100007b7          	lui	a5,0x10000
    8000099c:	0789                	addi	a5,a5,2 # 10000002 <_entry-0x6ffffffe>
    8000099e:	0007c783          	lbu	a5,0(a5)

  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009a2:	100007b7          	lui	a5,0x10000
    800009a6:	0795                	addi	a5,a5,5 # 10000005 <_entry-0x6ffffffb>
    800009a8:	0007c783          	lbu	a5,0(a5)
    800009ac:	0207f793          	andi	a5,a5,32
    800009b0:	ef99                	bnez	a5,800009ce <uartintr+0x42>
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009b2:	100004b7          	lui	s1,0x10000
    800009b6:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    800009b8:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009bc:	0004c783          	lbu	a5,0(s1)
    800009c0:	8b85                	andi	a5,a5,1
    800009c2:	cf89                	beqz	a5,800009dc <uartintr+0x50>
    return ReadReg(RHR);
    800009c4:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    800009c8:	8f3ff0ef          	jal	800002ba <consoleintr>
  while (1) {
    800009cc:	bfc5                	j	800009bc <uartintr+0x30>
    wakeup(&tx_chan);
    800009ce:	0000b517          	auipc	a0,0xb
    800009d2:	aea50513          	addi	a0,a0,-1302 # 8000b4b8 <tx_chan>
    800009d6:	53c010ef          	jal	80001f12 <wakeup>
    800009da:	bfe1                	j	800009b2 <uartintr+0x26>
  }
}
    800009dc:	60e2                	ld	ra,24(sp)
    800009de:	6442                	ld	s0,16(sp)
    800009e0:	64a2                	ld	s1,8(sp)
    800009e2:	6902                	ld	s2,0(sp)
    800009e4:	6105                	addi	sp,sp,32
    800009e6:	8082                	ret

00000000800009e8 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    800009e8:	1101                	addi	sp,sp,-32
    800009ea:	ec06                	sd	ra,24(sp)
    800009ec:	e822                	sd	s0,16(sp)
    800009ee:	e426                	sd	s1,8(sp)
    800009f0:	e04a                	sd	s2,0(sp)
    800009f2:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    800009f4:	03451793          	slli	a5,a0,0x34
    800009f8:	e7a9                	bnez	a5,80000a42 <kfree+0x5a>
    800009fa:	84aa                	mv	s1,a0
    800009fc:	00024797          	auipc	a5,0x24
    80000a00:	e8478793          	addi	a5,a5,-380 # 80024880 <end>
    80000a04:	02f56f63          	bltu	a0,a5,80000a42 <kfree+0x5a>
    80000a08:	47c5                	li	a5,17
    80000a0a:	07ee                	slli	a5,a5,0x1b
    80000a0c:	02f57b63          	bgeu	a0,a5,80000a42 <kfree+0x5a>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a10:	6605                	lui	a2,0x1
    80000a12:	4585                	li	a1,1
    80000a14:	240000ef          	jal	80000c54 <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a18:	00013917          	auipc	s2,0x13
    80000a1c:	bb890913          	addi	s2,s2,-1096 # 800135d0 <kmem>
    80000a20:	854a                	mv	a0,s2
    80000a22:	16e000ef          	jal	80000b90 <acquire>
  r->next = kmem.freelist;
    80000a26:	01893783          	ld	a5,24(s2)
    80000a2a:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a2c:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a30:	854a                	mv	a0,s2
    80000a32:	1ea000ef          	jal	80000c1c <release>
}
    80000a36:	60e2                	ld	ra,24(sp)
    80000a38:	6442                	ld	s0,16(sp)
    80000a3a:	64a2                	ld	s1,8(sp)
    80000a3c:	6902                	ld	s2,0(sp)
    80000a3e:	6105                	addi	sp,sp,32
    80000a40:	8082                	ret
    panic("kfree");
    80000a42:	00007517          	auipc	a0,0x7
    80000a46:	5f650513          	addi	a0,a0,1526 # 80008038 <etext+0x38>
    80000a4a:	da7ff0ef          	jal	800007f0 <panic>

0000000080000a4e <freerange>:
{
    80000a4e:	7179                	addi	sp,sp,-48
    80000a50:	f406                	sd	ra,40(sp)
    80000a52:	f022                	sd	s0,32(sp)
    80000a54:	ec26                	sd	s1,24(sp)
    80000a56:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000a58:	6785                	lui	a5,0x1
    80000a5a:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000a5e:	00e504b3          	add	s1,a0,a4
    80000a62:	777d                	lui	a4,0xfffff
    80000a64:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a66:	94be                	add	s1,s1,a5
    80000a68:	0295e263          	bltu	a1,s1,80000a8c <freerange+0x3e>
    80000a6c:	e84a                	sd	s2,16(sp)
    80000a6e:	e44e                	sd	s3,8(sp)
    80000a70:	e052                	sd	s4,0(sp)
    80000a72:	892e                	mv	s2,a1
    kfree(p);
    80000a74:	7a7d                	lui	s4,0xfffff
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a76:	6985                	lui	s3,0x1
    kfree(p);
    80000a78:	01448533          	add	a0,s1,s4
    80000a7c:	f6dff0ef          	jal	800009e8 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000a80:	94ce                	add	s1,s1,s3
    80000a82:	fe997be3          	bgeu	s2,s1,80000a78 <freerange+0x2a>
    80000a86:	6942                	ld	s2,16(sp)
    80000a88:	69a2                	ld	s3,8(sp)
    80000a8a:	6a02                	ld	s4,0(sp)
}
    80000a8c:	70a2                	ld	ra,40(sp)
    80000a8e:	7402                	ld	s0,32(sp)
    80000a90:	64e2                	ld	s1,24(sp)
    80000a92:	6145                	addi	sp,sp,48
    80000a94:	8082                	ret

0000000080000a96 <kinit>:
{
    80000a96:	1141                	addi	sp,sp,-16
    80000a98:	e406                	sd	ra,8(sp)
    80000a9a:	e022                	sd	s0,0(sp)
    80000a9c:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000a9e:	00007597          	auipc	a1,0x7
    80000aa2:	5a258593          	addi	a1,a1,1442 # 80008040 <etext+0x40>
    80000aa6:	00013517          	auipc	a0,0x13
    80000aaa:	b2a50513          	addi	a0,a0,-1238 # 800135d0 <kmem>
    80000aae:	06c000ef          	jal	80000b1a <initlock>
  freerange(end, (void *)PHYSTOP);
    80000ab2:	45c5                	li	a1,17
    80000ab4:	05ee                	slli	a1,a1,0x1b
    80000ab6:	00024517          	auipc	a0,0x24
    80000aba:	dca50513          	addi	a0,a0,-566 # 80024880 <end>
    80000abe:	f91ff0ef          	jal	80000a4e <freerange>
}
    80000ac2:	60a2                	ld	ra,8(sp)
    80000ac4:	6402                	ld	s0,0(sp)
    80000ac6:	0141                	addi	sp,sp,16
    80000ac8:	8082                	ret

0000000080000aca <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000aca:	1101                	addi	sp,sp,-32
    80000acc:	ec06                	sd	ra,24(sp)
    80000ace:	e822                	sd	s0,16(sp)
    80000ad0:	e426                	sd	s1,8(sp)
    80000ad2:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000ad4:	00013497          	auipc	s1,0x13
    80000ad8:	afc48493          	addi	s1,s1,-1284 # 800135d0 <kmem>
    80000adc:	8526                	mv	a0,s1
    80000ade:	0b2000ef          	jal	80000b90 <acquire>
  r = kmem.freelist;
    80000ae2:	6c84                	ld	s1,24(s1)
  if (r)
    80000ae4:	c485                	beqz	s1,80000b0c <kalloc+0x42>
    kmem.freelist = r->next;
    80000ae6:	609c                	ld	a5,0(s1)
    80000ae8:	00013517          	auipc	a0,0x13
    80000aec:	ae850513          	addi	a0,a0,-1304 # 800135d0 <kmem>
    80000af0:	ed1c                	sd	a5,24(a0)
  release(&kmem.lock);
    80000af2:	12a000ef          	jal	80000c1c <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000af6:	6605                	lui	a2,0x1
    80000af8:	4595                	li	a1,5
    80000afa:	8526                	mv	a0,s1
    80000afc:	158000ef          	jal	80000c54 <memset>
  return (void *)r;
}
    80000b00:	8526                	mv	a0,s1
    80000b02:	60e2                	ld	ra,24(sp)
    80000b04:	6442                	ld	s0,16(sp)
    80000b06:	64a2                	ld	s1,8(sp)
    80000b08:	6105                	addi	sp,sp,32
    80000b0a:	8082                	ret
  release(&kmem.lock);
    80000b0c:	00013517          	auipc	a0,0x13
    80000b10:	ac450513          	addi	a0,a0,-1340 # 800135d0 <kmem>
    80000b14:	108000ef          	jal	80000c1c <release>
  if (r)
    80000b18:	b7e5                	j	80000b00 <kalloc+0x36>

0000000080000b1a <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b1a:	1141                	addi	sp,sp,-16
    80000b1c:	e422                	sd	s0,8(sp)
    80000b1e:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b20:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b22:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b26:	00053823          	sd	zero,16(a0)
}
    80000b2a:	6422                	ld	s0,8(sp)
    80000b2c:	0141                	addi	sp,sp,16
    80000b2e:	8082                	ret

0000000080000b30 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b30:	411c                	lw	a5,0(a0)
    80000b32:	e399                	bnez	a5,80000b38 <holding+0x8>
    80000b34:	4501                	li	a0,0
  return r;
}
    80000b36:	8082                	ret
{
    80000b38:	1101                	addi	sp,sp,-32
    80000b3a:	ec06                	sd	ra,24(sp)
    80000b3c:	e822                	sd	s0,16(sp)
    80000b3e:	e426                	sd	s1,8(sp)
    80000b40:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b42:	6904                	ld	s1,16(a0)
    80000b44:	543000ef          	jal	80001886 <mycpu>
    80000b48:	40a48533          	sub	a0,s1,a0
    80000b4c:	00153513          	seqz	a0,a0
}
    80000b50:	60e2                	ld	ra,24(sp)
    80000b52:	6442                	ld	s0,16(sp)
    80000b54:	64a2                	ld	s1,8(sp)
    80000b56:	6105                	addi	sp,sp,32
    80000b58:	8082                	ret

0000000080000b5a <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000b5a:	1101                	addi	sp,sp,-32
    80000b5c:	ec06                	sd	ra,24(sp)
    80000b5e:	e822                	sd	s0,16(sp)
    80000b60:	e426                	sd	s1,8(sp)
    80000b62:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000b64:	100174f3          	csrrci	s1,sstatus,2
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000b68:	51f000ef          	jal	80001886 <mycpu>
    80000b6c:	5d3c                	lw	a5,120(a0)
    80000b6e:	cb99                	beqz	a5,80000b84 <push_off+0x2a>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000b70:	517000ef          	jal	80001886 <mycpu>
    80000b74:	5d3c                	lw	a5,120(a0)
    80000b76:	2785                	addiw	a5,a5,1
    80000b78:	dd3c                	sw	a5,120(a0)
}
    80000b7a:	60e2                	ld	ra,24(sp)
    80000b7c:	6442                	ld	s0,16(sp)
    80000b7e:	64a2                	ld	s1,8(sp)
    80000b80:	6105                	addi	sp,sp,32
    80000b82:	8082                	ret
    mycpu()->intena = old;
    80000b84:	503000ef          	jal	80001886 <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000b88:	8085                	srli	s1,s1,0x1
    80000b8a:	8885                	andi	s1,s1,1
    mycpu()->intena = old;
    80000b8c:	dd64                	sw	s1,124(a0)
    80000b8e:	b7cd                	j	80000b70 <push_off+0x16>

0000000080000b90 <acquire>:
{
    80000b90:	1101                	addi	sp,sp,-32
    80000b92:	ec06                	sd	ra,24(sp)
    80000b94:	e822                	sd	s0,16(sp)
    80000b96:	e426                	sd	s1,8(sp)
    80000b98:	1000                	addi	s0,sp,32
    80000b9a:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000b9c:	fbfff0ef          	jal	80000b5a <push_off>
  if (holding(lk))
    80000ba0:	8526                	mv	a0,s1
    80000ba2:	f8fff0ef          	jal	80000b30 <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000ba6:	4705                	li	a4,1
  if (holding(lk))
    80000ba8:	ed11                	bnez	a0,80000bc4 <acquire+0x34>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000baa:	87ba                	mv	a5,a4
    80000bac:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000bb0:	2781                	sext.w	a5,a5
    80000bb2:	ffe5                	bnez	a5,80000baa <acquire+0x1a>
  lk->cpu = mycpu();
    80000bb4:	4d3000ef          	jal	80001886 <mycpu>
    80000bb8:	e888                	sd	a0,16(s1)
}
    80000bba:	60e2                	ld	ra,24(sp)
    80000bbc:	6442                	ld	s0,16(sp)
    80000bbe:	64a2                	ld	s1,8(sp)
    80000bc0:	6105                	addi	sp,sp,32
    80000bc2:	8082                	ret
    panic("acquire");
    80000bc4:	00007517          	auipc	a0,0x7
    80000bc8:	48450513          	addi	a0,a0,1156 # 80008048 <etext+0x48>
    80000bcc:	c25ff0ef          	jal	800007f0 <panic>

0000000080000bd0 <pop_off>:

void
pop_off(void)
{
    80000bd0:	1141                	addi	sp,sp,-16
    80000bd2:	e406                	sd	ra,8(sp)
    80000bd4:	e022                	sd	s0,0(sp)
    80000bd6:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000bd8:	4af000ef          	jal	80001886 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000bdc:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000be0:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000be2:	e38d                	bnez	a5,80000c04 <pop_off+0x34>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000be4:	5d3c                	lw	a5,120(a0)
    80000be6:	02f05563          	blez	a5,80000c10 <pop_off+0x40>
    panic("pop_off");
  c->noff -= 1;
    80000bea:	37fd                	addiw	a5,a5,-1
    80000bec:	0007871b          	sext.w	a4,a5
    80000bf0:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000bf2:	e709                	bnez	a4,80000bfc <pop_off+0x2c>
    80000bf4:	5d7c                	lw	a5,124(a0)
    80000bf6:	c399                	beqz	a5,80000bfc <pop_off+0x2c>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000bf8:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000bfc:	60a2                	ld	ra,8(sp)
    80000bfe:	6402                	ld	s0,0(sp)
    80000c00:	0141                	addi	sp,sp,16
    80000c02:	8082                	ret
    panic("pop_off - interruptible");
    80000c04:	00007517          	auipc	a0,0x7
    80000c08:	44c50513          	addi	a0,a0,1100 # 80008050 <etext+0x50>
    80000c0c:	be5ff0ef          	jal	800007f0 <panic>
    panic("pop_off");
    80000c10:	00007517          	auipc	a0,0x7
    80000c14:	45850513          	addi	a0,a0,1112 # 80008068 <etext+0x68>
    80000c18:	bd9ff0ef          	jal	800007f0 <panic>

0000000080000c1c <release>:
{
    80000c1c:	1101                	addi	sp,sp,-32
    80000c1e:	ec06                	sd	ra,24(sp)
    80000c20:	e822                	sd	s0,16(sp)
    80000c22:	e426                	sd	s1,8(sp)
    80000c24:	1000                	addi	s0,sp,32
    80000c26:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000c28:	f09ff0ef          	jal	80000b30 <holding>
    80000c2c:	cd11                	beqz	a0,80000c48 <release+0x2c>
  lk->cpu = 0;
    80000c2e:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000c32:	0310000f          	fence	rw,w
    80000c36:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000c3a:	f97ff0ef          	jal	80000bd0 <pop_off>
}
    80000c3e:	60e2                	ld	ra,24(sp)
    80000c40:	6442                	ld	s0,16(sp)
    80000c42:	64a2                	ld	s1,8(sp)
    80000c44:	6105                	addi	sp,sp,32
    80000c46:	8082                	ret
    panic("release");
    80000c48:	00007517          	auipc	a0,0x7
    80000c4c:	42850513          	addi	a0,a0,1064 # 80008070 <etext+0x70>
    80000c50:	ba1ff0ef          	jal	800007f0 <panic>

0000000080000c54 <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000c54:	1141                	addi	sp,sp,-16
    80000c56:	e422                	sd	s0,8(sp)
    80000c58:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000c5a:	ca19                	beqz	a2,80000c70 <memset+0x1c>
    80000c5c:	87aa                	mv	a5,a0
    80000c5e:	1602                	slli	a2,a2,0x20
    80000c60:	9201                	srli	a2,a2,0x20
    80000c62:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000c66:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000c6a:	0785                	addi	a5,a5,1
    80000c6c:	fee79de3          	bne	a5,a4,80000c66 <memset+0x12>
  }
  return dst;
}
    80000c70:	6422                	ld	s0,8(sp)
    80000c72:	0141                	addi	sp,sp,16
    80000c74:	8082                	ret

0000000080000c76 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000c76:	1141                	addi	sp,sp,-16
    80000c78:	e422                	sd	s0,8(sp)
    80000c7a:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000c7c:	ca05                	beqz	a2,80000cac <memcmp+0x36>
    80000c7e:	fff6069b          	addiw	a3,a2,-1 # fff <_entry-0x7ffff001>
    80000c82:	1682                	slli	a3,a3,0x20
    80000c84:	9281                	srli	a3,a3,0x20
    80000c86:	0685                	addi	a3,a3,1
    80000c88:	96aa                	add	a3,a3,a0
    if (*s1 != *s2)
    80000c8a:	00054783          	lbu	a5,0(a0)
    80000c8e:	0005c703          	lbu	a4,0(a1)
    80000c92:	00e79863          	bne	a5,a4,80000ca2 <memcmp+0x2c>
      return *s1 - *s2;
    s1++, s2++;
    80000c96:	0505                	addi	a0,a0,1
    80000c98:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000c9a:	fed518e3          	bne	a0,a3,80000c8a <memcmp+0x14>
  }

  return 0;
    80000c9e:	4501                	li	a0,0
    80000ca0:	a019                	j	80000ca6 <memcmp+0x30>
      return *s1 - *s2;
    80000ca2:	40e7853b          	subw	a0,a5,a4
}
    80000ca6:	6422                	ld	s0,8(sp)
    80000ca8:	0141                	addi	sp,sp,16
    80000caa:	8082                	ret
  return 0;
    80000cac:	4501                	li	a0,0
    80000cae:	bfe5                	j	80000ca6 <memcmp+0x30>

0000000080000cb0 <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000cb0:	1141                	addi	sp,sp,-16
    80000cb2:	e422                	sd	s0,8(sp)
    80000cb4:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000cb6:	c205                	beqz	a2,80000cd6 <memmove+0x26>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000cb8:	02a5e263          	bltu	a1,a0,80000cdc <memmove+0x2c>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000cbc:	1602                	slli	a2,a2,0x20
    80000cbe:	9201                	srli	a2,a2,0x20
    80000cc0:	00c587b3          	add	a5,a1,a2
{
    80000cc4:	872a                	mv	a4,a0
      *d++ = *s++;
    80000cc6:	0585                	addi	a1,a1,1
    80000cc8:	0705                	addi	a4,a4,1 # fffffffffffff001 <end+0xffffffff7ffda781>
    80000cca:	fff5c683          	lbu	a3,-1(a1)
    80000cce:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000cd2:	feb79ae3          	bne	a5,a1,80000cc6 <memmove+0x16>

  return dst;
}
    80000cd6:	6422                	ld	s0,8(sp)
    80000cd8:	0141                	addi	sp,sp,16
    80000cda:	8082                	ret
  if (s < d && s + n > d) {
    80000cdc:	02061693          	slli	a3,a2,0x20
    80000ce0:	9281                	srli	a3,a3,0x20
    80000ce2:	00d58733          	add	a4,a1,a3
    80000ce6:	fce57be3          	bgeu	a0,a4,80000cbc <memmove+0xc>
    d += n;
    80000cea:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000cec:	fff6079b          	addiw	a5,a2,-1
    80000cf0:	1782                	slli	a5,a5,0x20
    80000cf2:	9381                	srli	a5,a5,0x20
    80000cf4:	fff7c793          	not	a5,a5
    80000cf8:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000cfa:	177d                	addi	a4,a4,-1
    80000cfc:	16fd                	addi	a3,a3,-1
    80000cfe:	00074603          	lbu	a2,0(a4)
    80000d02:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000d06:	fef71ae3          	bne	a4,a5,80000cfa <memmove+0x4a>
    80000d0a:	b7f1                	j	80000cd6 <memmove+0x26>

0000000080000d0c <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000d0c:	1141                	addi	sp,sp,-16
    80000d0e:	e406                	sd	ra,8(sp)
    80000d10:	e022                	sd	s0,0(sp)
    80000d12:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d14:	f9dff0ef          	jal	80000cb0 <memmove>
}
    80000d18:	60a2                	ld	ra,8(sp)
    80000d1a:	6402                	ld	s0,0(sp)
    80000d1c:	0141                	addi	sp,sp,16
    80000d1e:	8082                	ret

0000000080000d20 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d20:	1141                	addi	sp,sp,-16
    80000d22:	e422                	sd	s0,8(sp)
    80000d24:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000d26:	ce11                	beqz	a2,80000d42 <strncmp+0x22>
    80000d28:	00054783          	lbu	a5,0(a0)
    80000d2c:	cf89                	beqz	a5,80000d46 <strncmp+0x26>
    80000d2e:	0005c703          	lbu	a4,0(a1)
    80000d32:	00f71a63          	bne	a4,a5,80000d46 <strncmp+0x26>
    n--, p++, q++;
    80000d36:	367d                	addiw	a2,a2,-1
    80000d38:	0505                	addi	a0,a0,1
    80000d3a:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000d3c:	f675                	bnez	a2,80000d28 <strncmp+0x8>
  if (n == 0)
    return 0;
    80000d3e:	4501                	li	a0,0
    80000d40:	a801                	j	80000d50 <strncmp+0x30>
    80000d42:	4501                	li	a0,0
    80000d44:	a031                	j	80000d50 <strncmp+0x30>
  return (uchar)*p - (uchar)*q;
    80000d46:	00054503          	lbu	a0,0(a0)
    80000d4a:	0005c783          	lbu	a5,0(a1)
    80000d4e:	9d1d                	subw	a0,a0,a5
}
    80000d50:	6422                	ld	s0,8(sp)
    80000d52:	0141                	addi	sp,sp,16
    80000d54:	8082                	ret

0000000080000d56 <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000d56:	1141                	addi	sp,sp,-16
    80000d58:	e422                	sd	s0,8(sp)
    80000d5a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000d5c:	87aa                	mv	a5,a0
    80000d5e:	86b2                	mv	a3,a2
    80000d60:	367d                	addiw	a2,a2,-1
    80000d62:	02d05563          	blez	a3,80000d8c <strncpy+0x36>
    80000d66:	0785                	addi	a5,a5,1
    80000d68:	0005c703          	lbu	a4,0(a1)
    80000d6c:	fee78fa3          	sb	a4,-1(a5)
    80000d70:	0585                	addi	a1,a1,1
    80000d72:	f775                	bnez	a4,80000d5e <strncpy+0x8>
    ;
  while (n-- > 0)
    80000d74:	873e                	mv	a4,a5
    80000d76:	9fb5                	addw	a5,a5,a3
    80000d78:	37fd                	addiw	a5,a5,-1
    80000d7a:	00c05963          	blez	a2,80000d8c <strncpy+0x36>
    *s++ = 0;
    80000d7e:	0705                	addi	a4,a4,1
    80000d80:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000d84:	40e786bb          	subw	a3,a5,a4
    80000d88:	fed04be3          	bgtz	a3,80000d7e <strncpy+0x28>
  return os;
}
    80000d8c:	6422                	ld	s0,8(sp)
    80000d8e:	0141                	addi	sp,sp,16
    80000d90:	8082                	ret

0000000080000d92 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000d92:	1141                	addi	sp,sp,-16
    80000d94:	e422                	sd	s0,8(sp)
    80000d96:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000d98:	02c05363          	blez	a2,80000dbe <safestrcpy+0x2c>
    80000d9c:	fff6069b          	addiw	a3,a2,-1
    80000da0:	1682                	slli	a3,a3,0x20
    80000da2:	9281                	srli	a3,a3,0x20
    80000da4:	96ae                	add	a3,a3,a1
    80000da6:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000da8:	00d58963          	beq	a1,a3,80000dba <safestrcpy+0x28>
    80000dac:	0585                	addi	a1,a1,1
    80000dae:	0785                	addi	a5,a5,1
    80000db0:	fff5c703          	lbu	a4,-1(a1)
    80000db4:	fee78fa3          	sb	a4,-1(a5)
    80000db8:	fb65                	bnez	a4,80000da8 <safestrcpy+0x16>
    ;
  *s = 0;
    80000dba:	00078023          	sb	zero,0(a5)
  return os;
}
    80000dbe:	6422                	ld	s0,8(sp)
    80000dc0:	0141                	addi	sp,sp,16
    80000dc2:	8082                	ret

0000000080000dc4 <strlen>:

int
strlen(const char *s)
{
    80000dc4:	1141                	addi	sp,sp,-16
    80000dc6:	e422                	sd	s0,8(sp)
    80000dc8:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000dca:	00054783          	lbu	a5,0(a0)
    80000dce:	cf91                	beqz	a5,80000dea <strlen+0x26>
    80000dd0:	0505                	addi	a0,a0,1
    80000dd2:	87aa                	mv	a5,a0
    80000dd4:	86be                	mv	a3,a5
    80000dd6:	0785                	addi	a5,a5,1
    80000dd8:	fff7c703          	lbu	a4,-1(a5)
    80000ddc:	ff65                	bnez	a4,80000dd4 <strlen+0x10>
    80000dde:	40a6853b          	subw	a0,a3,a0
    80000de2:	2505                	addiw	a0,a0,1
    ;
  return n;
}
    80000de4:	6422                	ld	s0,8(sp)
    80000de6:	0141                	addi	sp,sp,16
    80000de8:	8082                	ret
  for (n = 0; s[n]; n++)
    80000dea:	4501                	li	a0,0
    80000dec:	bfe5                	j	80000de4 <strlen+0x20>

0000000080000dee <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000dee:	1141                	addi	sp,sp,-16
    80000df0:	e406                	sd	ra,8(sp)
    80000df2:	e022                	sd	s0,0(sp)
    80000df4:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000df6:	281000ef          	jal	80001876 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000dfa:	0000a717          	auipc	a4,0xa
    80000dfe:	6c270713          	addi	a4,a4,1730 # 8000b4bc <started>
  if (cpuid() == 0) {
    80000e02:	c51d                	beqz	a0,80000e30 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e04:	431c                	lw	a5,0(a4)
    80000e06:	0230000f          	fence	r,rw
    80000e0a:	2781                	sext.w	a5,a5
    80000e0c:	dfe5                	beqz	a5,80000e04 <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000e0e:	269000ef          	jal	80001876 <cpuid>
    80000e12:	85aa                	mv	a1,a0
    80000e14:	00007517          	auipc	a0,0x7
    80000e18:	28450513          	addi	a0,a0,644 # 80008098 <etext+0x98>
    80000e1c:	eeeff0ef          	jal	8000050a <printk>
    kvminithart();  // turn on paging
    80000e20:	082000ef          	jal	80000ea2 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000e24:	5e0010ef          	jal	80002404 <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000e28:	551040ef          	jal	80005b78 <plicinithart>
  }

  scheduler();
    80000e2c:	6e1000ef          	jal	80001d0c <scheduler>
    consoleinit();
    80000e30:	e04ff0ef          	jal	80000434 <consoleinit>
    printkinit();
    80000e34:	9f9ff0ef          	jal	8000082c <printkinit>
    printk("\n");
    80000e38:	00007517          	auipc	a0,0x7
    80000e3c:	24050513          	addi	a0,a0,576 # 80008078 <etext+0x78>
    80000e40:	ecaff0ef          	jal	8000050a <printk>
    printk("xv6 kernel is booting\n");
    80000e44:	00007517          	auipc	a0,0x7
    80000e48:	23c50513          	addi	a0,a0,572 # 80008080 <etext+0x80>
    80000e4c:	ebeff0ef          	jal	8000050a <printk>
    printk("\n");
    80000e50:	00007517          	auipc	a0,0x7
    80000e54:	22850513          	addi	a0,a0,552 # 80008078 <etext+0x78>
    80000e58:	eb2ff0ef          	jal	8000050a <printk>
    kinit();            // physical page allocator
    80000e5c:	c3bff0ef          	jal	80000a96 <kinit>
    kvminit();          // create kernel page table
    80000e60:	2cc000ef          	jal	8000112c <kvminit>
    kvminithart();      // turn on paging
    80000e64:	03e000ef          	jal	80000ea2 <kvminithart>
    procinit();         // process table
    80000e68:	159000ef          	jal	800017c0 <procinit>
    trapinit();         // trap vectors
    80000e6c:	574010ef          	jal	800023e0 <trapinit>
    trapinithart();     // install kernel trap vector
    80000e70:	594010ef          	jal	80002404 <trapinithart>
    plicinit();         // set up interrupt controller
    80000e74:	4eb040ef          	jal	80005b5e <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000e78:	501040ef          	jal	80005b78 <plicinithart>
    binit();            // buffer cache
    80000e7c:	1f6020ef          	jal	80003072 <binit>
    iinit();            // inode table
    80000e80:	77c020ef          	jal	800035fc <iinit>
    fileinit();         // file table
    80000e84:	76e030ef          	jal	800045f2 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000e88:	5e9040ef          	jal	80005c70 <virtio_disk_init>
    userinit();         // first user process
    80000e8c:	4d5000ef          	jal	80001b60 <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000e90:	0000a797          	auipc	a5,0xa
    80000e94:	62c78793          	addi	a5,a5,1580 # 8000b4bc <started>
    80000e98:	4705                	li	a4,1
    80000e9a:	0310000f          	fence	rw,w
    80000e9e:	c398                	sw	a4,0(a5)
    80000ea0:	b771                	j	80000e2c <main+0x3e>

0000000080000ea2 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000ea2:	1141                	addi	sp,sp,-16
    80000ea4:	e422                	sd	s0,8(sp)
    80000ea6:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000ea8:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000eac:	0000a797          	auipc	a5,0xa
    80000eb0:	6147b783          	ld	a5,1556(a5) # 8000b4c0 <kernel_pagetable>
    80000eb4:	83b1                	srli	a5,a5,0xc
    80000eb6:	577d                	li	a4,-1
    80000eb8:	177e                	slli	a4,a4,0x3f
    80000eba:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000ebc:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000ec0:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000ec4:	6422                	ld	s0,8(sp)
    80000ec6:	0141                	addi	sp,sp,16
    80000ec8:	8082                	ret

0000000080000eca <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000eca:	7139                	addi	sp,sp,-64
    80000ecc:	fc06                	sd	ra,56(sp)
    80000ece:	f822                	sd	s0,48(sp)
    80000ed0:	f426                	sd	s1,40(sp)
    80000ed2:	f04a                	sd	s2,32(sp)
    80000ed4:	ec4e                	sd	s3,24(sp)
    80000ed6:	e852                	sd	s4,16(sp)
    80000ed8:	e456                	sd	s5,8(sp)
    80000eda:	e05a                	sd	s6,0(sp)
    80000edc:	0080                	addi	s0,sp,64
    80000ede:	84aa                	mv	s1,a0
    80000ee0:	89ae                	mv	s3,a1
    80000ee2:	8ab2                	mv	s5,a2
  if (va >= MAXVA)
    80000ee4:	57fd                	li	a5,-1
    80000ee6:	83e9                	srli	a5,a5,0x1a
    80000ee8:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000eea:	4b31                	li	s6,12
  if (va >= MAXVA)
    80000eec:	02b7fc63          	bgeu	a5,a1,80000f24 <walk+0x5a>
    panic("walk");
    80000ef0:	00007517          	auipc	a0,0x7
    80000ef4:	1c050513          	addi	a0,a0,448 # 800080b0 <etext+0xb0>
    80000ef8:	8f9ff0ef          	jal	800007f0 <panic>
    pte_t *pte = &pagetable[PX(level, va)];
    if (*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000efc:	060a8263          	beqz	s5,80000f60 <walk+0x96>
    80000f00:	bcbff0ef          	jal	80000aca <kalloc>
    80000f04:	84aa                	mv	s1,a0
    80000f06:	c139                	beqz	a0,80000f4c <walk+0x82>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80000f08:	6605                	lui	a2,0x1
    80000f0a:	4581                	li	a1,0
    80000f0c:	d49ff0ef          	jal	80000c54 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000f10:	00c4d793          	srli	a5,s1,0xc
    80000f14:	07aa                	slli	a5,a5,0xa
    80000f16:	0017e793          	ori	a5,a5,1
    80000f1a:	00f93023          	sd	a5,0(s2)
  for (int level = 2; level > 0; level--) {
    80000f1e:	3a5d                	addiw	s4,s4,-9 # ffffffffffffeff7 <end+0xffffffff7ffda777>
    80000f20:	036a0063          	beq	s4,s6,80000f40 <walk+0x76>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f24:	0149d933          	srl	s2,s3,s4
    80000f28:	1ff97913          	andi	s2,s2,511
    80000f2c:	090e                	slli	s2,s2,0x3
    80000f2e:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000f30:	00093483          	ld	s1,0(s2)
    80000f34:	0014f793          	andi	a5,s1,1
    80000f38:	d3f1                	beqz	a5,80000efc <walk+0x32>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f3a:	80a9                	srli	s1,s1,0xa
    80000f3c:	04b2                	slli	s1,s1,0xc
    80000f3e:	b7c5                	j	80000f1e <walk+0x54>
    }
  }
  return &pagetable[PX(0, va)];
    80000f40:	00c9d513          	srli	a0,s3,0xc
    80000f44:	1ff57513          	andi	a0,a0,511
    80000f48:	050e                	slli	a0,a0,0x3
    80000f4a:	9526                	add	a0,a0,s1
}
    80000f4c:	70e2                	ld	ra,56(sp)
    80000f4e:	7442                	ld	s0,48(sp)
    80000f50:	74a2                	ld	s1,40(sp)
    80000f52:	7902                	ld	s2,32(sp)
    80000f54:	69e2                	ld	s3,24(sp)
    80000f56:	6a42                	ld	s4,16(sp)
    80000f58:	6aa2                	ld	s5,8(sp)
    80000f5a:	6b02                	ld	s6,0(sp)
    80000f5c:	6121                	addi	sp,sp,64
    80000f5e:	8082                	ret
        return 0;
    80000f60:	4501                	li	a0,0
    80000f62:	b7ed                	j	80000f4c <walk+0x82>

0000000080000f64 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    80000f64:	57fd                	li	a5,-1
    80000f66:	83e9                	srli	a5,a5,0x1a
    80000f68:	00b7f463          	bgeu	a5,a1,80000f70 <walkaddr+0xc>
    return 0;
    80000f6c:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000f6e:	8082                	ret
{
    80000f70:	1141                	addi	sp,sp,-16
    80000f72:	e406                	sd	ra,8(sp)
    80000f74:	e022                	sd	s0,0(sp)
    80000f76:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000f78:	4601                	li	a2,0
    80000f7a:	f51ff0ef          	jal	80000eca <walk>
  if (pte == 0)
    80000f7e:	c105                	beqz	a0,80000f9e <walkaddr+0x3a>
  if ((*pte & PTE_V) == 0)
    80000f80:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    80000f82:	0117f693          	andi	a3,a5,17
    80000f86:	4745                	li	a4,17
    return 0;
    80000f88:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    80000f8a:	00e68663          	beq	a3,a4,80000f96 <walkaddr+0x32>
}
    80000f8e:	60a2                	ld	ra,8(sp)
    80000f90:	6402                	ld	s0,0(sp)
    80000f92:	0141                	addi	sp,sp,16
    80000f94:	8082                	ret
  pa = PTE2PA(*pte);
    80000f96:	83a9                	srli	a5,a5,0xa
    80000f98:	00c79513          	slli	a0,a5,0xc
  return pa;
    80000f9c:	bfcd                	j	80000f8e <walkaddr+0x2a>
    return 0;
    80000f9e:	4501                	li	a0,0
    80000fa0:	b7fd                	j	80000f8e <walkaddr+0x2a>

0000000080000fa2 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80000fa2:	715d                	addi	sp,sp,-80
    80000fa4:	e486                	sd	ra,72(sp)
    80000fa6:	e0a2                	sd	s0,64(sp)
    80000fa8:	fc26                	sd	s1,56(sp)
    80000faa:	f84a                	sd	s2,48(sp)
    80000fac:	f44e                	sd	s3,40(sp)
    80000fae:	f052                	sd	s4,32(sp)
    80000fb0:	ec56                	sd	s5,24(sp)
    80000fb2:	e85a                	sd	s6,16(sp)
    80000fb4:	e45e                	sd	s7,8(sp)
    80000fb6:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80000fb8:	03459793          	slli	a5,a1,0x34
    80000fbc:	e7a9                	bnez	a5,80001006 <mappages+0x64>
    80000fbe:	8aaa                	mv	s5,a0
    80000fc0:	8b3a                	mv	s6,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80000fc2:	03461793          	slli	a5,a2,0x34
    80000fc6:	e7b1                	bnez	a5,80001012 <mappages+0x70>
    panic("mappages: size not aligned");

  if (size == 0)
    80000fc8:	ca39                	beqz	a2,8000101e <mappages+0x7c>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    80000fca:	77fd                	lui	a5,0xfffff
    80000fcc:	963e                	add	a2,a2,a5
    80000fce:	00b609b3          	add	s3,a2,a1
  a = va;
    80000fd2:	892e                	mv	s2,a1
    80000fd4:	40b68a33          	sub	s4,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    80000fd8:	6b85                	lui	s7,0x1
    80000fda:	014904b3          	add	s1,s2,s4
    if ((pte = walk(pagetable, a, 1)) == 0)
    80000fde:	4605                	li	a2,1
    80000fe0:	85ca                	mv	a1,s2
    80000fe2:	8556                	mv	a0,s5
    80000fe4:	ee7ff0ef          	jal	80000eca <walk>
    80000fe8:	c539                	beqz	a0,80001036 <mappages+0x94>
    if (*pte & PTE_V)
    80000fea:	611c                	ld	a5,0(a0)
    80000fec:	8b85                	andi	a5,a5,1
    80000fee:	ef95                	bnez	a5,8000102a <mappages+0x88>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80000ff0:	80b1                	srli	s1,s1,0xc
    80000ff2:	04aa                	slli	s1,s1,0xa
    80000ff4:	0164e4b3          	or	s1,s1,s6
    80000ff8:	0014e493          	ori	s1,s1,1
    80000ffc:	e104                	sd	s1,0(a0)
    if (a == last)
    80000ffe:	05390863          	beq	s2,s3,8000104e <mappages+0xac>
    a += PGSIZE;
    80001002:	995e                	add	s2,s2,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001004:	bfd9                	j	80000fda <mappages+0x38>
    panic("mappages: va not aligned");
    80001006:	00007517          	auipc	a0,0x7
    8000100a:	0b250513          	addi	a0,a0,178 # 800080b8 <etext+0xb8>
    8000100e:	fe2ff0ef          	jal	800007f0 <panic>
    panic("mappages: size not aligned");
    80001012:	00007517          	auipc	a0,0x7
    80001016:	0c650513          	addi	a0,a0,198 # 800080d8 <etext+0xd8>
    8000101a:	fd6ff0ef          	jal	800007f0 <panic>
    panic("mappages: size");
    8000101e:	00007517          	auipc	a0,0x7
    80001022:	0da50513          	addi	a0,a0,218 # 800080f8 <etext+0xf8>
    80001026:	fcaff0ef          	jal	800007f0 <panic>
      panic("mappages: remap");
    8000102a:	00007517          	auipc	a0,0x7
    8000102e:	0de50513          	addi	a0,a0,222 # 80008108 <etext+0x108>
    80001032:	fbeff0ef          	jal	800007f0 <panic>
      return -1;
    80001036:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001038:	60a6                	ld	ra,72(sp)
    8000103a:	6406                	ld	s0,64(sp)
    8000103c:	74e2                	ld	s1,56(sp)
    8000103e:	7942                	ld	s2,48(sp)
    80001040:	79a2                	ld	s3,40(sp)
    80001042:	7a02                	ld	s4,32(sp)
    80001044:	6ae2                	ld	s5,24(sp)
    80001046:	6b42                	ld	s6,16(sp)
    80001048:	6ba2                	ld	s7,8(sp)
    8000104a:	6161                	addi	sp,sp,80
    8000104c:	8082                	ret
  return 0;
    8000104e:	4501                	li	a0,0
    80001050:	b7e5                	j	80001038 <mappages+0x96>

0000000080001052 <kvmmap>:
{
    80001052:	1141                	addi	sp,sp,-16
    80001054:	e406                	sd	ra,8(sp)
    80001056:	e022                	sd	s0,0(sp)
    80001058:	0800                	addi	s0,sp,16
    8000105a:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    8000105c:	86b2                	mv	a3,a2
    8000105e:	863e                	mv	a2,a5
    80001060:	f43ff0ef          	jal	80000fa2 <mappages>
    80001064:	e509                	bnez	a0,8000106e <kvmmap+0x1c>
}
    80001066:	60a2                	ld	ra,8(sp)
    80001068:	6402                	ld	s0,0(sp)
    8000106a:	0141                	addi	sp,sp,16
    8000106c:	8082                	ret
    panic("kvmmap");
    8000106e:	00007517          	auipc	a0,0x7
    80001072:	0aa50513          	addi	a0,a0,170 # 80008118 <etext+0x118>
    80001076:	f7aff0ef          	jal	800007f0 <panic>

000000008000107a <kvmmake>:
{
    8000107a:	1101                	addi	sp,sp,-32
    8000107c:	ec06                	sd	ra,24(sp)
    8000107e:	e822                	sd	s0,16(sp)
    80001080:	e426                	sd	s1,8(sp)
    80001082:	e04a                	sd	s2,0(sp)
    80001084:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    80001086:	a45ff0ef          	jal	80000aca <kalloc>
    8000108a:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000108c:	6605                	lui	a2,0x1
    8000108e:	4581                	li	a1,0
    80001090:	bc5ff0ef          	jal	80000c54 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001094:	4719                	li	a4,6
    80001096:	6685                	lui	a3,0x1
    80001098:	10000637          	lui	a2,0x10000
    8000109c:	100005b7          	lui	a1,0x10000
    800010a0:	8526                	mv	a0,s1
    800010a2:	fb1ff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    800010a6:	4719                	li	a4,6
    800010a8:	6685                	lui	a3,0x1
    800010aa:	10001637          	lui	a2,0x10001
    800010ae:	100015b7          	lui	a1,0x10001
    800010b2:	8526                	mv	a0,s1
    800010b4:	f9fff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800010b8:	4719                	li	a4,6
    800010ba:	040006b7          	lui	a3,0x4000
    800010be:	0c000637          	lui	a2,0xc000
    800010c2:	0c0005b7          	lui	a1,0xc000
    800010c6:	8526                	mv	a0,s1
    800010c8:	f8bff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    800010cc:	00007917          	auipc	s2,0x7
    800010d0:	f3490913          	addi	s2,s2,-204 # 80008000 <etext>
    800010d4:	4729                	li	a4,10
    800010d6:	80007697          	auipc	a3,0x80007
    800010da:	f2a68693          	addi	a3,a3,-214 # 8000 <_entry-0x7fff8000>
    800010de:	4605                	li	a2,1
    800010e0:	067e                	slli	a2,a2,0x1f
    800010e2:	85b2                	mv	a1,a2
    800010e4:	8526                	mv	a0,s1
    800010e6:	f6dff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    800010ea:	46c5                	li	a3,17
    800010ec:	06ee                	slli	a3,a3,0x1b
    800010ee:	4719                	li	a4,6
    800010f0:	412686b3          	sub	a3,a3,s2
    800010f4:	864a                	mv	a2,s2
    800010f6:	85ca                	mv	a1,s2
    800010f8:	8526                	mv	a0,s1
    800010fa:	f59ff0ef          	jal	80001052 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800010fe:	4729                	li	a4,10
    80001100:	6685                	lui	a3,0x1
    80001102:	00006617          	auipc	a2,0x6
    80001106:	efe60613          	addi	a2,a2,-258 # 80007000 <_trampoline>
    8000110a:	040005b7          	lui	a1,0x4000
    8000110e:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001110:	05b2                	slli	a1,a1,0xc
    80001112:	8526                	mv	a0,s1
    80001114:	f3fff0ef          	jal	80001052 <kvmmap>
  proc_mapstacks(kpgtbl);
    80001118:	8526                	mv	a0,s1
    8000111a:	60e000ef          	jal	80001728 <proc_mapstacks>
}
    8000111e:	8526                	mv	a0,s1
    80001120:	60e2                	ld	ra,24(sp)
    80001122:	6442                	ld	s0,16(sp)
    80001124:	64a2                	ld	s1,8(sp)
    80001126:	6902                	ld	s2,0(sp)
    80001128:	6105                	addi	sp,sp,32
    8000112a:	8082                	ret

000000008000112c <kvminit>:
{
    8000112c:	1141                	addi	sp,sp,-16
    8000112e:	e406                	sd	ra,8(sp)
    80001130:	e022                	sd	s0,0(sp)
    80001132:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001134:	f47ff0ef          	jal	8000107a <kvmmake>
    80001138:	0000a797          	auipc	a5,0xa
    8000113c:	38a7b423          	sd	a0,904(a5) # 8000b4c0 <kernel_pagetable>
}
    80001140:	60a2                	ld	ra,8(sp)
    80001142:	6402                	ld	s0,0(sp)
    80001144:	0141                	addi	sp,sp,16
    80001146:	8082                	ret

0000000080001148 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001148:	1101                	addi	sp,sp,-32
    8000114a:	ec06                	sd	ra,24(sp)
    8000114c:	e822                	sd	s0,16(sp)
    8000114e:	e426                	sd	s1,8(sp)
    80001150:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    80001152:	979ff0ef          	jal	80000aca <kalloc>
    80001156:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001158:	c509                	beqz	a0,80001162 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    8000115a:	6605                	lui	a2,0x1
    8000115c:	4581                	li	a1,0
    8000115e:	af7ff0ef          	jal	80000c54 <memset>
  return pagetable;
}
    80001162:	8526                	mv	a0,s1
    80001164:	60e2                	ld	ra,24(sp)
    80001166:	6442                	ld	s0,16(sp)
    80001168:	64a2                	ld	s1,8(sp)
    8000116a:	6105                	addi	sp,sp,32
    8000116c:	8082                	ret

000000008000116e <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000116e:	7139                	addi	sp,sp,-64
    80001170:	fc06                	sd	ra,56(sp)
    80001172:	f822                	sd	s0,48(sp)
    80001174:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    80001176:	03459793          	slli	a5,a1,0x34
    8000117a:	e38d                	bnez	a5,8000119c <uvmunmap+0x2e>
    8000117c:	f04a                	sd	s2,32(sp)
    8000117e:	ec4e                	sd	s3,24(sp)
    80001180:	e852                	sd	s4,16(sp)
    80001182:	e456                	sd	s5,8(sp)
    80001184:	e05a                	sd	s6,0(sp)
    80001186:	8a2a                	mv	s4,a0
    80001188:	892e                	mv	s2,a1
    8000118a:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8000118c:	0632                	slli	a2,a2,0xc
    8000118e:	00b609b3          	add	s3,a2,a1
    80001192:	6b05                	lui	s6,0x1
    80001194:	0535f963          	bgeu	a1,s3,800011e6 <uvmunmap+0x78>
    80001198:	f426                	sd	s1,40(sp)
    8000119a:	a015                	j	800011be <uvmunmap+0x50>
    8000119c:	f426                	sd	s1,40(sp)
    8000119e:	f04a                	sd	s2,32(sp)
    800011a0:	ec4e                	sd	s3,24(sp)
    800011a2:	e852                	sd	s4,16(sp)
    800011a4:	e456                	sd	s5,8(sp)
    800011a6:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    800011a8:	00007517          	auipc	a0,0x7
    800011ac:	f7850513          	addi	a0,a0,-136 # 80008120 <etext+0x120>
    800011b0:	e40ff0ef          	jal	800007f0 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    800011b4:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    800011b8:	995a                	add	s2,s2,s6
    800011ba:	03397563          	bgeu	s2,s3,800011e4 <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    800011be:	4601                	li	a2,0
    800011c0:	85ca                	mv	a1,s2
    800011c2:	8552                	mv	a0,s4
    800011c4:	d07ff0ef          	jal	80000eca <walk>
    800011c8:	84aa                	mv	s1,a0
    800011ca:	d57d                	beqz	a0,800011b8 <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    800011cc:	611c                	ld	a5,0(a0)
    800011ce:	0017f713          	andi	a4,a5,1
    800011d2:	d37d                	beqz	a4,800011b8 <uvmunmap+0x4a>
    if (do_free) {
    800011d4:	fe0a80e3          	beqz	s5,800011b4 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    800011d8:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    800011da:	00c79513          	slli	a0,a5,0xc
    800011de:	80bff0ef          	jal	800009e8 <kfree>
    800011e2:	bfc9                	j	800011b4 <uvmunmap+0x46>
    800011e4:	74a2                	ld	s1,40(sp)
    800011e6:	7902                	ld	s2,32(sp)
    800011e8:	69e2                	ld	s3,24(sp)
    800011ea:	6a42                	ld	s4,16(sp)
    800011ec:	6aa2                	ld	s5,8(sp)
    800011ee:	6b02                	ld	s6,0(sp)
  }
}
    800011f0:	70e2                	ld	ra,56(sp)
    800011f2:	7442                	ld	s0,48(sp)
    800011f4:	6121                	addi	sp,sp,64
    800011f6:	8082                	ret

00000000800011f8 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800011f8:	1101                	addi	sp,sp,-32
    800011fa:	ec06                	sd	ra,24(sp)
    800011fc:	e822                	sd	s0,16(sp)
    800011fe:	e426                	sd	s1,8(sp)
    80001200:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    80001202:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    80001204:	00b67d63          	bgeu	a2,a1,8000121e <uvmdealloc+0x26>
    80001208:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    8000120a:	6785                	lui	a5,0x1
    8000120c:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000120e:	00f60733          	add	a4,a2,a5
    80001212:	76fd                	lui	a3,0xfffff
    80001214:	8f75                	and	a4,a4,a3
    80001216:	97ae                	add	a5,a5,a1
    80001218:	8ff5                	and	a5,a5,a3
    8000121a:	00f76863          	bltu	a4,a5,8000122a <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    8000121e:	8526                	mv	a0,s1
    80001220:	60e2                	ld	ra,24(sp)
    80001222:	6442                	ld	s0,16(sp)
    80001224:	64a2                	ld	s1,8(sp)
    80001226:	6105                	addi	sp,sp,32
    80001228:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    8000122a:	8f99                	sub	a5,a5,a4
    8000122c:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    8000122e:	4685                	li	a3,1
    80001230:	0007861b          	sext.w	a2,a5
    80001234:	85ba                	mv	a1,a4
    80001236:	f39ff0ef          	jal	8000116e <uvmunmap>
    8000123a:	b7d5                	j	8000121e <uvmdealloc+0x26>

000000008000123c <uvmalloc>:
  if (newsz < oldsz)
    8000123c:	08b66f63          	bltu	a2,a1,800012da <uvmalloc+0x9e>
{
    80001240:	7139                	addi	sp,sp,-64
    80001242:	fc06                	sd	ra,56(sp)
    80001244:	f822                	sd	s0,48(sp)
    80001246:	ec4e                	sd	s3,24(sp)
    80001248:	e852                	sd	s4,16(sp)
    8000124a:	e456                	sd	s5,8(sp)
    8000124c:	0080                	addi	s0,sp,64
    8000124e:	8aaa                	mv	s5,a0
    80001250:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001252:	6785                	lui	a5,0x1
    80001254:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001256:	95be                	add	a1,a1,a5
    80001258:	77fd                	lui	a5,0xfffff
    8000125a:	00f5f9b3          	and	s3,a1,a5
  for (a = oldsz; a < newsz; a += PGSIZE) {
    8000125e:	08c9f063          	bgeu	s3,a2,800012de <uvmalloc+0xa2>
    80001262:	f426                	sd	s1,40(sp)
    80001264:	f04a                	sd	s2,32(sp)
    80001266:	e05a                	sd	s6,0(sp)
    80001268:	894e                	mv	s2,s3
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    8000126a:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    8000126e:	85dff0ef          	jal	80000aca <kalloc>
    80001272:	84aa                	mv	s1,a0
    if (mem == 0) {
    80001274:	c515                	beqz	a0,800012a0 <uvmalloc+0x64>
    memset(mem, 0, PGSIZE);
    80001276:	6605                	lui	a2,0x1
    80001278:	4581                	li	a1,0
    8000127a:	9dbff0ef          	jal	80000c54 <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    8000127e:	875a                	mv	a4,s6
    80001280:	86a6                	mv	a3,s1
    80001282:	6605                	lui	a2,0x1
    80001284:	85ca                	mv	a1,s2
    80001286:	8556                	mv	a0,s5
    80001288:	d1bff0ef          	jal	80000fa2 <mappages>
    8000128c:	e915                	bnez	a0,800012c0 <uvmalloc+0x84>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    8000128e:	6785                	lui	a5,0x1
    80001290:	993e                	add	s2,s2,a5
    80001292:	fd496ee3          	bltu	s2,s4,8000126e <uvmalloc+0x32>
  return newsz;
    80001296:	8552                	mv	a0,s4
    80001298:	74a2                	ld	s1,40(sp)
    8000129a:	7902                	ld	s2,32(sp)
    8000129c:	6b02                	ld	s6,0(sp)
    8000129e:	a811                	j	800012b2 <uvmalloc+0x76>
      uvmdealloc(pagetable, a, oldsz);
    800012a0:	864e                	mv	a2,s3
    800012a2:	85ca                	mv	a1,s2
    800012a4:	8556                	mv	a0,s5
    800012a6:	f53ff0ef          	jal	800011f8 <uvmdealloc>
      return 0;
    800012aa:	4501                	li	a0,0
    800012ac:	74a2                	ld	s1,40(sp)
    800012ae:	7902                	ld	s2,32(sp)
    800012b0:	6b02                	ld	s6,0(sp)
}
    800012b2:	70e2                	ld	ra,56(sp)
    800012b4:	7442                	ld	s0,48(sp)
    800012b6:	69e2                	ld	s3,24(sp)
    800012b8:	6a42                	ld	s4,16(sp)
    800012ba:	6aa2                	ld	s5,8(sp)
    800012bc:	6121                	addi	sp,sp,64
    800012be:	8082                	ret
      kfree(mem);
    800012c0:	8526                	mv	a0,s1
    800012c2:	f26ff0ef          	jal	800009e8 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800012c6:	864e                	mv	a2,s3
    800012c8:	85ca                	mv	a1,s2
    800012ca:	8556                	mv	a0,s5
    800012cc:	f2dff0ef          	jal	800011f8 <uvmdealloc>
      return 0;
    800012d0:	4501                	li	a0,0
    800012d2:	74a2                	ld	s1,40(sp)
    800012d4:	7902                	ld	s2,32(sp)
    800012d6:	6b02                	ld	s6,0(sp)
    800012d8:	bfe9                	j	800012b2 <uvmalloc+0x76>
    return oldsz;
    800012da:	852e                	mv	a0,a1
}
    800012dc:	8082                	ret
  return newsz;
    800012de:	8532                	mv	a0,a2
    800012e0:	bfc9                	j	800012b2 <uvmalloc+0x76>

00000000800012e2 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800012e2:	7179                	addi	sp,sp,-48
    800012e4:	f406                	sd	ra,40(sp)
    800012e6:	f022                	sd	s0,32(sp)
    800012e8:	ec26                	sd	s1,24(sp)
    800012ea:	e84a                	sd	s2,16(sp)
    800012ec:	e44e                	sd	s3,8(sp)
    800012ee:	e052                	sd	s4,0(sp)
    800012f0:	1800                	addi	s0,sp,48
    800012f2:	8a2a                	mv	s4,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    800012f4:	84aa                	mv	s1,a0
    800012f6:	6905                	lui	s2,0x1
    800012f8:	992a                	add	s2,s2,a0
    pte_t pte = pagetable[i];
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800012fa:	4985                	li	s3,1
    800012fc:	a819                	j	80001312 <freewalk+0x30>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
    800012fe:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001300:	00c79513          	slli	a0,a5,0xc
    80001304:	fdfff0ef          	jal	800012e2 <freewalk>
      pagetable[i] = 0;
    80001308:	0004b023          	sd	zero,0(s1)
  for (int i = 0; i < 512; i++) {
    8000130c:	04a1                	addi	s1,s1,8
    8000130e:	01248f63          	beq	s1,s2,8000132c <freewalk+0x4a>
    pte_t pte = pagetable[i];
    80001312:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80001314:	00f7f713          	andi	a4,a5,15
    80001318:	ff3703e3          	beq	a4,s3,800012fe <freewalk+0x1c>
    } else if (pte & PTE_V) {
    8000131c:	8b85                	andi	a5,a5,1
    8000131e:	d7fd                	beqz	a5,8000130c <freewalk+0x2a>
      panic("freewalk: leaf");
    80001320:	00007517          	auipc	a0,0x7
    80001324:	e1850513          	addi	a0,a0,-488 # 80008138 <etext+0x138>
    80001328:	cc8ff0ef          	jal	800007f0 <panic>
    }
  }
  kfree((void *)pagetable);
    8000132c:	8552                	mv	a0,s4
    8000132e:	ebaff0ef          	jal	800009e8 <kfree>
}
    80001332:	70a2                	ld	ra,40(sp)
    80001334:	7402                	ld	s0,32(sp)
    80001336:	64e2                	ld	s1,24(sp)
    80001338:	6942                	ld	s2,16(sp)
    8000133a:	69a2                	ld	s3,8(sp)
    8000133c:	6a02                	ld	s4,0(sp)
    8000133e:	6145                	addi	sp,sp,48
    80001340:	8082                	ret

0000000080001342 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    80001342:	1101                	addi	sp,sp,-32
    80001344:	ec06                	sd	ra,24(sp)
    80001346:	e822                	sd	s0,16(sp)
    80001348:	e426                	sd	s1,8(sp)
    8000134a:	1000                	addi	s0,sp,32
    8000134c:	84aa                	mv	s1,a0
  if (sz > 0)
    8000134e:	e989                	bnez	a1,80001360 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    80001350:	8526                	mv	a0,s1
    80001352:	f91ff0ef          	jal	800012e2 <freewalk>
}
    80001356:	60e2                	ld	ra,24(sp)
    80001358:	6442                	ld	s0,16(sp)
    8000135a:	64a2                	ld	s1,8(sp)
    8000135c:	6105                	addi	sp,sp,32
    8000135e:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    80001360:	6785                	lui	a5,0x1
    80001362:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001364:	95be                	add	a1,a1,a5
    80001366:	4685                	li	a3,1
    80001368:	00c5d613          	srli	a2,a1,0xc
    8000136c:	4581                	li	a1,0
    8000136e:	e01ff0ef          	jal	8000116e <uvmunmap>
    80001372:	bff9                	j	80001350 <uvmfree+0xe>

0000000080001374 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    80001374:	ce49                	beqz	a2,8000140e <uvmcopy+0x9a>
{
    80001376:	715d                	addi	sp,sp,-80
    80001378:	e486                	sd	ra,72(sp)
    8000137a:	e0a2                	sd	s0,64(sp)
    8000137c:	fc26                	sd	s1,56(sp)
    8000137e:	f84a                	sd	s2,48(sp)
    80001380:	f44e                	sd	s3,40(sp)
    80001382:	f052                	sd	s4,32(sp)
    80001384:	ec56                	sd	s5,24(sp)
    80001386:	e85a                	sd	s6,16(sp)
    80001388:	e45e                	sd	s7,8(sp)
    8000138a:	0880                	addi	s0,sp,80
    8000138c:	8aaa                	mv	s5,a0
    8000138e:	8b2e                	mv	s6,a1
    80001390:	8a32                	mv	s4,a2
  for (i = 0; i < sz; i += PGSIZE) {
    80001392:	4481                	li	s1,0
    80001394:	a029                	j	8000139e <uvmcopy+0x2a>
    80001396:	6785                	lui	a5,0x1
    80001398:	94be                	add	s1,s1,a5
    8000139a:	0544fe63          	bgeu	s1,s4,800013f6 <uvmcopy+0x82>
    if ((pte = walk(old, i, 0)) == 0)
    8000139e:	4601                	li	a2,0
    800013a0:	85a6                	mv	a1,s1
    800013a2:	8556                	mv	a0,s5
    800013a4:	b27ff0ef          	jal	80000eca <walk>
    800013a8:	d57d                	beqz	a0,80001396 <uvmcopy+0x22>
      continue; // page table entry hasn't been allocated
    if ((*pte & PTE_V) == 0)
    800013aa:	6118                	ld	a4,0(a0)
    800013ac:	00177793          	andi	a5,a4,1
    800013b0:	d3fd                	beqz	a5,80001396 <uvmcopy+0x22>
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    800013b2:	00a75593          	srli	a1,a4,0xa
    800013b6:	00c59b93          	slli	s7,a1,0xc
    flags = PTE_FLAGS(*pte);
    800013ba:	3ff77913          	andi	s2,a4,1023
    if ((mem = kalloc()) == 0)
    800013be:	f0cff0ef          	jal	80000aca <kalloc>
    800013c2:	89aa                	mv	s3,a0
    800013c4:	c105                	beqz	a0,800013e4 <uvmcopy+0x70>
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    800013c6:	6605                	lui	a2,0x1
    800013c8:	85de                	mv	a1,s7
    800013ca:	8e7ff0ef          	jal	80000cb0 <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    800013ce:	874a                	mv	a4,s2
    800013d0:	86ce                	mv	a3,s3
    800013d2:	6605                	lui	a2,0x1
    800013d4:	85a6                	mv	a1,s1
    800013d6:	855a                	mv	a0,s6
    800013d8:	bcbff0ef          	jal	80000fa2 <mappages>
    800013dc:	dd4d                	beqz	a0,80001396 <uvmcopy+0x22>
      kfree(mem);
    800013de:	854e                	mv	a0,s3
    800013e0:	e08ff0ef          	jal	800009e8 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800013e4:	4685                	li	a3,1
    800013e6:	00c4d613          	srli	a2,s1,0xc
    800013ea:	4581                	li	a1,0
    800013ec:	855a                	mv	a0,s6
    800013ee:	d81ff0ef          	jal	8000116e <uvmunmap>
  return -1;
    800013f2:	557d                	li	a0,-1
    800013f4:	a011                	j	800013f8 <uvmcopy+0x84>
  return 0;
    800013f6:	4501                	li	a0,0
}
    800013f8:	60a6                	ld	ra,72(sp)
    800013fa:	6406                	ld	s0,64(sp)
    800013fc:	74e2                	ld	s1,56(sp)
    800013fe:	7942                	ld	s2,48(sp)
    80001400:	79a2                	ld	s3,40(sp)
    80001402:	7a02                	ld	s4,32(sp)
    80001404:	6ae2                	ld	s5,24(sp)
    80001406:	6b42                	ld	s6,16(sp)
    80001408:	6ba2                	ld	s7,8(sp)
    8000140a:	6161                	addi	sp,sp,80
    8000140c:	8082                	ret
  return 0;
    8000140e:	4501                	li	a0,0
}
    80001410:	8082                	ret

0000000080001412 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001412:	1141                	addi	sp,sp,-16
    80001414:	e406                	sd	ra,8(sp)
    80001416:	e022                	sd	s0,0(sp)
    80001418:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    8000141a:	4601                	li	a2,0
    8000141c:	aafff0ef          	jal	80000eca <walk>
  if (pte == 0)
    80001420:	c901                	beqz	a0,80001430 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001422:	611c                	ld	a5,0(a0)
    80001424:	9bbd                	andi	a5,a5,-17
    80001426:	e11c                	sd	a5,0(a0)
}
    80001428:	60a2                	ld	ra,8(sp)
    8000142a:	6402                	ld	s0,0(sp)
    8000142c:	0141                	addi	sp,sp,16
    8000142e:	8082                	ret
    panic("uvmclear");
    80001430:	00007517          	auipc	a0,0x7
    80001434:	d1850513          	addi	a0,a0,-744 # 80008148 <etext+0x148>
    80001438:	bb8ff0ef          	jal	800007f0 <panic>

000000008000143c <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    8000143c:	1141                	addi	sp,sp,-16
    8000143e:	e406                	sd	ra,8(sp)
    80001440:	e022                	sd	s0,0(sp)
    80001442:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    80001444:	4601                	li	a2,0
    80001446:	a85ff0ef          	jal	80000eca <walk>
  if (pte == 0) {
    8000144a:	c519                	beqz	a0,80001458 <ismapped+0x1c>
    return 0;
  }
  if (*pte & PTE_V) {
    8000144c:	6108                	ld	a0,0(a0)
    8000144e:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    80001450:	60a2                	ld	ra,8(sp)
    80001452:	6402                	ld	s0,0(sp)
    80001454:	0141                	addi	sp,sp,16
    80001456:	8082                	ret
    return 0;
    80001458:	4501                	li	a0,0
    8000145a:	bfdd                	j	80001450 <ismapped+0x14>

000000008000145c <vmfault>:
{
    8000145c:	7179                	addi	sp,sp,-48
    8000145e:	f406                	sd	ra,40(sp)
    80001460:	f022                	sd	s0,32(sp)
    80001462:	e44e                	sd	s3,8(sp)
    80001464:	1800                	addi	s0,sp,48
    return 0;
    80001466:	4981                	li	s3,0
  if (va >= psz)
    80001468:	00b66863          	bltu	a2,a1,80001478 <vmfault+0x1c>
}
    8000146c:	854e                	mv	a0,s3
    8000146e:	70a2                	ld	ra,40(sp)
    80001470:	7402                	ld	s0,32(sp)
    80001472:	69a2                	ld	s3,8(sp)
    80001474:	6145                	addi	sp,sp,48
    80001476:	8082                	ret
    80001478:	ec26                	sd	s1,24(sp)
    8000147a:	e84a                	sd	s2,16(sp)
    8000147c:	892a                	mv	s2,a0
  va = PGROUNDDOWN(va);
    8000147e:	77fd                	lui	a5,0xfffff
    80001480:	00f674b3          	and	s1,a2,a5
  if (ismapped(pagetable, va)) {
    80001484:	85a6                	mv	a1,s1
    80001486:	fb7ff0ef          	jal	8000143c <ismapped>
    return 0;
    8000148a:	4981                	li	s3,0
  if (ismapped(pagetable, va)) {
    8000148c:	c501                	beqz	a0,80001494 <vmfault+0x38>
    8000148e:	64e2                	ld	s1,24(sp)
    80001490:	6942                	ld	s2,16(sp)
    80001492:	bfe9                	j	8000146c <vmfault+0x10>
    80001494:	e052                	sd	s4,0(sp)
  mem = (uint64)kalloc();
    80001496:	e34ff0ef          	jal	80000aca <kalloc>
    8000149a:	8a2a                	mv	s4,a0
  if (mem == 0)
    8000149c:	c915                	beqz	a0,800014d0 <vmfault+0x74>
  mem = (uint64)kalloc();
    8000149e:	89aa                	mv	s3,a0
  memset((void *)mem, 0, PGSIZE);
    800014a0:	6605                	lui	a2,0x1
    800014a2:	4581                	li	a1,0
    800014a4:	fb0ff0ef          	jal	80000c54 <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    800014a8:	4759                	li	a4,22
    800014aa:	86d2                	mv	a3,s4
    800014ac:	6605                	lui	a2,0x1
    800014ae:	85a6                	mv	a1,s1
    800014b0:	854a                	mv	a0,s2
    800014b2:	af1ff0ef          	jal	80000fa2 <mappages>
    800014b6:	e509                	bnez	a0,800014c0 <vmfault+0x64>
    800014b8:	64e2                	ld	s1,24(sp)
    800014ba:	6942                	ld	s2,16(sp)
    800014bc:	6a02                	ld	s4,0(sp)
    800014be:	b77d                	j	8000146c <vmfault+0x10>
    kfree((void *)mem);
    800014c0:	8552                	mv	a0,s4
    800014c2:	d26ff0ef          	jal	800009e8 <kfree>
    return 0;
    800014c6:	4981                	li	s3,0
    800014c8:	64e2                	ld	s1,24(sp)
    800014ca:	6942                	ld	s2,16(sp)
    800014cc:	6a02                	ld	s4,0(sp)
    800014ce:	bf79                	j	8000146c <vmfault+0x10>
    800014d0:	64e2                	ld	s1,24(sp)
    800014d2:	6942                	ld	s2,16(sp)
    800014d4:	6a02                	ld	s4,0(sp)
    800014d6:	bf59                	j	8000146c <vmfault+0x10>

00000000800014d8 <copyout>:
  while (len > 0) {
    800014d8:	c745                	beqz	a4,80001580 <copyout+0xa8>
{
    800014da:	7159                	addi	sp,sp,-112
    800014dc:	f486                	sd	ra,104(sp)
    800014de:	f0a2                	sd	s0,96(sp)
    800014e0:	eca6                	sd	s1,88(sp)
    800014e2:	e0d2                	sd	s4,64(sp)
    800014e4:	f85a                	sd	s6,48(sp)
    800014e6:	f45e                	sd	s7,40(sp)
    800014e8:	f062                	sd	s8,32(sp)
    800014ea:	e46e                	sd	s11,8(sp)
    800014ec:	1880                	addi	s0,sp,112
    800014ee:	8c2a                	mv	s8,a0
    800014f0:	8dae                	mv	s11,a1
    800014f2:	8b32                	mv	s6,a2
    800014f4:	8bb6                	mv	s7,a3
    800014f6:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(dstva);
    800014f8:	74fd                	lui	s1,0xfffff
    800014fa:	8cf1                	and	s1,s1,a2
    if (va0 >= MAXVA)
    800014fc:	57fd                	li	a5,-1
    800014fe:	83e9                	srli	a5,a5,0x1a
    80001500:	0897e263          	bltu	a5,s1,80001584 <copyout+0xac>
    80001504:	e8ca                	sd	s2,80(sp)
    80001506:	e4ce                	sd	s3,72(sp)
    80001508:	fc56                	sd	s5,56(sp)
    8000150a:	ec66                	sd	s9,24(sp)
    8000150c:	e86a                	sd	s10,16(sp)
    8000150e:	6d05                	lui	s10,0x1
    80001510:	8cbe                	mv	s9,a5
    80001512:	a015                	j	80001536 <copyout+0x5e>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001514:	409b0533          	sub	a0,s6,s1
    80001518:	0009861b          	sext.w	a2,s3
    8000151c:	85de                	mv	a1,s7
    8000151e:	954a                	add	a0,a0,s2
    80001520:	f90ff0ef          	jal	80000cb0 <memmove>
    len -= n;
    80001524:	413a0a33          	sub	s4,s4,s3
    src += n;
    80001528:	9bce                	add	s7,s7,s3
  while (len > 0) {
    8000152a:	040a0463          	beqz	s4,80001572 <copyout+0x9a>
    if (va0 >= MAXVA)
    8000152e:	055ced63          	bltu	s9,s5,80001588 <copyout+0xb0>
    80001532:	84d6                	mv	s1,s5
    80001534:	8b56                	mv	s6,s5
    pa0 = walkaddr(pagetable, va0);
    80001536:	85a6                	mv	a1,s1
    80001538:	8562                	mv	a0,s8
    8000153a:	a2bff0ef          	jal	80000f64 <walkaddr>
    8000153e:	892a                	mv	s2,a0
    if (pa0 == 0) {
    80001540:	e909                	bnez	a0,80001552 <copyout+0x7a>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    80001542:	4681                	li	a3,0
    80001544:	8626                	mv	a2,s1
    80001546:	85ee                	mv	a1,s11
    80001548:	8562                	mv	a0,s8
    8000154a:	f13ff0ef          	jal	8000145c <vmfault>
    8000154e:	892a                	mv	s2,a0
    80001550:	c139                	beqz	a0,80001596 <copyout+0xbe>
    pte = walk(pagetable, va0, 0);
    80001552:	4601                	li	a2,0
    80001554:	85a6                	mv	a1,s1
    80001556:	8562                	mv	a0,s8
    80001558:	973ff0ef          	jal	80000eca <walk>
    if ((*pte & PTE_W) == 0)
    8000155c:	611c                	ld	a5,0(a0)
    8000155e:	8b91                	andi	a5,a5,4
    80001560:	c3b1                	beqz	a5,800015a4 <copyout+0xcc>
    n = PGSIZE - (dstva - va0);
    80001562:	01a48ab3          	add	s5,s1,s10
    80001566:	416a89b3          	sub	s3,s5,s6
    if (n > len)
    8000156a:	fb3a75e3          	bgeu	s4,s3,80001514 <copyout+0x3c>
    8000156e:	89d2                	mv	s3,s4
    80001570:	b755                	j	80001514 <copyout+0x3c>
  return 0;
    80001572:	4501                	li	a0,0
    80001574:	6946                	ld	s2,80(sp)
    80001576:	69a6                	ld	s3,72(sp)
    80001578:	7ae2                	ld	s5,56(sp)
    8000157a:	6ce2                	ld	s9,24(sp)
    8000157c:	6d42                	ld	s10,16(sp)
    8000157e:	a80d                	j	800015b0 <copyout+0xd8>
    80001580:	4501                	li	a0,0
}
    80001582:	8082                	ret
      return -1;
    80001584:	557d                	li	a0,-1
    80001586:	a02d                	j	800015b0 <copyout+0xd8>
    80001588:	557d                	li	a0,-1
    8000158a:	6946                	ld	s2,80(sp)
    8000158c:	69a6                	ld	s3,72(sp)
    8000158e:	7ae2                	ld	s5,56(sp)
    80001590:	6ce2                	ld	s9,24(sp)
    80001592:	6d42                	ld	s10,16(sp)
    80001594:	a831                	j	800015b0 <copyout+0xd8>
        return -1;
    80001596:	557d                	li	a0,-1
    80001598:	6946                	ld	s2,80(sp)
    8000159a:	69a6                	ld	s3,72(sp)
    8000159c:	7ae2                	ld	s5,56(sp)
    8000159e:	6ce2                	ld	s9,24(sp)
    800015a0:	6d42                	ld	s10,16(sp)
    800015a2:	a039                	j	800015b0 <copyout+0xd8>
      return -1;
    800015a4:	557d                	li	a0,-1
    800015a6:	6946                	ld	s2,80(sp)
    800015a8:	69a6                	ld	s3,72(sp)
    800015aa:	7ae2                	ld	s5,56(sp)
    800015ac:	6ce2                	ld	s9,24(sp)
    800015ae:	6d42                	ld	s10,16(sp)
}
    800015b0:	70a6                	ld	ra,104(sp)
    800015b2:	7406                	ld	s0,96(sp)
    800015b4:	64e6                	ld	s1,88(sp)
    800015b6:	6a06                	ld	s4,64(sp)
    800015b8:	7b42                	ld	s6,48(sp)
    800015ba:	7ba2                	ld	s7,40(sp)
    800015bc:	7c02                	ld	s8,32(sp)
    800015be:	6da2                	ld	s11,8(sp)
    800015c0:	6165                	addi	sp,sp,112
    800015c2:	8082                	ret

00000000800015c4 <copyin>:
  while (len > 0) {
    800015c4:	cb49                	beqz	a4,80001656 <copyin+0x92>
{
    800015c6:	711d                	addi	sp,sp,-96
    800015c8:	ec86                	sd	ra,88(sp)
    800015ca:	e8a2                	sd	s0,80(sp)
    800015cc:	e4a6                	sd	s1,72(sp)
    800015ce:	e0ca                	sd	s2,64(sp)
    800015d0:	fc4e                	sd	s3,56(sp)
    800015d2:	f852                	sd	s4,48(sp)
    800015d4:	f456                	sd	s5,40(sp)
    800015d6:	f05a                	sd	s6,32(sp)
    800015d8:	ec5e                	sd	s7,24(sp)
    800015da:	e862                	sd	s8,16(sp)
    800015dc:	e466                	sd	s9,8(sp)
    800015de:	1080                	addi	s0,sp,96
    800015e0:	8baa                	mv	s7,a0
    800015e2:	8cae                	mv	s9,a1
    800015e4:	8ab2                	mv	s5,a2
    800015e6:	8936                	mv	s2,a3
    800015e8:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    800015ea:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    800015ec:	6b05                	lui	s6,0x1
    800015ee:	a035                	j	8000161a <copyin+0x56>
    800015f0:	412984b3          	sub	s1,s3,s2
    800015f4:	94da                	add	s1,s1,s6
    if (n > len)
    800015f6:	009a7363          	bgeu	s4,s1,800015fc <copyin+0x38>
    800015fa:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    800015fc:	413905b3          	sub	a1,s2,s3
    80001600:	0004861b          	sext.w	a2,s1
    80001604:	95aa                	add	a1,a1,a0
    80001606:	8556                	mv	a0,s5
    80001608:	ea8ff0ef          	jal	80000cb0 <memmove>
    len -= n;
    8000160c:	409a0a33          	sub	s4,s4,s1
    dst += n;
    80001610:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    80001612:	01698933          	add	s2,s3,s6
  while (len > 0) {
    80001616:	020a0263          	beqz	s4,8000163a <copyin+0x76>
    va0 = PGROUNDDOWN(srcva);
    8000161a:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    8000161e:	85ce                	mv	a1,s3
    80001620:	855e                	mv	a0,s7
    80001622:	943ff0ef          	jal	80000f64 <walkaddr>
    if (pa0 == 0) {
    80001626:	f569                	bnez	a0,800015f0 <copyin+0x2c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001628:	4685                	li	a3,1
    8000162a:	864e                	mv	a2,s3
    8000162c:	85e6                	mv	a1,s9
    8000162e:	855e                	mv	a0,s7
    80001630:	e2dff0ef          	jal	8000145c <vmfault>
    80001634:	fd55                	bnez	a0,800015f0 <copyin+0x2c>
        return -1;
    80001636:	557d                	li	a0,-1
    80001638:	a011                	j	8000163c <copyin+0x78>
  return 0;
    8000163a:	4501                	li	a0,0
}
    8000163c:	60e6                	ld	ra,88(sp)
    8000163e:	6446                	ld	s0,80(sp)
    80001640:	64a6                	ld	s1,72(sp)
    80001642:	6906                	ld	s2,64(sp)
    80001644:	79e2                	ld	s3,56(sp)
    80001646:	7a42                	ld	s4,48(sp)
    80001648:	7aa2                	ld	s5,40(sp)
    8000164a:	7b02                	ld	s6,32(sp)
    8000164c:	6be2                	ld	s7,24(sp)
    8000164e:	6c42                	ld	s8,16(sp)
    80001650:	6ca2                	ld	s9,8(sp)
    80001652:	6125                	addi	sp,sp,96
    80001654:	8082                	ret
  return 0;
    80001656:	4501                	li	a0,0
}
    80001658:	8082                	ret

000000008000165a <copyinstr>:
  while (got_null == 0 && max > 0) {
    8000165a:	c371                	beqz	a4,8000171e <copyinstr+0xc4>
{
    8000165c:	715d                	addi	sp,sp,-80
    8000165e:	e486                	sd	ra,72(sp)
    80001660:	e0a2                	sd	s0,64(sp)
    80001662:	fc26                	sd	s1,56(sp)
    80001664:	f84a                	sd	s2,48(sp)
    80001666:	f44e                	sd	s3,40(sp)
    80001668:	f052                	sd	s4,32(sp)
    8000166a:	ec56                	sd	s5,24(sp)
    8000166c:	e85a                	sd	s6,16(sp)
    8000166e:	e45e                	sd	s7,8(sp)
    80001670:	e062                	sd	s8,0(sp)
    80001672:	0880                	addi	s0,sp,80
    80001674:	8a2a                	mv	s4,a0
    80001676:	8b2e                	mv	s6,a1
    80001678:	8bb2                	mv	s7,a2
    8000167a:	8c36                	mv	s8,a3
    8000167c:	893a                	mv	s2,a4
    va0 = PGROUNDDOWN(srcva);
    8000167e:	7afd                	lui	s5,0xfffff
    n = PGSIZE - (srcva - va0);
    80001680:	6985                	lui	s3,0x1
    80001682:	a0b1                	j	800016ce <copyinstr+0x74>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001684:	4685                	li	a3,1
    80001686:	8626                	mv	a2,s1
    80001688:	85da                	mv	a1,s6
    8000168a:	8552                	mv	a0,s4
    8000168c:	dd1ff0ef          	jal	8000145c <vmfault>
    80001690:	e531                	bnez	a0,800016dc <copyinstr+0x82>
        return -1;
    80001692:	557d                	li	a0,-1
    80001694:	a039                	j	800016a2 <copyinstr+0x48>
        *dst = '\0';
    80001696:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffda780>
    8000169a:	4785                	li	a5,1
  if (got_null) {
    8000169c:	37fd                	addiw	a5,a5,-1
    8000169e:	0007851b          	sext.w	a0,a5
}
    800016a2:	60a6                	ld	ra,72(sp)
    800016a4:	6406                	ld	s0,64(sp)
    800016a6:	74e2                	ld	s1,56(sp)
    800016a8:	7942                	ld	s2,48(sp)
    800016aa:	79a2                	ld	s3,40(sp)
    800016ac:	7a02                	ld	s4,32(sp)
    800016ae:	6ae2                	ld	s5,24(sp)
    800016b0:	6b42                	ld	s6,16(sp)
    800016b2:	6ba2                	ld	s7,8(sp)
    800016b4:	6c02                	ld	s8,0(sp)
    800016b6:	6161                	addi	sp,sp,80
    800016b8:	8082                	ret
    800016ba:	fff90713          	addi	a4,s2,-1 # fff <_entry-0x7ffff001>
    800016be:	972a                	add	a4,a4,a0
      --max;
    800016c0:	40b70933          	sub	s2,a4,a1
    srcva = va0 + PGSIZE;
    800016c4:	01348c33          	add	s8,s1,s3
  while (got_null == 0 && max > 0) {
    800016c8:	04e58563          	beq	a1,a4,80001712 <copyinstr+0xb8>
{
    800016cc:	8bbe                	mv	s7,a5
    va0 = PGROUNDDOWN(srcva);
    800016ce:	015c74b3          	and	s1,s8,s5
    pa0 = walkaddr(pagetable, va0);
    800016d2:	85a6                	mv	a1,s1
    800016d4:	8552                	mv	a0,s4
    800016d6:	88fff0ef          	jal	80000f64 <walkaddr>
    if (pa0 == 0) {
    800016da:	d54d                	beqz	a0,80001684 <copyinstr+0x2a>
    n = PGSIZE - (srcva - va0);
    800016dc:	41848633          	sub	a2,s1,s8
    800016e0:	964e                	add	a2,a2,s3
    if (n > max)
    800016e2:	00c97363          	bgeu	s2,a2,800016e8 <copyinstr+0x8e>
    800016e6:	864a                	mv	a2,s2
    char *p = (char *)(pa0 + (srcva - va0));
    800016e8:	409c0c33          	sub	s8,s8,s1
    800016ec:	9c2a                	add	s8,s8,a0
    while (n > 0) {
    800016ee:	c605                	beqz	a2,80001716 <copyinstr+0xbc>
    800016f0:	87de                	mv	a5,s7
    800016f2:	855e                	mv	a0,s7
      if (*p == '\0') {
    800016f4:	417c0733          	sub	a4,s8,s7
    while (n > 0) {
    800016f8:	965e                	add	a2,a2,s7
    800016fa:	85be                	mv	a1,a5
      if (*p == '\0') {
    800016fc:	00f706b3          	add	a3,a4,a5
    80001700:	0006c683          	lbu	a3,0(a3) # fffffffffffff000 <end+0xffffffff7ffda780>
    80001704:	dac9                	beqz	a3,80001696 <copyinstr+0x3c>
        *dst = *p;
    80001706:	00d78023          	sb	a3,0(a5)
      dst++;
    8000170a:	0785                	addi	a5,a5,1
    while (n > 0) {
    8000170c:	fec797e3          	bne	a5,a2,800016fa <copyinstr+0xa0>
    80001710:	b76d                	j	800016ba <copyinstr+0x60>
    80001712:	4781                	li	a5,0
    80001714:	b761                	j	8000169c <copyinstr+0x42>
    srcva = va0 + PGSIZE;
    80001716:	6c05                	lui	s8,0x1
    80001718:	9c26                	add	s8,s8,s1
    8000171a:	87de                	mv	a5,s7
    8000171c:	bf45                	j	800016cc <copyinstr+0x72>
  int got_null = 0;
    8000171e:	4781                	li	a5,0
  if (got_null) {
    80001720:	37fd                	addiw	a5,a5,-1
    80001722:	0007851b          	sext.w	a0,a5
}
    80001726:	8082                	ret

0000000080001728 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    80001728:	7139                	addi	sp,sp,-64
    8000172a:	fc06                	sd	ra,56(sp)
    8000172c:	f822                	sd	s0,48(sp)
    8000172e:	f426                	sd	s1,40(sp)
    80001730:	f04a                	sd	s2,32(sp)
    80001732:	ec4e                	sd	s3,24(sp)
    80001734:	e852                	sd	s4,16(sp)
    80001736:	e456                	sd	s5,8(sp)
    80001738:	e05a                	sd	s6,0(sp)
    8000173a:	0080                	addi	s0,sp,64
    8000173c:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    8000173e:	00012497          	auipc	s1,0x12
    80001742:	2e248493          	addi	s1,s1,738 # 80013a20 <proc>
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    80001746:	8b26                	mv	s6,s1
    80001748:	04fa5937          	lui	s2,0x4fa5
    8000174c:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    80001750:	0932                	slli	s2,s2,0xc
    80001752:	fa590913          	addi	s2,s2,-91
    80001756:	0932                	slli	s2,s2,0xc
    80001758:	fa590913          	addi	s2,s2,-91
    8000175c:	0932                	slli	s2,s2,0xc
    8000175e:	fa590913          	addi	s2,s2,-91
    80001762:	040009b7          	lui	s3,0x4000
    80001766:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001768:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    8000176a:	00018a97          	auipc	s5,0x18
    8000176e:	cb6a8a93          	addi	s5,s5,-842 # 80019420 <tickslock>
    char *pa = kalloc();
    80001772:	b58ff0ef          	jal	80000aca <kalloc>
    80001776:	862a                	mv	a2,a0
    if (pa == 0)
    80001778:	cd15                	beqz	a0,800017b4 <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int)(p - proc));
    8000177a:	416485b3          	sub	a1,s1,s6
    8000177e:	858d                	srai	a1,a1,0x3
    80001780:	032585b3          	mul	a1,a1,s2
    80001784:	2585                	addiw	a1,a1,1
    80001786:	00d5959b          	slliw	a1,a1,0xd
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000178a:	4719                	li	a4,6
    8000178c:	6685                	lui	a3,0x1
    8000178e:	40b985b3          	sub	a1,s3,a1
    80001792:	8552                	mv	a0,s4
    80001794:	8bfff0ef          	jal	80001052 <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001798:	16848493          	addi	s1,s1,360
    8000179c:	fd549be3          	bne	s1,s5,80001772 <proc_mapstacks+0x4a>
  }
}
    800017a0:	70e2                	ld	ra,56(sp)
    800017a2:	7442                	ld	s0,48(sp)
    800017a4:	74a2                	ld	s1,40(sp)
    800017a6:	7902                	ld	s2,32(sp)
    800017a8:	69e2                	ld	s3,24(sp)
    800017aa:	6a42                	ld	s4,16(sp)
    800017ac:	6aa2                	ld	s5,8(sp)
    800017ae:	6b02                	ld	s6,0(sp)
    800017b0:	6121                	addi	sp,sp,64
    800017b2:	8082                	ret
      panic("kalloc");
    800017b4:	00007517          	auipc	a0,0x7
    800017b8:	9a450513          	addi	a0,a0,-1628 # 80008158 <etext+0x158>
    800017bc:	834ff0ef          	jal	800007f0 <panic>

00000000800017c0 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    800017c0:	7139                	addi	sp,sp,-64
    800017c2:	fc06                	sd	ra,56(sp)
    800017c4:	f822                	sd	s0,48(sp)
    800017c6:	f426                	sd	s1,40(sp)
    800017c8:	f04a                	sd	s2,32(sp)
    800017ca:	ec4e                	sd	s3,24(sp)
    800017cc:	e852                	sd	s4,16(sp)
    800017ce:	e456                	sd	s5,8(sp)
    800017d0:	e05a                	sd	s6,0(sp)
    800017d2:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    800017d4:	00007597          	auipc	a1,0x7
    800017d8:	98c58593          	addi	a1,a1,-1652 # 80008160 <etext+0x160>
    800017dc:	00012517          	auipc	a0,0x12
    800017e0:	e1450513          	addi	a0,a0,-492 # 800135f0 <pid_lock>
    800017e4:	b36ff0ef          	jal	80000b1a <initlock>
  initlock(&wait_lock, "wait_lock");
    800017e8:	00007597          	auipc	a1,0x7
    800017ec:	98058593          	addi	a1,a1,-1664 # 80008168 <etext+0x168>
    800017f0:	00012517          	auipc	a0,0x12
    800017f4:	e1850513          	addi	a0,a0,-488 # 80013608 <wait_lock>
    800017f8:	b22ff0ef          	jal	80000b1a <initlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    800017fc:	00012497          	auipc	s1,0x12
    80001800:	22448493          	addi	s1,s1,548 # 80013a20 <proc>
    initlock(&p->lock, "proc");
    80001804:	00007b17          	auipc	s6,0x7
    80001808:	974b0b13          	addi	s6,s6,-1676 # 80008178 <etext+0x178>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    8000180c:	8aa6                	mv	s5,s1
    8000180e:	04fa5937          	lui	s2,0x4fa5
    80001812:	fa590913          	addi	s2,s2,-91 # 4fa4fa5 <_entry-0x7b05b05b>
    80001816:	0932                	slli	s2,s2,0xc
    80001818:	fa590913          	addi	s2,s2,-91
    8000181c:	0932                	slli	s2,s2,0xc
    8000181e:	fa590913          	addi	s2,s2,-91
    80001822:	0932                	slli	s2,s2,0xc
    80001824:	fa590913          	addi	s2,s2,-91
    80001828:	040009b7          	lui	s3,0x4000
    8000182c:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000182e:	09b2                	slli	s3,s3,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    80001830:	00018a17          	auipc	s4,0x18
    80001834:	bf0a0a13          	addi	s4,s4,-1040 # 80019420 <tickslock>
    initlock(&p->lock, "proc");
    80001838:	85da                	mv	a1,s6
    8000183a:	8526                	mv	a0,s1
    8000183c:	adeff0ef          	jal	80000b1a <initlock>
    p->state = UNUSED;
    80001840:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    80001844:	415487b3          	sub	a5,s1,s5
    80001848:	878d                	srai	a5,a5,0x3
    8000184a:	032787b3          	mul	a5,a5,s2
    8000184e:	2785                	addiw	a5,a5,1
    80001850:	00d7979b          	slliw	a5,a5,0xd
    80001854:	40f987b3          	sub	a5,s3,a5
    80001858:	e0bc                	sd	a5,64(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    8000185a:	16848493          	addi	s1,s1,360
    8000185e:	fd449de3          	bne	s1,s4,80001838 <procinit+0x78>
  }
}
    80001862:	70e2                	ld	ra,56(sp)
    80001864:	7442                	ld	s0,48(sp)
    80001866:	74a2                	ld	s1,40(sp)
    80001868:	7902                	ld	s2,32(sp)
    8000186a:	69e2                	ld	s3,24(sp)
    8000186c:	6a42                	ld	s4,16(sp)
    8000186e:	6aa2                	ld	s5,8(sp)
    80001870:	6b02                	ld	s6,0(sp)
    80001872:	6121                	addi	sp,sp,64
    80001874:	8082                	ret

0000000080001876 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001876:	1141                	addi	sp,sp,-16
    80001878:	e422                	sd	s0,8(sp)
    8000187a:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    8000187c:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    8000187e:	2501                	sext.w	a0,a0
    80001880:	6422                	ld	s0,8(sp)
    80001882:	0141                	addi	sp,sp,16
    80001884:	8082                	ret

0000000080001886 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    80001886:	1141                	addi	sp,sp,-16
    80001888:	e422                	sd	s0,8(sp)
    8000188a:	0800                	addi	s0,sp,16
    8000188c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    8000188e:	2781                	sext.w	a5,a5
    80001890:	079e                	slli	a5,a5,0x7
  return c;
}
    80001892:	00012517          	auipc	a0,0x12
    80001896:	d8e50513          	addi	a0,a0,-626 # 80013620 <cpus>
    8000189a:	953e                	add	a0,a0,a5
    8000189c:	6422                	ld	s0,8(sp)
    8000189e:	0141                	addi	sp,sp,16
    800018a0:	8082                	ret

00000000800018a2 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    800018a2:	1101                	addi	sp,sp,-32
    800018a4:	ec06                	sd	ra,24(sp)
    800018a6:	e822                	sd	s0,16(sp)
    800018a8:	e426                	sd	s1,8(sp)
    800018aa:	1000                	addi	s0,sp,32
  push_off();
    800018ac:	aaeff0ef          	jal	80000b5a <push_off>
    800018b0:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    800018b2:	2781                	sext.w	a5,a5
    800018b4:	079e                	slli	a5,a5,0x7
    800018b6:	00012717          	auipc	a4,0x12
    800018ba:	d3a70713          	addi	a4,a4,-710 # 800135f0 <pid_lock>
    800018be:	97ba                	add	a5,a5,a4
    800018c0:	7b84                	ld	s1,48(a5)
  pop_off();
    800018c2:	b0eff0ef          	jal	80000bd0 <pop_off>
  return p;
}
    800018c6:	8526                	mv	a0,s1
    800018c8:	60e2                	ld	ra,24(sp)
    800018ca:	6442                	ld	s0,16(sp)
    800018cc:	64a2                	ld	s1,8(sp)
    800018ce:	6105                	addi	sp,sp,32
    800018d0:	8082                	ret

00000000800018d2 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    800018d2:	7179                	addi	sp,sp,-48
    800018d4:	f406                	sd	ra,40(sp)
    800018d6:	f022                	sd	s0,32(sp)
    800018d8:	ec26                	sd	s1,24(sp)
    800018da:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    800018dc:	fc7ff0ef          	jal	800018a2 <myproc>
    800018e0:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    800018e2:	b3aff0ef          	jal	80000c1c <release>

  if (first) {
    800018e6:	0000a797          	auipc	a5,0xa
    800018ea:	b9a7a783          	lw	a5,-1126(a5) # 8000b480 <first.1>
    800018ee:	cb9d                	beqz	a5,80001924 <forkret+0x52>
    first = 0;
    800018f0:	0000a797          	auipc	a5,0xa
    800018f4:	b807a823          	sw	zero,-1136(a5) # 8000b480 <first.1>

    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    800018f8:	4505                	li	a0,1
    800018fa:	206020ef          	jal	80003b00 <fsinit>

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    800018fe:	00007517          	auipc	a0,0x7
    80001902:	88250513          	addi	a0,a0,-1918 # 80008180 <etext+0x180>
    80001906:	fca43823          	sd	a0,-48(s0)
    8000190a:	fc043c23          	sd	zero,-40(s0)
    8000190e:	fd040593          	addi	a1,s0,-48
    80001912:	3f8030ef          	jal	80004d0a <kexec>
    80001916:	6cbc                	ld	a5,88(s1)
    80001918:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    8000191a:	6cbc                	ld	a5,88(s1)
    8000191c:	7bb8                	ld	a4,112(a5)
    8000191e:	57fd                	li	a5,-1
    80001920:	02f70d63          	beq	a4,a5,8000195a <forkret+0x88>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001924:	2f9000ef          	jal	8000241c <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001928:	68a8                	ld	a0,80(s1)
    8000192a:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    8000192c:	04000737          	lui	a4,0x4000
    80001930:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001932:	0732                	slli	a4,a4,0xc
    80001934:	00005797          	auipc	a5,0x5
    80001938:	76878793          	addi	a5,a5,1896 # 8000709c <userret>
    8000193c:	00005697          	auipc	a3,0x5
    80001940:	6c468693          	addi	a3,a3,1732 # 80007000 <_trampoline>
    80001944:	8f95                	sub	a5,a5,a3
    80001946:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001948:	577d                	li	a4,-1
    8000194a:	177e                	slli	a4,a4,0x3f
    8000194c:	8d59                	or	a0,a0,a4
    8000194e:	9782                	jalr	a5
}
    80001950:	70a2                	ld	ra,40(sp)
    80001952:	7402                	ld	s0,32(sp)
    80001954:	64e2                	ld	s1,24(sp)
    80001956:	6145                	addi	sp,sp,48
    80001958:	8082                	ret
      panic("exec");
    8000195a:	00007517          	auipc	a0,0x7
    8000195e:	82e50513          	addi	a0,a0,-2002 # 80008188 <etext+0x188>
    80001962:	e8ffe0ef          	jal	800007f0 <panic>

0000000080001966 <allocpid>:
{
    80001966:	1101                	addi	sp,sp,-32
    80001968:	ec06                	sd	ra,24(sp)
    8000196a:	e822                	sd	s0,16(sp)
    8000196c:	e426                	sd	s1,8(sp)
    8000196e:	e04a                	sd	s2,0(sp)
    80001970:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001972:	00012917          	auipc	s2,0x12
    80001976:	c7e90913          	addi	s2,s2,-898 # 800135f0 <pid_lock>
    8000197a:	854a                	mv	a0,s2
    8000197c:	a14ff0ef          	jal	80000b90 <acquire>
  pid = nextpid;
    80001980:	0000a797          	auipc	a5,0xa
    80001984:	b0478793          	addi	a5,a5,-1276 # 8000b484 <nextpid>
    80001988:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    8000198a:	0014871b          	addiw	a4,s1,1
    8000198e:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001990:	854a                	mv	a0,s2
    80001992:	a8aff0ef          	jal	80000c1c <release>
}
    80001996:	8526                	mv	a0,s1
    80001998:	60e2                	ld	ra,24(sp)
    8000199a:	6442                	ld	s0,16(sp)
    8000199c:	64a2                	ld	s1,8(sp)
    8000199e:	6902                	ld	s2,0(sp)
    800019a0:	6105                	addi	sp,sp,32
    800019a2:	8082                	ret

00000000800019a4 <proc_pagetable>:
{
    800019a4:	1101                	addi	sp,sp,-32
    800019a6:	ec06                	sd	ra,24(sp)
    800019a8:	e822                	sd	s0,16(sp)
    800019aa:	e426                	sd	s1,8(sp)
    800019ac:	e04a                	sd	s2,0(sp)
    800019ae:	1000                	addi	s0,sp,32
    800019b0:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019b2:	f96ff0ef          	jal	80001148 <uvmcreate>
    800019b6:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800019b8:	cd05                	beqz	a0,800019f0 <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    800019ba:	4729                	li	a4,10
    800019bc:	00005697          	auipc	a3,0x5
    800019c0:	64468693          	addi	a3,a3,1604 # 80007000 <_trampoline>
    800019c4:	6605                	lui	a2,0x1
    800019c6:	040005b7          	lui	a1,0x4000
    800019ca:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019cc:	05b2                	slli	a1,a1,0xc
    800019ce:	dd4ff0ef          	jal	80000fa2 <mappages>
    800019d2:	02054663          	bltz	a0,800019fe <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    800019d6:	4719                	li	a4,6
    800019d8:	05893683          	ld	a3,88(s2)
    800019dc:	6605                	lui	a2,0x1
    800019de:	020005b7          	lui	a1,0x2000
    800019e2:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    800019e4:	05b6                	slli	a1,a1,0xd
    800019e6:	8526                	mv	a0,s1
    800019e8:	dbaff0ef          	jal	80000fa2 <mappages>
    800019ec:	00054f63          	bltz	a0,80001a0a <proc_pagetable+0x66>
}
    800019f0:	8526                	mv	a0,s1
    800019f2:	60e2                	ld	ra,24(sp)
    800019f4:	6442                	ld	s0,16(sp)
    800019f6:	64a2                	ld	s1,8(sp)
    800019f8:	6902                	ld	s2,0(sp)
    800019fa:	6105                	addi	sp,sp,32
    800019fc:	8082                	ret
    uvmfree(pagetable, 0);
    800019fe:	4581                	li	a1,0
    80001a00:	8526                	mv	a0,s1
    80001a02:	941ff0ef          	jal	80001342 <uvmfree>
    return 0;
    80001a06:	4481                	li	s1,0
    80001a08:	b7e5                	j	800019f0 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a0a:	4681                	li	a3,0
    80001a0c:	4605                	li	a2,1
    80001a0e:	040005b7          	lui	a1,0x4000
    80001a12:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a14:	05b2                	slli	a1,a1,0xc
    80001a16:	8526                	mv	a0,s1
    80001a18:	f56ff0ef          	jal	8000116e <uvmunmap>
    uvmfree(pagetable, 0);
    80001a1c:	4581                	li	a1,0
    80001a1e:	8526                	mv	a0,s1
    80001a20:	923ff0ef          	jal	80001342 <uvmfree>
    return 0;
    80001a24:	4481                	li	s1,0
    80001a26:	b7e9                	j	800019f0 <proc_pagetable+0x4c>

0000000080001a28 <proc_freepagetable>:
{
    80001a28:	1101                	addi	sp,sp,-32
    80001a2a:	ec06                	sd	ra,24(sp)
    80001a2c:	e822                	sd	s0,16(sp)
    80001a2e:	e426                	sd	s1,8(sp)
    80001a30:	e04a                	sd	s2,0(sp)
    80001a32:	1000                	addi	s0,sp,32
    80001a34:	84aa                	mv	s1,a0
    80001a36:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a38:	4681                	li	a3,0
    80001a3a:	4605                	li	a2,1
    80001a3c:	040005b7          	lui	a1,0x4000
    80001a40:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a42:	05b2                	slli	a1,a1,0xc
    80001a44:	f2aff0ef          	jal	8000116e <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a48:	4681                	li	a3,0
    80001a4a:	4605                	li	a2,1
    80001a4c:	020005b7          	lui	a1,0x2000
    80001a50:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a52:	05b6                	slli	a1,a1,0xd
    80001a54:	8526                	mv	a0,s1
    80001a56:	f18ff0ef          	jal	8000116e <uvmunmap>
  uvmfree(pagetable, sz);
    80001a5a:	85ca                	mv	a1,s2
    80001a5c:	8526                	mv	a0,s1
    80001a5e:	8e5ff0ef          	jal	80001342 <uvmfree>
}
    80001a62:	60e2                	ld	ra,24(sp)
    80001a64:	6442                	ld	s0,16(sp)
    80001a66:	64a2                	ld	s1,8(sp)
    80001a68:	6902                	ld	s2,0(sp)
    80001a6a:	6105                	addi	sp,sp,32
    80001a6c:	8082                	ret

0000000080001a6e <freeproc>:
{
    80001a6e:	1101                	addi	sp,sp,-32
    80001a70:	ec06                	sd	ra,24(sp)
    80001a72:	e822                	sd	s0,16(sp)
    80001a74:	e426                	sd	s1,8(sp)
    80001a76:	1000                	addi	s0,sp,32
    80001a78:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001a7a:	6d28                	ld	a0,88(a0)
    80001a7c:	c119                	beqz	a0,80001a82 <freeproc+0x14>
    kfree((void *)p->trapframe);
    80001a7e:	f6bfe0ef          	jal	800009e8 <kfree>
  p->trapframe = 0;
    80001a82:	0404bc23          	sd	zero,88(s1)
  if (p->pagetable)
    80001a86:	68a8                	ld	a0,80(s1)
    80001a88:	c501                	beqz	a0,80001a90 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001a8a:	64ac                	ld	a1,72(s1)
    80001a8c:	f9dff0ef          	jal	80001a28 <proc_freepagetable>
  p->pagetable = 0;
    80001a90:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001a94:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001a98:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001a9c:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001aa0:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001aa4:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001aa8:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001aac:	0004ac23          	sw	zero,24(s1)
}
    80001ab0:	60e2                	ld	ra,24(sp)
    80001ab2:	6442                	ld	s0,16(sp)
    80001ab4:	64a2                	ld	s1,8(sp)
    80001ab6:	6105                	addi	sp,sp,32
    80001ab8:	8082                	ret

0000000080001aba <allocproc>:
{
    80001aba:	1101                	addi	sp,sp,-32
    80001abc:	ec06                	sd	ra,24(sp)
    80001abe:	e822                	sd	s0,16(sp)
    80001ac0:	e426                	sd	s1,8(sp)
    80001ac2:	e04a                	sd	s2,0(sp)
    80001ac4:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001ac6:	00012497          	auipc	s1,0x12
    80001aca:	f5a48493          	addi	s1,s1,-166 # 80013a20 <proc>
    80001ace:	00018917          	auipc	s2,0x18
    80001ad2:	95290913          	addi	s2,s2,-1710 # 80019420 <tickslock>
    acquire(&p->lock);
    80001ad6:	8526                	mv	a0,s1
    80001ad8:	8b8ff0ef          	jal	80000b90 <acquire>
    if (p->state == UNUSED) {
    80001adc:	4c9c                	lw	a5,24(s1)
    80001ade:	cb91                	beqz	a5,80001af2 <allocproc+0x38>
      release(&p->lock);
    80001ae0:	8526                	mv	a0,s1
    80001ae2:	93aff0ef          	jal	80000c1c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001ae6:	16848493          	addi	s1,s1,360
    80001aea:	ff2496e3          	bne	s1,s2,80001ad6 <allocproc+0x1c>
  return 0;
    80001aee:	4481                	li	s1,0
    80001af0:	a089                	j	80001b32 <allocproc+0x78>
  p->pid = allocpid();
    80001af2:	e75ff0ef          	jal	80001966 <allocpid>
    80001af6:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001af8:	4785                	li	a5,1
    80001afa:	cc9c                	sw	a5,24(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001afc:	fcffe0ef          	jal	80000aca <kalloc>
    80001b00:	892a                	mv	s2,a0
    80001b02:	eca8                	sd	a0,88(s1)
    80001b04:	cd15                	beqz	a0,80001b40 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001b06:	8526                	mv	a0,s1
    80001b08:	e9dff0ef          	jal	800019a4 <proc_pagetable>
    80001b0c:	892a                	mv	s2,a0
    80001b0e:	e8a8                	sd	a0,80(s1)
  if (p->pagetable == 0) {
    80001b10:	c121                	beqz	a0,80001b50 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001b12:	07000613          	li	a2,112
    80001b16:	4581                	li	a1,0
    80001b18:	06048513          	addi	a0,s1,96
    80001b1c:	938ff0ef          	jal	80000c54 <memset>
  p->context.ra = (uint64)forkret;
    80001b20:	00000797          	auipc	a5,0x0
    80001b24:	db278793          	addi	a5,a5,-590 # 800018d2 <forkret>
    80001b28:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b2a:	60bc                	ld	a5,64(s1)
    80001b2c:	6705                	lui	a4,0x1
    80001b2e:	97ba                	add	a5,a5,a4
    80001b30:	f4bc                	sd	a5,104(s1)
}
    80001b32:	8526                	mv	a0,s1
    80001b34:	60e2                	ld	ra,24(sp)
    80001b36:	6442                	ld	s0,16(sp)
    80001b38:	64a2                	ld	s1,8(sp)
    80001b3a:	6902                	ld	s2,0(sp)
    80001b3c:	6105                	addi	sp,sp,32
    80001b3e:	8082                	ret
    freeproc(p);
    80001b40:	8526                	mv	a0,s1
    80001b42:	f2dff0ef          	jal	80001a6e <freeproc>
    release(&p->lock);
    80001b46:	8526                	mv	a0,s1
    80001b48:	8d4ff0ef          	jal	80000c1c <release>
    return 0;
    80001b4c:	84ca                	mv	s1,s2
    80001b4e:	b7d5                	j	80001b32 <allocproc+0x78>
    freeproc(p);
    80001b50:	8526                	mv	a0,s1
    80001b52:	f1dff0ef          	jal	80001a6e <freeproc>
    release(&p->lock);
    80001b56:	8526                	mv	a0,s1
    80001b58:	8c4ff0ef          	jal	80000c1c <release>
    return 0;
    80001b5c:	84ca                	mv	s1,s2
    80001b5e:	bfd1                	j	80001b32 <allocproc+0x78>

0000000080001b60 <userinit>:
{
    80001b60:	1101                	addi	sp,sp,-32
    80001b62:	ec06                	sd	ra,24(sp)
    80001b64:	e822                	sd	s0,16(sp)
    80001b66:	e426                	sd	s1,8(sp)
    80001b68:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b6a:	f51ff0ef          	jal	80001aba <allocproc>
    80001b6e:	84aa                	mv	s1,a0
  initproc = p;
    80001b70:	0000a797          	auipc	a5,0xa
    80001b74:	94a7bc23          	sd	a0,-1704(a5) # 8000b4c8 <initproc>
  p->cwd = namei("/");
    80001b78:	00006517          	auipc	a0,0x6
    80001b7c:	61850513          	addi	a0,a0,1560 # 80008190 <etext+0x190>
    80001b80:	4ba020ef          	jal	8000403a <namei>
    80001b84:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001b88:	478d                	li	a5,3
    80001b8a:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001b8c:	8526                	mv	a0,s1
    80001b8e:	88eff0ef          	jal	80000c1c <release>
}
    80001b92:	60e2                	ld	ra,24(sp)
    80001b94:	6442                	ld	s0,16(sp)
    80001b96:	64a2                	ld	s1,8(sp)
    80001b98:	6105                	addi	sp,sp,32
    80001b9a:	8082                	ret

0000000080001b9c <growproc>:
{
    80001b9c:	1101                	addi	sp,sp,-32
    80001b9e:	ec06                	sd	ra,24(sp)
    80001ba0:	e822                	sd	s0,16(sp)
    80001ba2:	e426                	sd	s1,8(sp)
    80001ba4:	e04a                	sd	s2,0(sp)
    80001ba6:	1000                	addi	s0,sp,32
    80001ba8:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001baa:	cf9ff0ef          	jal	800018a2 <myproc>
    80001bae:	892a                	mv	s2,a0
  sz = p->sz;
    80001bb0:	652c                	ld	a1,72(a0)
  if (n > 0) {
    80001bb2:	02905963          	blez	s1,80001be4 <growproc+0x48>
    if (sz + n > TRAPFRAME) {
    80001bb6:	00b48633          	add	a2,s1,a1
    80001bba:	020007b7          	lui	a5,0x2000
    80001bbe:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001bc0:	07b6                	slli	a5,a5,0xd
    80001bc2:	02c7ea63          	bltu	a5,a2,80001bf6 <growproc+0x5a>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001bc6:	4691                	li	a3,4
    80001bc8:	6928                	ld	a0,80(a0)
    80001bca:	e72ff0ef          	jal	8000123c <uvmalloc>
    80001bce:	85aa                	mv	a1,a0
    80001bd0:	c50d                	beqz	a0,80001bfa <growproc+0x5e>
  p->sz = sz;
    80001bd2:	04b93423          	sd	a1,72(s2)
  return 0;
    80001bd6:	4501                	li	a0,0
}
    80001bd8:	60e2                	ld	ra,24(sp)
    80001bda:	6442                	ld	s0,16(sp)
    80001bdc:	64a2                	ld	s1,8(sp)
    80001bde:	6902                	ld	s2,0(sp)
    80001be0:	6105                	addi	sp,sp,32
    80001be2:	8082                	ret
  } else if (n < 0) {
    80001be4:	fe04d7e3          	bgez	s1,80001bd2 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001be8:	00b48633          	add	a2,s1,a1
    80001bec:	6928                	ld	a0,80(a0)
    80001bee:	e0aff0ef          	jal	800011f8 <uvmdealloc>
    80001bf2:	85aa                	mv	a1,a0
    80001bf4:	bff9                	j	80001bd2 <growproc+0x36>
      return -1;
    80001bf6:	557d                	li	a0,-1
    80001bf8:	b7c5                	j	80001bd8 <growproc+0x3c>
      return -1;
    80001bfa:	557d                	li	a0,-1
    80001bfc:	bff1                	j	80001bd8 <growproc+0x3c>

0000000080001bfe <kfork>:
{
    80001bfe:	7139                	addi	sp,sp,-64
    80001c00:	fc06                	sd	ra,56(sp)
    80001c02:	f822                	sd	s0,48(sp)
    80001c04:	f04a                	sd	s2,32(sp)
    80001c06:	e456                	sd	s5,8(sp)
    80001c08:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c0a:	c99ff0ef          	jal	800018a2 <myproc>
    80001c0e:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001c10:	eabff0ef          	jal	80001aba <allocproc>
    80001c14:	0e050a63          	beqz	a0,80001d08 <kfork+0x10a>
    80001c18:	e852                	sd	s4,16(sp)
    80001c1a:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001c1c:	048ab603          	ld	a2,72(s5)
    80001c20:	692c                	ld	a1,80(a0)
    80001c22:	050ab503          	ld	a0,80(s5)
    80001c26:	f4eff0ef          	jal	80001374 <uvmcopy>
    80001c2a:	04054a63          	bltz	a0,80001c7e <kfork+0x80>
    80001c2e:	f426                	sd	s1,40(sp)
    80001c30:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c32:	048ab783          	ld	a5,72(s5)
    80001c36:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c3a:	058ab683          	ld	a3,88(s5)
    80001c3e:	87b6                	mv	a5,a3
    80001c40:	058a3703          	ld	a4,88(s4)
    80001c44:	12068693          	addi	a3,a3,288
    80001c48:	0007b803          	ld	a6,0(a5)
    80001c4c:	6788                	ld	a0,8(a5)
    80001c4e:	6b8c                	ld	a1,16(a5)
    80001c50:	6f90                	ld	a2,24(a5)
    80001c52:	01073023          	sd	a6,0(a4) # 1000 <_entry-0x7ffff000>
    80001c56:	e708                	sd	a0,8(a4)
    80001c58:	eb0c                	sd	a1,16(a4)
    80001c5a:	ef10                	sd	a2,24(a4)
    80001c5c:	02078793          	addi	a5,a5,32
    80001c60:	02070713          	addi	a4,a4,32
    80001c64:	fed792e3          	bne	a5,a3,80001c48 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001c68:	058a3783          	ld	a5,88(s4)
    80001c6c:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001c70:	0d0a8493          	addi	s1,s5,208
    80001c74:	0d0a0913          	addi	s2,s4,208
    80001c78:	150a8993          	addi	s3,s5,336
    80001c7c:	a831                	j	80001c98 <kfork+0x9a>
    freeproc(np);
    80001c7e:	8552                	mv	a0,s4
    80001c80:	defff0ef          	jal	80001a6e <freeproc>
    release(&np->lock);
    80001c84:	8552                	mv	a0,s4
    80001c86:	f97fe0ef          	jal	80000c1c <release>
    return -1;
    80001c8a:	597d                	li	s2,-1
    80001c8c:	6a42                	ld	s4,16(sp)
    80001c8e:	a0b5                	j	80001cfa <kfork+0xfc>
  for (i = 0; i < NOFILE; i++)
    80001c90:	04a1                	addi	s1,s1,8
    80001c92:	0921                	addi	s2,s2,8
    80001c94:	01348963          	beq	s1,s3,80001ca6 <kfork+0xa8>
    if (p->ofile[i])
    80001c98:	6088                	ld	a0,0(s1)
    80001c9a:	d97d                	beqz	a0,80001c90 <kfork+0x92>
      np->ofile[i] = filedup(p->ofile[i]);
    80001c9c:	1d9020ef          	jal	80004674 <filedup>
    80001ca0:	00a93023          	sd	a0,0(s2)
    80001ca4:	b7f5                	j	80001c90 <kfork+0x92>
  np->cwd = idup(p->cwd);
    80001ca6:	150ab503          	ld	a0,336(s5)
    80001caa:	2e5010ef          	jal	8000378e <idup>
    80001cae:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cb2:	4641                	li	a2,16
    80001cb4:	158a8593          	addi	a1,s5,344
    80001cb8:	158a0513          	addi	a0,s4,344
    80001cbc:	8d6ff0ef          	jal	80000d92 <safestrcpy>
  pid = np->pid;
    80001cc0:	030a2903          	lw	s2,48(s4)
  release(&np->lock);
    80001cc4:	8552                	mv	a0,s4
    80001cc6:	f57fe0ef          	jal	80000c1c <release>
  acquire(&wait_lock);
    80001cca:	00012497          	auipc	s1,0x12
    80001cce:	93e48493          	addi	s1,s1,-1730 # 80013608 <wait_lock>
    80001cd2:	8526                	mv	a0,s1
    80001cd4:	ebdfe0ef          	jal	80000b90 <acquire>
  np->parent = p;
    80001cd8:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001cdc:	8526                	mv	a0,s1
    80001cde:	f3ffe0ef          	jal	80000c1c <release>
  acquire(&np->lock);
    80001ce2:	8552                	mv	a0,s4
    80001ce4:	eadfe0ef          	jal	80000b90 <acquire>
  np->state = RUNNABLE;
    80001ce8:	478d                	li	a5,3
    80001cea:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001cee:	8552                	mv	a0,s4
    80001cf0:	f2dfe0ef          	jal	80000c1c <release>
  return pid;
    80001cf4:	74a2                	ld	s1,40(sp)
    80001cf6:	69e2                	ld	s3,24(sp)
    80001cf8:	6a42                	ld	s4,16(sp)
}
    80001cfa:	854a                	mv	a0,s2
    80001cfc:	70e2                	ld	ra,56(sp)
    80001cfe:	7442                	ld	s0,48(sp)
    80001d00:	7902                	ld	s2,32(sp)
    80001d02:	6aa2                	ld	s5,8(sp)
    80001d04:	6121                	addi	sp,sp,64
    80001d06:	8082                	ret
    return -1;
    80001d08:	597d                	li	s2,-1
    80001d0a:	bfc5                	j	80001cfa <kfork+0xfc>

0000000080001d0c <scheduler>:
{
    80001d0c:	711d                	addi	sp,sp,-96
    80001d0e:	ec86                	sd	ra,88(sp)
    80001d10:	e8a2                	sd	s0,80(sp)
    80001d12:	e4a6                	sd	s1,72(sp)
    80001d14:	e0ca                	sd	s2,64(sp)
    80001d16:	fc4e                	sd	s3,56(sp)
    80001d18:	f852                	sd	s4,48(sp)
    80001d1a:	f456                	sd	s5,40(sp)
    80001d1c:	f05a                	sd	s6,32(sp)
    80001d1e:	ec5e                	sd	s7,24(sp)
    80001d20:	e862                	sd	s8,16(sp)
    80001d22:	e466                	sd	s9,8(sp)
    80001d24:	1080                	addi	s0,sp,96
    80001d26:	8792                	mv	a5,tp
  int id = r_tp();
    80001d28:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d2a:	00779a93          	slli	s5,a5,0x7
    80001d2e:	00012717          	auipc	a4,0x12
    80001d32:	8c270713          	addi	a4,a4,-1854 # 800135f0 <pid_lock>
    80001d36:	9756                	add	a4,a4,s5
    80001d38:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d3c:	00012717          	auipc	a4,0x12
    80001d40:	8ec70713          	addi	a4,a4,-1812 # 80013628 <cpus+0x8>
    80001d44:	9aba                	add	s5,s5,a4
        p->state = RUNNING;
    80001d46:	4c11                	li	s8,4
        c->proc = p;
    80001d48:	00012b17          	auipc	s6,0x12
    80001d4c:	8a8b0b13          	addi	s6,s6,-1880 # 800135f0 <pid_lock>
    80001d50:	079e                	slli	a5,a5,0x7
    80001d52:	00fb0a33          	add	s4,s6,a5
        found = 1;
    80001d56:	4b85                	li	s7,1
    for (p = proc; p < &proc[NPROC]; p++) {
    80001d58:	00017997          	auipc	s3,0x17
    80001d5c:	6c898993          	addi	s3,s3,1736 # 80019420 <tickslock>
    80001d60:	a0a9                	j	80001daa <scheduler+0x9e>
      release(&p->lock);
    80001d62:	8526                	mv	a0,s1
    80001d64:	eb9fe0ef          	jal	80000c1c <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    80001d68:	16848493          	addi	s1,s1,360
    80001d6c:	03348b63          	beq	s1,s3,80001da2 <scheduler+0x96>
      acquire(&p->lock);
    80001d70:	8526                	mv	a0,s1
    80001d72:	e1ffe0ef          	jal	80000b90 <acquire>
      if (p->state == RUNNABLE) {
    80001d76:	4c9c                	lw	a5,24(s1)
    80001d78:	ff2795e3          	bne	a5,s2,80001d62 <scheduler+0x56>
        p->state = RUNNING;
    80001d7c:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001d80:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001d84:	06048593          	addi	a1,s1,96
    80001d88:	8556                	mv	a0,s5
    80001d8a:	5ec000ef          	jal	80002376 <swtch>
    80001d8e:	8792                	mv	a5,tp
        mycpu()->intena = 0;
    80001d90:	2781                	sext.w	a5,a5
    80001d92:	079e                	slli	a5,a5,0x7
    80001d94:	97da                	add	a5,a5,s6
    80001d96:	0a07a623          	sw	zero,172(a5)
        c->proc = 0;
    80001d9a:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001d9e:	8cde                	mv	s9,s7
    80001da0:	b7c9                	j	80001d62 <scheduler+0x56>
    if (found == 0) {
    80001da2:	000c9463          	bnez	s9,80001daa <scheduler+0x9e>
      asm volatile("wfi");
    80001da6:	10500073          	wfi
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80001daa:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80001dae:	10017073          	csrci	sstatus,2
    int found = 0;
    80001db2:	4c81                	li	s9,0
    for (p = proc; p < &proc[NPROC]; p++) {
    80001db4:	00012497          	auipc	s1,0x12
    80001db8:	c6c48493          	addi	s1,s1,-916 # 80013a20 <proc>
      if (p->state == RUNNABLE) {
    80001dbc:	490d                	li	s2,3
    80001dbe:	bf4d                	j	80001d70 <scheduler+0x64>

0000000080001dc0 <sched>:
{
    80001dc0:	7179                	addi	sp,sp,-48
    80001dc2:	f406                	sd	ra,40(sp)
    80001dc4:	f022                	sd	s0,32(sp)
    80001dc6:	ec26                	sd	s1,24(sp)
    80001dc8:	e84a                	sd	s2,16(sp)
    80001dca:	e44e                	sd	s3,8(sp)
    80001dcc:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001dce:	ad5ff0ef          	jal	800018a2 <myproc>
    80001dd2:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    80001dd4:	d5dfe0ef          	jal	80000b30 <holding>
    80001dd8:	c92d                	beqz	a0,80001e4a <sched+0x8a>
  asm volatile("mv %0, tp" : "=r"(x));
    80001dda:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    80001ddc:	2781                	sext.w	a5,a5
    80001dde:	079e                	slli	a5,a5,0x7
    80001de0:	00012717          	auipc	a4,0x12
    80001de4:	81070713          	addi	a4,a4,-2032 # 800135f0 <pid_lock>
    80001de8:	97ba                	add	a5,a5,a4
    80001dea:	0a87a703          	lw	a4,168(a5)
    80001dee:	4785                	li	a5,1
    80001df0:	06f71363          	bne	a4,a5,80001e56 <sched+0x96>
  if (p->state == RUNNING)
    80001df4:	4c98                	lw	a4,24(s1)
    80001df6:	4791                	li	a5,4
    80001df8:	06f70563          	beq	a4,a5,80001e62 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80001dfc:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e00:	8b89                	andi	a5,a5,2
  if (intr_get())
    80001e02:	e7b5                	bnez	a5,80001e6e <sched+0xae>
  asm volatile("mv %0, tp" : "=r"(x));
    80001e04:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e06:	00011917          	auipc	s2,0x11
    80001e0a:	7ea90913          	addi	s2,s2,2026 # 800135f0 <pid_lock>
    80001e0e:	2781                	sext.w	a5,a5
    80001e10:	079e                	slli	a5,a5,0x7
    80001e12:	97ca                	add	a5,a5,s2
    80001e14:	0ac7a983          	lw	s3,172(a5)
    80001e18:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e1a:	2781                	sext.w	a5,a5
    80001e1c:	079e                	slli	a5,a5,0x7
    80001e1e:	00012597          	auipc	a1,0x12
    80001e22:	80a58593          	addi	a1,a1,-2038 # 80013628 <cpus+0x8>
    80001e26:	95be                	add	a1,a1,a5
    80001e28:	06048513          	addi	a0,s1,96
    80001e2c:	54a000ef          	jal	80002376 <swtch>
    80001e30:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e32:	2781                	sext.w	a5,a5
    80001e34:	079e                	slli	a5,a5,0x7
    80001e36:	993e                	add	s2,s2,a5
    80001e38:	0b392623          	sw	s3,172(s2)
}
    80001e3c:	70a2                	ld	ra,40(sp)
    80001e3e:	7402                	ld	s0,32(sp)
    80001e40:	64e2                	ld	s1,24(sp)
    80001e42:	6942                	ld	s2,16(sp)
    80001e44:	69a2                	ld	s3,8(sp)
    80001e46:	6145                	addi	sp,sp,48
    80001e48:	8082                	ret
    panic("sched p->lock");
    80001e4a:	00006517          	auipc	a0,0x6
    80001e4e:	34e50513          	addi	a0,a0,846 # 80008198 <etext+0x198>
    80001e52:	99ffe0ef          	jal	800007f0 <panic>
    panic("sched locks");
    80001e56:	00006517          	auipc	a0,0x6
    80001e5a:	35250513          	addi	a0,a0,850 # 800081a8 <etext+0x1a8>
    80001e5e:	993fe0ef          	jal	800007f0 <panic>
    panic("sched RUNNING");
    80001e62:	00006517          	auipc	a0,0x6
    80001e66:	35650513          	addi	a0,a0,854 # 800081b8 <etext+0x1b8>
    80001e6a:	987fe0ef          	jal	800007f0 <panic>
    panic("sched interruptible");
    80001e6e:	00006517          	auipc	a0,0x6
    80001e72:	35a50513          	addi	a0,a0,858 # 800081c8 <etext+0x1c8>
    80001e76:	97bfe0ef          	jal	800007f0 <panic>

0000000080001e7a <yield>:
{
    80001e7a:	1101                	addi	sp,sp,-32
    80001e7c:	ec06                	sd	ra,24(sp)
    80001e7e:	e822                	sd	s0,16(sp)
    80001e80:	e426                	sd	s1,8(sp)
    80001e82:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001e84:	a1fff0ef          	jal	800018a2 <myproc>
    80001e88:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001e8a:	d07fe0ef          	jal	80000b90 <acquire>
  p->state = RUNNABLE;
    80001e8e:	478d                	li	a5,3
    80001e90:	cc9c                	sw	a5,24(s1)
  sched();
    80001e92:	f2fff0ef          	jal	80001dc0 <sched>
  release(&p->lock);
    80001e96:	8526                	mv	a0,s1
    80001e98:	d85fe0ef          	jal	80000c1c <release>
}
    80001e9c:	60e2                	ld	ra,24(sp)
    80001e9e:	6442                	ld	s0,16(sp)
    80001ea0:	64a2                	ld	s1,8(sp)
    80001ea2:	6105                	addi	sp,sp,32
    80001ea4:	8082                	ret

0000000080001ea6 <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80001ea6:	1101                	addi	sp,sp,-32
    80001ea8:	ec06                	sd	ra,24(sp)
    80001eaa:	e822                	sd	s0,16(sp)
    80001eac:	e426                	sd	s1,8(sp)
    80001eae:	e04a                	sd	s2,0(sp)
    80001eb0:	1000                	addi	s0,sp,32
    80001eb2:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001eb4:	9efff0ef          	jal	800018a2 <myproc>
    80001eb8:	892a                	mv	s2,a0

  acquire(&p->lock);
    80001eba:	cd7fe0ef          	jal	80000b90 <acquire>
  if (chan == 0)
    80001ebe:	cc81                	beqz	s1,80001ed6 <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80001ec0:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80001ec4:	854a                	mv	a0,s2
    80001ec6:	d57fe0ef          	jal	80000c1c <release>
}
    80001eca:	60e2                	ld	ra,24(sp)
    80001ecc:	6442                	ld	s0,16(sp)
    80001ece:	64a2                	ld	s1,8(sp)
    80001ed0:	6902                	ld	s2,0(sp)
    80001ed2:	6105                	addi	sp,sp,32
    80001ed4:	8082                	ret
    panic("sleep_prepare: zero chan");
    80001ed6:	00006517          	auipc	a0,0x6
    80001eda:	30a50513          	addi	a0,a0,778 # 800081e0 <etext+0x1e0>
    80001ede:	913fe0ef          	jal	800007f0 <panic>

0000000080001ee2 <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    80001ee2:	1101                	addi	sp,sp,-32
    80001ee4:	ec06                	sd	ra,24(sp)
    80001ee6:	e822                	sd	s0,16(sp)
    80001ee8:	e426                	sd	s1,8(sp)
    80001eea:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001eec:	9b7ff0ef          	jal	800018a2 <myproc>
    80001ef0:	84aa                	mv	s1,a0

  acquire(&p->lock);
    80001ef2:	c9ffe0ef          	jal	80000b90 <acquire>
  if (p->chan != 0) {
    80001ef6:	709c                	ld	a5,32(s1)
    80001ef8:	c789                	beqz	a5,80001f02 <sleep+0x20>
    p->state = SLEEPING;
    80001efa:	4789                	li	a5,2
    80001efc:	cc9c                	sw	a5,24(s1)
    sched();
    80001efe:	ec3ff0ef          	jal	80001dc0 <sched>
  }
  release(&p->lock);
    80001f02:	8526                	mv	a0,s1
    80001f04:	d19fe0ef          	jal	80000c1c <release>
}
    80001f08:	60e2                	ld	ra,24(sp)
    80001f0a:	6442                	ld	s0,16(sp)
    80001f0c:	64a2                	ld	s1,8(sp)
    80001f0e:	6105                	addi	sp,sp,32
    80001f10:	8082                	ret

0000000080001f12 <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    80001f12:	7139                	addi	sp,sp,-64
    80001f14:	fc06                	sd	ra,56(sp)
    80001f16:	f822                	sd	s0,48(sp)
    80001f18:	f426                	sd	s1,40(sp)
    80001f1a:	f04a                	sd	s2,32(sp)
    80001f1c:	ec4e                	sd	s3,24(sp)
    80001f1e:	e852                	sd	s4,16(sp)
    80001f20:	e456                	sd	s5,8(sp)
    80001f22:	0080                	addi	s0,sp,64
    80001f24:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001f26:	00012497          	auipc	s1,0x12
    80001f2a:	afa48493          	addi	s1,s1,-1286 # 80013a20 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80001f2e:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80001f30:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f32:	00017997          	auipc	s3,0x17
    80001f36:	4ee98993          	addi	s3,s3,1262 # 80019420 <tickslock>
    80001f3a:	a801                	j	80001f4a <wakeup+0x38>
      }
    }
    release(&p->lock);
    80001f3c:	8526                	mv	a0,s1
    80001f3e:	cdffe0ef          	jal	80000c1c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001f42:	16848493          	addi	s1,s1,360
    80001f46:	03348063          	beq	s1,s3,80001f66 <wakeup+0x54>
    acquire(&p->lock);
    80001f4a:	8526                	mv	a0,s1
    80001f4c:	c45fe0ef          	jal	80000b90 <acquire>
    if (p->chan == chan) {
    80001f50:	709c                	ld	a5,32(s1)
    80001f52:	ff2795e3          	bne	a5,s2,80001f3c <wakeup+0x2a>
      p->chan = 0;
    80001f56:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    80001f5a:	4c9c                	lw	a5,24(s1)
    80001f5c:	ff4790e3          	bne	a5,s4,80001f3c <wakeup+0x2a>
        p->state = RUNNABLE;
    80001f60:	0154ac23          	sw	s5,24(s1)
    80001f64:	bfe1                	j	80001f3c <wakeup+0x2a>
  }
}
    80001f66:	70e2                	ld	ra,56(sp)
    80001f68:	7442                	ld	s0,48(sp)
    80001f6a:	74a2                	ld	s1,40(sp)
    80001f6c:	7902                	ld	s2,32(sp)
    80001f6e:	69e2                	ld	s3,24(sp)
    80001f70:	6a42                	ld	s4,16(sp)
    80001f72:	6aa2                	ld	s5,8(sp)
    80001f74:	6121                	addi	sp,sp,64
    80001f76:	8082                	ret

0000000080001f78 <reparent>:
{
    80001f78:	7179                	addi	sp,sp,-48
    80001f7a:	f406                	sd	ra,40(sp)
    80001f7c:	f022                	sd	s0,32(sp)
    80001f7e:	ec26                	sd	s1,24(sp)
    80001f80:	e84a                	sd	s2,16(sp)
    80001f82:	e44e                	sd	s3,8(sp)
    80001f84:	e052                	sd	s4,0(sp)
    80001f86:	1800                	addi	s0,sp,48
    80001f88:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001f8a:	00012497          	auipc	s1,0x12
    80001f8e:	a9648493          	addi	s1,s1,-1386 # 80013a20 <proc>
      pp->parent = initproc;
    80001f92:	00009a17          	auipc	s4,0x9
    80001f96:	536a0a13          	addi	s4,s4,1334 # 8000b4c8 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    80001f9a:	00017997          	auipc	s3,0x17
    80001f9e:	48698993          	addi	s3,s3,1158 # 80019420 <tickslock>
    80001fa2:	a029                	j	80001fac <reparent+0x34>
    80001fa4:	16848493          	addi	s1,s1,360
    80001fa8:	01348b63          	beq	s1,s3,80001fbe <reparent+0x46>
    if (pp->parent == p) {
    80001fac:	7c9c                	ld	a5,56(s1)
    80001fae:	ff279be3          	bne	a5,s2,80001fa4 <reparent+0x2c>
      pp->parent = initproc;
    80001fb2:	000a3503          	ld	a0,0(s4)
    80001fb6:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001fb8:	f5bff0ef          	jal	80001f12 <wakeup>
    80001fbc:	b7e5                	j	80001fa4 <reparent+0x2c>
}
    80001fbe:	70a2                	ld	ra,40(sp)
    80001fc0:	7402                	ld	s0,32(sp)
    80001fc2:	64e2                	ld	s1,24(sp)
    80001fc4:	6942                	ld	s2,16(sp)
    80001fc6:	69a2                	ld	s3,8(sp)
    80001fc8:	6a02                	ld	s4,0(sp)
    80001fca:	6145                	addi	sp,sp,48
    80001fcc:	8082                	ret

0000000080001fce <kexit>:
{
    80001fce:	7179                	addi	sp,sp,-48
    80001fd0:	f406                	sd	ra,40(sp)
    80001fd2:	f022                	sd	s0,32(sp)
    80001fd4:	ec26                	sd	s1,24(sp)
    80001fd6:	e84a                	sd	s2,16(sp)
    80001fd8:	e44e                	sd	s3,8(sp)
    80001fda:	e052                	sd	s4,0(sp)
    80001fdc:	1800                	addi	s0,sp,48
    80001fde:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001fe0:	8c3ff0ef          	jal	800018a2 <myproc>
    80001fe4:	89aa                	mv	s3,a0
  if (p == initproc)
    80001fe6:	00009797          	auipc	a5,0x9
    80001fea:	4e27b783          	ld	a5,1250(a5) # 8000b4c8 <initproc>
    80001fee:	0d050493          	addi	s1,a0,208
    80001ff2:	15050913          	addi	s2,a0,336
    80001ff6:	00a79f63          	bne	a5,a0,80002014 <kexit+0x46>
    panic("init exiting");
    80001ffa:	00006517          	auipc	a0,0x6
    80001ffe:	20650513          	addi	a0,a0,518 # 80008200 <etext+0x200>
    80002002:	feefe0ef          	jal	800007f0 <panic>
      fileclose(f);
    80002006:	6b4020ef          	jal	800046ba <fileclose>
      p->ofile[fd] = 0;
    8000200a:	0004b023          	sd	zero,0(s1)
  for (int fd = 0; fd < NOFILE; fd++) {
    8000200e:	04a1                	addi	s1,s1,8
    80002010:	01248563          	beq	s1,s2,8000201a <kexit+0x4c>
    if (p->ofile[fd]) {
    80002014:	6088                	ld	a0,0(s1)
    80002016:	f965                	bnez	a0,80002006 <kexit+0x38>
    80002018:	bfdd                	j	8000200e <kexit+0x40>
  begin_op();
    8000201a:	1f4020ef          	jal	8000420e <begin_op>
  iput(p->cwd);
    8000201e:	1509b503          	ld	a0,336(s3)
    80002022:	125010ef          	jal	80003946 <iput>
  end_op();
    80002026:	26e020ef          	jal	80004294 <end_op>
  p->cwd = 0;
    8000202a:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000202e:	00011497          	auipc	s1,0x11
    80002032:	5da48493          	addi	s1,s1,1498 # 80013608 <wait_lock>
    80002036:	8526                	mv	a0,s1
    80002038:	b59fe0ef          	jal	80000b90 <acquire>
  reparent(p);
    8000203c:	854e                	mv	a0,s3
    8000203e:	f3bff0ef          	jal	80001f78 <reparent>
  wakeup(p->parent);
    80002042:	0389b503          	ld	a0,56(s3)
    80002046:	ecdff0ef          	jal	80001f12 <wakeup>
  acquire(&p->lock);
    8000204a:	854e                	mv	a0,s3
    8000204c:	b45fe0ef          	jal	80000b90 <acquire>
  p->xstate = status;
    80002050:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002054:	4795                	li	a5,5
    80002056:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    8000205a:	8526                	mv	a0,s1
    8000205c:	bc1fe0ef          	jal	80000c1c <release>
  sched();
    80002060:	d61ff0ef          	jal	80001dc0 <sched>
  panic("zombie exit");
    80002064:	00006517          	auipc	a0,0x6
    80002068:	1ac50513          	addi	a0,a0,428 # 80008210 <etext+0x210>
    8000206c:	f84fe0ef          	jal	800007f0 <panic>

0000000080002070 <kkill>:
int
kkill(int pid)
{
  struct proc *p;

  if (pid == 0)
    80002070:	c525                	beqz	a0,800020d8 <kkill+0x68>
{
    80002072:	7179                	addi	sp,sp,-48
    80002074:	f406                	sd	ra,40(sp)
    80002076:	f022                	sd	s0,32(sp)
    80002078:	ec26                	sd	s1,24(sp)
    8000207a:	e84a                	sd	s2,16(sp)
    8000207c:	e44e                	sd	s3,8(sp)
    8000207e:	1800                	addi	s0,sp,48
    80002080:	892a                	mv	s2,a0
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    80002082:	00012497          	auipc	s1,0x12
    80002086:	99e48493          	addi	s1,s1,-1634 # 80013a20 <proc>
    8000208a:	00017997          	auipc	s3,0x17
    8000208e:	39698993          	addi	s3,s3,918 # 80019420 <tickslock>
    acquire(&p->lock);
    80002092:	8526                	mv	a0,s1
    80002094:	afdfe0ef          	jal	80000b90 <acquire>
    if (p->pid == pid) {
    80002098:	589c                	lw	a5,48(s1)
    8000209a:	01278b63          	beq	a5,s2,800020b0 <kkill+0x40>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000209e:	8526                	mv	a0,s1
    800020a0:	b7dfe0ef          	jal	80000c1c <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    800020a4:	16848493          	addi	s1,s1,360
    800020a8:	ff3495e3          	bne	s1,s3,80002092 <kkill+0x22>
  }
  return -1;
    800020ac:	557d                	li	a0,-1
    800020ae:	a819                	j	800020c4 <kkill+0x54>
      p->killed = 1;
    800020b0:	4785                	li	a5,1
    800020b2:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    800020b4:	4c98                	lw	a4,24(s1)
    800020b6:	4789                	li	a5,2
    800020b8:	00f70d63          	beq	a4,a5,800020d2 <kkill+0x62>
      release(&p->lock);
    800020bc:	8526                	mv	a0,s1
    800020be:	b5ffe0ef          	jal	80000c1c <release>
      return 0;
    800020c2:	4501                	li	a0,0
}
    800020c4:	70a2                	ld	ra,40(sp)
    800020c6:	7402                	ld	s0,32(sp)
    800020c8:	64e2                	ld	s1,24(sp)
    800020ca:	6942                	ld	s2,16(sp)
    800020cc:	69a2                	ld	s3,8(sp)
    800020ce:	6145                	addi	sp,sp,48
    800020d0:	8082                	ret
        p->state = RUNNABLE;
    800020d2:	478d                	li	a5,3
    800020d4:	cc9c                	sw	a5,24(s1)
    800020d6:	b7dd                	j	800020bc <kkill+0x4c>
    return -1;
    800020d8:	557d                	li	a0,-1
}
    800020da:	8082                	ret

00000000800020dc <setkilled>:

void
setkilled(struct proc *p)
{
    800020dc:	1101                	addi	sp,sp,-32
    800020de:	ec06                	sd	ra,24(sp)
    800020e0:	e822                	sd	s0,16(sp)
    800020e2:	e426                	sd	s1,8(sp)
    800020e4:	1000                	addi	s0,sp,32
    800020e6:	84aa                	mv	s1,a0
  acquire(&p->lock);
    800020e8:	aa9fe0ef          	jal	80000b90 <acquire>
  p->killed = 1;
    800020ec:	4785                	li	a5,1
    800020ee:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    800020f0:	8526                	mv	a0,s1
    800020f2:	b2bfe0ef          	jal	80000c1c <release>
}
    800020f6:	60e2                	ld	ra,24(sp)
    800020f8:	6442                	ld	s0,16(sp)
    800020fa:	64a2                	ld	s1,8(sp)
    800020fc:	6105                	addi	sp,sp,32
    800020fe:	8082                	ret

0000000080002100 <killed>:

int
killed(struct proc *p)
{
    80002100:	1101                	addi	sp,sp,-32
    80002102:	ec06                	sd	ra,24(sp)
    80002104:	e822                	sd	s0,16(sp)
    80002106:	e426                	sd	s1,8(sp)
    80002108:	e04a                	sd	s2,0(sp)
    8000210a:	1000                	addi	s0,sp,32
    8000210c:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    8000210e:	a83fe0ef          	jal	80000b90 <acquire>
  k = p->killed;
    80002112:	0284a903          	lw	s2,40(s1)
  release(&p->lock);
    80002116:	8526                	mv	a0,s1
    80002118:	b05fe0ef          	jal	80000c1c <release>
  return k;
}
    8000211c:	854a                	mv	a0,s2
    8000211e:	60e2                	ld	ra,24(sp)
    80002120:	6442                	ld	s0,16(sp)
    80002122:	64a2                	ld	s1,8(sp)
    80002124:	6902                	ld	s2,0(sp)
    80002126:	6105                	addi	sp,sp,32
    80002128:	8082                	ret

000000008000212a <kwait>:
{
    8000212a:	715d                	addi	sp,sp,-80
    8000212c:	e486                	sd	ra,72(sp)
    8000212e:	e0a2                	sd	s0,64(sp)
    80002130:	fc26                	sd	s1,56(sp)
    80002132:	f84a                	sd	s2,48(sp)
    80002134:	f44e                	sd	s3,40(sp)
    80002136:	f052                	sd	s4,32(sp)
    80002138:	ec56                	sd	s5,24(sp)
    8000213a:	e85a                	sd	s6,16(sp)
    8000213c:	e45e                	sd	s7,8(sp)
    8000213e:	e062                	sd	s8,0(sp)
    80002140:	0880                	addi	s0,sp,80
    80002142:	8b2a                	mv	s6,a0
  struct proc *p = myproc();
    80002144:	f5eff0ef          	jal	800018a2 <myproc>
    80002148:	892a                	mv	s2,a0
  acquire(&wait_lock);
    8000214a:	00011517          	auipc	a0,0x11
    8000214e:	4be50513          	addi	a0,a0,1214 # 80013608 <wait_lock>
    80002152:	a3ffe0ef          	jal	80000b90 <acquire>
    havekids = 0;
    80002156:	4c01                	li	s8,0
        if (pp->state == ZOMBIE) {
    80002158:	4a15                	li	s4,5
        havekids = 1;
    8000215a:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000215c:	00017997          	auipc	s3,0x17
    80002160:	2c498993          	addi	s3,s3,708 # 80019420 <tickslock>
    release(&wait_lock);
    80002164:	00011b97          	auipc	s7,0x11
    80002168:	4a4b8b93          	addi	s7,s7,1188 # 80013608 <wait_lock>
    8000216c:	a84d                	j	8000221e <kwait+0xf4>
          pid = pp->pid;
    8000216e:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    80002172:	000b0e63          	beqz	s6,8000218e <kwait+0x64>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    80002176:	4711                	li	a4,4
    80002178:	02c48693          	addi	a3,s1,44
    8000217c:	865a                	mv	a2,s6
    8000217e:	04893583          	ld	a1,72(s2)
    80002182:	05093503          	ld	a0,80(s2)
    80002186:	b52ff0ef          	jal	800014d8 <copyout>
          if (addr != 0 &&
    8000218a:	02054d63          	bltz	a0,800021c4 <kwait+0x9a>
          pp->parent = 0;
    8000218e:	0204bc23          	sd	zero,56(s1)
          freeproc(pp);
    80002192:	8526                	mv	a0,s1
    80002194:	8dbff0ef          	jal	80001a6e <freeproc>
          release(&pp->lock);
    80002198:	8526                	mv	a0,s1
    8000219a:	a83fe0ef          	jal	80000c1c <release>
          release(&wait_lock);
    8000219e:	00011517          	auipc	a0,0x11
    800021a2:	46a50513          	addi	a0,a0,1130 # 80013608 <wait_lock>
    800021a6:	a77fe0ef          	jal	80000c1c <release>
}
    800021aa:	854e                	mv	a0,s3
    800021ac:	60a6                	ld	ra,72(sp)
    800021ae:	6406                	ld	s0,64(sp)
    800021b0:	74e2                	ld	s1,56(sp)
    800021b2:	7942                	ld	s2,48(sp)
    800021b4:	79a2                	ld	s3,40(sp)
    800021b6:	7a02                	ld	s4,32(sp)
    800021b8:	6ae2                	ld	s5,24(sp)
    800021ba:	6b42                	ld	s6,16(sp)
    800021bc:	6ba2                	ld	s7,8(sp)
    800021be:	6c02                	ld	s8,0(sp)
    800021c0:	6161                	addi	sp,sp,80
    800021c2:	8082                	ret
            release(&pp->lock);
    800021c4:	8526                	mv	a0,s1
    800021c6:	a57fe0ef          	jal	80000c1c <release>
            release(&wait_lock);
    800021ca:	00011517          	auipc	a0,0x11
    800021ce:	43e50513          	addi	a0,a0,1086 # 80013608 <wait_lock>
    800021d2:	a4bfe0ef          	jal	80000c1c <release>
            return -1;
    800021d6:	59fd                	li	s3,-1
    800021d8:	bfc9                	j	800021aa <kwait+0x80>
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800021da:	16848493          	addi	s1,s1,360
    800021de:	03348063          	beq	s1,s3,800021fe <kwait+0xd4>
      if (pp->parent == p) {
    800021e2:	7c9c                	ld	a5,56(s1)
    800021e4:	ff279be3          	bne	a5,s2,800021da <kwait+0xb0>
        acquire(&pp->lock);
    800021e8:	8526                	mv	a0,s1
    800021ea:	9a7fe0ef          	jal	80000b90 <acquire>
        if (pp->state == ZOMBIE) {
    800021ee:	4c9c                	lw	a5,24(s1)
    800021f0:	f7478fe3          	beq	a5,s4,8000216e <kwait+0x44>
        release(&pp->lock);
    800021f4:	8526                	mv	a0,s1
    800021f6:	a27fe0ef          	jal	80000c1c <release>
        havekids = 1;
    800021fa:	8756                	mv	a4,s5
    800021fc:	bff9                	j	800021da <kwait+0xb0>
    if (!havekids || killed(p)) {
    800021fe:	c715                	beqz	a4,8000222a <kwait+0x100>
    80002200:	854a                	mv	a0,s2
    80002202:	effff0ef          	jal	80002100 <killed>
    80002206:	e115                	bnez	a0,8000222a <kwait+0x100>
    sleep_prepare(p); //DOC: wait-sleep
    80002208:	854a                	mv	a0,s2
    8000220a:	c9dff0ef          	jal	80001ea6 <sleep_prepare>
    release(&wait_lock);
    8000220e:	855e                	mv	a0,s7
    80002210:	a0dfe0ef          	jal	80000c1c <release>
    sleep();
    80002214:	ccfff0ef          	jal	80001ee2 <sleep>
    acquire(&wait_lock);
    80002218:	855e                	mv	a0,s7
    8000221a:	977fe0ef          	jal	80000b90 <acquire>
    havekids = 0;
    8000221e:	8762                	mv	a4,s8
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002220:	00012497          	auipc	s1,0x12
    80002224:	80048493          	addi	s1,s1,-2048 # 80013a20 <proc>
    80002228:	bf6d                	j	800021e2 <kwait+0xb8>
      release(&wait_lock);
    8000222a:	00011517          	auipc	a0,0x11
    8000222e:	3de50513          	addi	a0,a0,990 # 80013608 <wait_lock>
    80002232:	9ebfe0ef          	jal	80000c1c <release>
      return -1;
    80002236:	59fd                	li	s3,-1
    80002238:	bf8d                	j	800021aa <kwait+0x80>

000000008000223a <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    8000223a:	7179                	addi	sp,sp,-48
    8000223c:	f406                	sd	ra,40(sp)
    8000223e:	f022                	sd	s0,32(sp)
    80002240:	ec26                	sd	s1,24(sp)
    80002242:	e84a                	sd	s2,16(sp)
    80002244:	e44e                	sd	s3,8(sp)
    80002246:	e052                	sd	s4,0(sp)
    80002248:	1800                	addi	s0,sp,48
    8000224a:	84aa                	mv	s1,a0
    8000224c:	892e                	mv	s2,a1
    8000224e:	89b2                	mv	s3,a2
    80002250:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    80002252:	e50ff0ef          	jal	800018a2 <myproc>
  if (user_dst) {
    80002256:	c085                	beqz	s1,80002276 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    80002258:	8752                	mv	a4,s4
    8000225a:	86ce                	mv	a3,s3
    8000225c:	864a                	mv	a2,s2
    8000225e:	652c                	ld	a1,72(a0)
    80002260:	6928                	ld	a0,80(a0)
    80002262:	a76ff0ef          	jal	800014d8 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002266:	70a2                	ld	ra,40(sp)
    80002268:	7402                	ld	s0,32(sp)
    8000226a:	64e2                	ld	s1,24(sp)
    8000226c:	6942                	ld	s2,16(sp)
    8000226e:	69a2                	ld	s3,8(sp)
    80002270:	6a02                	ld	s4,0(sp)
    80002272:	6145                	addi	sp,sp,48
    80002274:	8082                	ret
    memmove((char *)dst, src, len);
    80002276:	000a061b          	sext.w	a2,s4
    8000227a:	85ce                	mv	a1,s3
    8000227c:	854a                	mv	a0,s2
    8000227e:	a33fe0ef          	jal	80000cb0 <memmove>
    return 0;
    80002282:	8526                	mv	a0,s1
    80002284:	b7cd                	j	80002266 <either_copyout+0x2c>

0000000080002286 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002286:	7179                	addi	sp,sp,-48
    80002288:	f406                	sd	ra,40(sp)
    8000228a:	f022                	sd	s0,32(sp)
    8000228c:	ec26                	sd	s1,24(sp)
    8000228e:	e84a                	sd	s2,16(sp)
    80002290:	e44e                	sd	s3,8(sp)
    80002292:	e052                	sd	s4,0(sp)
    80002294:	1800                	addi	s0,sp,48
    80002296:	892a                	mv	s2,a0
    80002298:	84ae                	mv	s1,a1
    8000229a:	89b2                	mv	s3,a2
    8000229c:	8a36                	mv	s4,a3
  struct proc *p = myproc();
    8000229e:	e04ff0ef          	jal	800018a2 <myproc>
  if (user_src) {
    800022a2:	c085                	beqz	s1,800022c2 <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    800022a4:	8752                	mv	a4,s4
    800022a6:	86ce                	mv	a3,s3
    800022a8:	864a                	mv	a2,s2
    800022aa:	652c                	ld	a1,72(a0)
    800022ac:	6928                	ld	a0,80(a0)
    800022ae:	b16ff0ef          	jal	800015c4 <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    800022b2:	70a2                	ld	ra,40(sp)
    800022b4:	7402                	ld	s0,32(sp)
    800022b6:	64e2                	ld	s1,24(sp)
    800022b8:	6942                	ld	s2,16(sp)
    800022ba:	69a2                	ld	s3,8(sp)
    800022bc:	6a02                	ld	s4,0(sp)
    800022be:	6145                	addi	sp,sp,48
    800022c0:	8082                	ret
    memmove(dst, (char *)src, len);
    800022c2:	000a061b          	sext.w	a2,s4
    800022c6:	85ce                	mv	a1,s3
    800022c8:	854a                	mv	a0,s2
    800022ca:	9e7fe0ef          	jal	80000cb0 <memmove>
    return 0;
    800022ce:	8526                	mv	a0,s1
    800022d0:	b7cd                	j	800022b2 <either_copyin+0x2c>

00000000800022d2 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800022d2:	715d                	addi	sp,sp,-80
    800022d4:	e486                	sd	ra,72(sp)
    800022d6:	e0a2                	sd	s0,64(sp)
    800022d8:	fc26                	sd	s1,56(sp)
    800022da:	f84a                	sd	s2,48(sp)
    800022dc:	f44e                	sd	s3,40(sp)
    800022de:	f052                	sd	s4,32(sp)
    800022e0:	ec56                	sd	s5,24(sp)
    800022e2:	e85a                	sd	s6,16(sp)
    800022e4:	e45e                	sd	s7,8(sp)
    800022e6:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    800022e8:	00006517          	auipc	a0,0x6
    800022ec:	d9050513          	addi	a0,a0,-624 # 80008078 <etext+0x78>
    800022f0:	a1afe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    800022f4:	00012497          	auipc	s1,0x12
    800022f8:	88448493          	addi	s1,s1,-1916 # 80013b78 <proc+0x158>
    800022fc:	00017917          	auipc	s2,0x17
    80002300:	27c90913          	addi	s2,s2,636 # 80019578 <bcache+0xc0>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002304:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002306:	00006997          	auipc	s3,0x6
    8000230a:	f1a98993          	addi	s3,s3,-230 # 80008220 <etext+0x220>
    printk("%d %s %s", p->pid, state, p->name);
    8000230e:	00006a97          	auipc	s5,0x6
    80002312:	f1aa8a93          	addi	s5,s5,-230 # 80008228 <etext+0x228>
    printk("\n");
    80002316:	00006a17          	auipc	s4,0x6
    8000231a:	d62a0a13          	addi	s4,s4,-670 # 80008078 <etext+0x78>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000231e:	00006b97          	auipc	s7,0x6
    80002322:	5dab8b93          	addi	s7,s7,1498 # 800088f8 <states.0>
    80002326:	a829                	j	80002340 <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    80002328:	ed86a583          	lw	a1,-296(a3)
    8000232c:	8556                	mv	a0,s5
    8000232e:	9dcfe0ef          	jal	8000050a <printk>
    printk("\n");
    80002332:	8552                	mv	a0,s4
    80002334:	9d6fe0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002338:	16848493          	addi	s1,s1,360
    8000233c:	03248263          	beq	s1,s2,80002360 <procdump+0x8e>
    if (p->state == UNUSED)
    80002340:	86a6                	mv	a3,s1
    80002342:	ec04a783          	lw	a5,-320(s1)
    80002346:	dbed                	beqz	a5,80002338 <procdump+0x66>
      state = "???";
    80002348:	864e                	mv	a2,s3
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000234a:	fcfb6fe3          	bltu	s6,a5,80002328 <procdump+0x56>
    8000234e:	02079713          	slli	a4,a5,0x20
    80002352:	01d75793          	srli	a5,a4,0x1d
    80002356:	97de                	add	a5,a5,s7
    80002358:	6390                	ld	a2,0(a5)
    8000235a:	f679                	bnez	a2,80002328 <procdump+0x56>
      state = "???";
    8000235c:	864e                	mv	a2,s3
    8000235e:	b7e9                	j	80002328 <procdump+0x56>
  }
}
    80002360:	60a6                	ld	ra,72(sp)
    80002362:	6406                	ld	s0,64(sp)
    80002364:	74e2                	ld	s1,56(sp)
    80002366:	7942                	ld	s2,48(sp)
    80002368:	79a2                	ld	s3,40(sp)
    8000236a:	7a02                	ld	s4,32(sp)
    8000236c:	6ae2                	ld	s5,24(sp)
    8000236e:	6b42                	ld	s6,16(sp)
    80002370:	6ba2                	ld	s7,8(sp)
    80002372:	6161                	addi	sp,sp,80
    80002374:	8082                	ret

0000000080002376 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    80002376:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    8000237a:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    8000237e:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002380:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002382:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    80002386:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    8000238a:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    8000238e:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002392:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002396:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    8000239a:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    8000239e:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800023a2:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800023a6:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800023aa:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800023ae:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800023b2:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800023b4:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    800023b6:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    800023ba:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    800023be:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    800023c2:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    800023c6:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    800023ca:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    800023ce:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    800023d2:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    800023d6:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    800023da:	0685bd83          	ld	s11,104(a1)
        
        ret
    800023de:	8082                	ret

00000000800023e0 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800023e0:	1141                	addi	sp,sp,-16
    800023e2:	e406                	sd	ra,8(sp)
    800023e4:	e022                	sd	s0,0(sp)
    800023e6:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800023e8:	00006597          	auipc	a1,0x6
    800023ec:	e8058593          	addi	a1,a1,-384 # 80008268 <etext+0x268>
    800023f0:	00017517          	auipc	a0,0x17
    800023f4:	03050513          	addi	a0,a0,48 # 80019420 <tickslock>
    800023f8:	f22fe0ef          	jal	80000b1a <initlock>
}
    800023fc:	60a2                	ld	ra,8(sp)
    800023fe:	6402                	ld	s0,0(sp)
    80002400:	0141                	addi	sp,sp,16
    80002402:	8082                	ret

0000000080002404 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002404:	1141                	addi	sp,sp,-16
    80002406:	e422                	sd	s0,8(sp)
    80002408:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    8000240a:	00003797          	auipc	a5,0x3
    8000240e:	6f678793          	addi	a5,a5,1782 # 80005b00 <kernelvec>
    80002412:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002416:	6422                	ld	s0,8(sp)
    80002418:	0141                	addi	sp,sp,16
    8000241a:	8082                	ret

000000008000241c <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    8000241c:	1141                	addi	sp,sp,-16
    8000241e:	e406                	sd	ra,8(sp)
    80002420:	e022                	sd	s0,0(sp)
    80002422:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002424:	c7eff0ef          	jal	800018a2 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80002428:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    8000242c:	04000737          	lui	a4,0x4000
    80002430:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80002432:	0732                	slli	a4,a4,0xc
    80002434:	00005797          	auipc	a5,0x5
    80002438:	bcc78793          	addi	a5,a5,-1076 # 80007000 <_trampoline>
    8000243c:	00005697          	auipc	a3,0x5
    80002440:	bc468693          	addi	a3,a3,-1084 # 80007000 <_trampoline>
    80002444:	8f95                	sub	a5,a5,a3
    80002446:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002448:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    8000244c:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    8000244e:	18002773          	csrr	a4,satp
    80002452:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002454:	6d38                	ld	a4,88(a0)
    80002456:	613c                	ld	a5,64(a0)
    80002458:	6685                	lui	a3,0x1
    8000245a:	97b6                	add	a5,a5,a3
    8000245c:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    8000245e:	6d3c                	ld	a5,88(a0)
    80002460:	00000717          	auipc	a4,0x0
    80002464:	0f870713          	addi	a4,a4,248 # 80002558 <usertrap>
    80002468:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    8000246a:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    8000246c:	8712                	mv	a4,tp
    8000246e:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002470:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002474:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002478:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    8000247c:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002480:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002482:	6f9c                	ld	a5,24(a5)
    80002484:	14179073          	csrw	sepc,a5
}
    80002488:	60a2                	ld	ra,8(sp)
    8000248a:	6402                	ld	s0,0(sp)
    8000248c:	0141                	addi	sp,sp,16
    8000248e:	8082                	ret

0000000080002490 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002490:	1101                	addi	sp,sp,-32
    80002492:	ec06                	sd	ra,24(sp)
    80002494:	e822                	sd	s0,16(sp)
    80002496:	1000                	addi	s0,sp,32
  if (cpuid() == 0) {
    80002498:	bdeff0ef          	jal	80001876 <cpuid>
    8000249c:	cd11                	beqz	a0,800024b8 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    8000249e:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800024a2:	000f4737          	lui	a4,0xf4
    800024a6:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800024aa:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    800024ac:	14d79073          	csrw	stimecmp,a5
}
    800024b0:	60e2                	ld	ra,24(sp)
    800024b2:	6442                	ld	s0,16(sp)
    800024b4:	6105                	addi	sp,sp,32
    800024b6:	8082                	ret
    800024b8:	e426                	sd	s1,8(sp)
    acquire(&tickslock);
    800024ba:	00017497          	auipc	s1,0x17
    800024be:	f6648493          	addi	s1,s1,-154 # 80019420 <tickslock>
    800024c2:	8526                	mv	a0,s1
    800024c4:	eccfe0ef          	jal	80000b90 <acquire>
    ticks++;
    800024c8:	00009517          	auipc	a0,0x9
    800024cc:	00850513          	addi	a0,a0,8 # 8000b4d0 <ticks>
    800024d0:	411c                	lw	a5,0(a0)
    800024d2:	2785                	addiw	a5,a5,1
    800024d4:	c11c                	sw	a5,0(a0)
    wakeup(&ticks);
    800024d6:	a3dff0ef          	jal	80001f12 <wakeup>
    release(&tickslock);
    800024da:	8526                	mv	a0,s1
    800024dc:	f40fe0ef          	jal	80000c1c <release>
    800024e0:	64a2                	ld	s1,8(sp)
    800024e2:	bf75                	j	8000249e <clockintr+0xe>

00000000800024e4 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800024e4:	1101                	addi	sp,sp,-32
    800024e6:	ec06                	sd	ra,24(sp)
    800024e8:	e822                	sd	s0,16(sp)
    800024ea:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    800024ec:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    800024f0:	57fd                	li	a5,-1
    800024f2:	17fe                	slli	a5,a5,0x3f
    800024f4:	07a5                	addi	a5,a5,9
    800024f6:	00f70c63          	beq	a4,a5,8000250e <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    800024fa:	57fd                	li	a5,-1
    800024fc:	17fe                	slli	a5,a5,0x3f
    800024fe:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002500:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    80002502:	04f70763          	beq	a4,a5,80002550 <devintr+0x6c>
  }
}
    80002506:	60e2                	ld	ra,24(sp)
    80002508:	6442                	ld	s0,16(sp)
    8000250a:	6105                	addi	sp,sp,32
    8000250c:	8082                	ret
    8000250e:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002510:	69e030ef          	jal	80005bae <plic_claim>
    80002514:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    80002516:	47a9                	li	a5,10
    80002518:	00f50963          	beq	a0,a5,8000252a <devintr+0x46>
    } else if (irq == VIRTIO0_IRQ) {
    8000251c:	4785                	li	a5,1
    8000251e:	00f50963          	beq	a0,a5,80002530 <devintr+0x4c>
    return 1;
    80002522:	4505                	li	a0,1
    } else if (irq) {
    80002524:	e889                	bnez	s1,80002536 <devintr+0x52>
    80002526:	64a2                	ld	s1,8(sp)
    80002528:	bff9                	j	80002506 <devintr+0x22>
      uartintr();
    8000252a:	c62fe0ef          	jal	8000098c <uartintr>
    if (irq)
    8000252e:	a819                	j	80002544 <devintr+0x60>
      virtio_disk_intr();
    80002530:	369030ef          	jal	80006098 <virtio_disk_intr>
    if (irq)
    80002534:	a801                	j	80002544 <devintr+0x60>
      printk("unexpected interrupt irq=%d\n", irq);
    80002536:	85a6                	mv	a1,s1
    80002538:	00006517          	auipc	a0,0x6
    8000253c:	d3850513          	addi	a0,a0,-712 # 80008270 <etext+0x270>
    80002540:	fcbfd0ef          	jal	8000050a <printk>
      plic_complete(irq);
    80002544:	8526                	mv	a0,s1
    80002546:	68a030ef          	jal	80005bd0 <plic_complete>
    return 1;
    8000254a:	4505                	li	a0,1
    8000254c:	64a2                	ld	s1,8(sp)
    8000254e:	bf65                	j	80002506 <devintr+0x22>
    clockintr();
    80002550:	f41ff0ef          	jal	80002490 <clockintr>
    return 2;
    80002554:	4509                	li	a0,2
    80002556:	bf45                	j	80002506 <devintr+0x22>

0000000080002558 <usertrap>:
{
    80002558:	1101                	addi	sp,sp,-32
    8000255a:	ec06                	sd	ra,24(sp)
    8000255c:	e822                	sd	s0,16(sp)
    8000255e:	e426                	sd	s1,8(sp)
    80002560:	e04a                	sd	s2,0(sp)
    80002562:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002564:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    80002568:	1007f793          	andi	a5,a5,256
    8000256c:	eba5                	bnez	a5,800025dc <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    8000256e:	00003797          	auipc	a5,0x3
    80002572:	59278793          	addi	a5,a5,1426 # 80005b00 <kernelvec>
    80002576:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000257a:	b28ff0ef          	jal	800018a2 <myproc>
    8000257e:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002580:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002582:	14102773          	csrr	a4,sepc
    80002586:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    80002588:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    8000258c:	47a1                	li	a5,8
    8000258e:	04f70d63          	beq	a4,a5,800025e8 <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    80002592:	f53ff0ef          	jal	800024e4 <devintr>
    80002596:	892a                	mv	s2,a0
    80002598:	e54d                	bnez	a0,80002642 <usertrap+0xea>
    8000259a:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    8000259e:	47bd                	li	a5,15
    800025a0:	08f70463          	beq	a4,a5,80002628 <usertrap+0xd0>
    800025a4:	14202773          	csrr	a4,scause
    800025a8:	47b5                	li	a5,13
    800025aa:	06f70f63          	beq	a4,a5,80002628 <usertrap+0xd0>
    800025ae:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800025b2:	5890                	lw	a2,48(s1)
    800025b4:	00006517          	auipc	a0,0x6
    800025b8:	cfc50513          	addi	a0,a0,-772 # 800082b0 <etext+0x2b0>
    800025bc:	f4ffd0ef          	jal	8000050a <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800025c0:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800025c4:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800025c8:	00006517          	auipc	a0,0x6
    800025cc:	d1850513          	addi	a0,a0,-744 # 800082e0 <etext+0x2e0>
    800025d0:	f3bfd0ef          	jal	8000050a <printk>
    setkilled(p);
    800025d4:	8526                	mv	a0,s1
    800025d6:	b07ff0ef          	jal	800020dc <setkilled>
    800025da:	a015                	j	800025fe <usertrap+0xa6>
    panic("usertrap: not from user mode");
    800025dc:	00006517          	auipc	a0,0x6
    800025e0:	cb450513          	addi	a0,a0,-844 # 80008290 <etext+0x290>
    800025e4:	a0cfe0ef          	jal	800007f0 <panic>
    if (killed(p))
    800025e8:	b19ff0ef          	jal	80002100 <killed>
    800025ec:	e915                	bnez	a0,80002620 <usertrap+0xc8>
    p->trapframe->epc += 4;
    800025ee:	6cb8                	ld	a4,88(s1)
    800025f0:	6f1c                	ld	a5,24(a4)
    800025f2:	0791                	addi	a5,a5,4
    800025f4:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    800025f6:	10016073          	csrsi	sstatus,2
    syscall();
    800025fa:	24a000ef          	jal	80002844 <syscall>
  if (killed(p))
    800025fe:	8526                	mv	a0,s1
    80002600:	b01ff0ef          	jal	80002100 <killed>
    80002604:	e521                	bnez	a0,8000264c <usertrap+0xf4>
  prepare_return();
    80002606:	e17ff0ef          	jal	8000241c <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    8000260a:	68a8                	ld	a0,80(s1)
    8000260c:	8131                	srli	a0,a0,0xc
    8000260e:	57fd                	li	a5,-1
    80002610:	17fe                	slli	a5,a5,0x3f
    80002612:	8d5d                	or	a0,a0,a5
}
    80002614:	60e2                	ld	ra,24(sp)
    80002616:	6442                	ld	s0,16(sp)
    80002618:	64a2                	ld	s1,8(sp)
    8000261a:	6902                	ld	s2,0(sp)
    8000261c:	6105                	addi	sp,sp,32
    8000261e:	8082                	ret
      kexit(-1);
    80002620:	557d                	li	a0,-1
    80002622:	9adff0ef          	jal	80001fce <kexit>
    80002626:	b7e1                	j	800025ee <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    80002628:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    8000262c:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    80002630:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    80002632:	0016b693          	seqz	a3,a3
    80002636:	64ac                	ld	a1,72(s1)
    80002638:	68a8                	ld	a0,80(s1)
    8000263a:	e23fe0ef          	jal	8000145c <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    8000263e:	f161                	bnez	a0,800025fe <usertrap+0xa6>
    80002640:	b7bd                	j	800025ae <usertrap+0x56>
  if (killed(p))
    80002642:	8526                	mv	a0,s1
    80002644:	abdff0ef          	jal	80002100 <killed>
    80002648:	c511                	beqz	a0,80002654 <usertrap+0xfc>
    8000264a:	a011                	j	8000264e <usertrap+0xf6>
    8000264c:	4901                	li	s2,0
    kexit(-1);
    8000264e:	557d                	li	a0,-1
    80002650:	97fff0ef          	jal	80001fce <kexit>
  if (which_dev == 2)
    80002654:	4789                	li	a5,2
    80002656:	faf918e3          	bne	s2,a5,80002606 <usertrap+0xae>
    yield();
    8000265a:	821ff0ef          	jal	80001e7a <yield>
    8000265e:	b765                	j	80002606 <usertrap+0xae>

0000000080002660 <kerneltrap>:
{
    80002660:	7179                	addi	sp,sp,-48
    80002662:	f406                	sd	ra,40(sp)
    80002664:	f022                	sd	s0,32(sp)
    80002666:	ec26                	sd	s1,24(sp)
    80002668:	e84a                	sd	s2,16(sp)
    8000266a:	e44e                	sd	s3,8(sp)
    8000266c:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    8000266e:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002672:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    80002676:	142029f3          	csrr	s3,scause
  if ((sstatus & SSTATUS_SPP) == 0)
    8000267a:	1004f793          	andi	a5,s1,256
    8000267e:	c795                	beqz	a5,800026aa <kerneltrap+0x4a>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002680:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002684:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    80002686:	eb85                	bnez	a5,800026b6 <kerneltrap+0x56>
  if ((which_dev = devintr()) == 0) {
    80002688:	e5dff0ef          	jal	800024e4 <devintr>
    8000268c:	c91d                	beqz	a0,800026c2 <kerneltrap+0x62>
  if (which_dev == 2 && myproc() != 0)
    8000268e:	4789                	li	a5,2
    80002690:	04f50a63          	beq	a0,a5,800026e4 <kerneltrap+0x84>
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002694:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002698:	10049073          	csrw	sstatus,s1
}
    8000269c:	70a2                	ld	ra,40(sp)
    8000269e:	7402                	ld	s0,32(sp)
    800026a0:	64e2                	ld	s1,24(sp)
    800026a2:	6942                	ld	s2,16(sp)
    800026a4:	69a2                	ld	s3,8(sp)
    800026a6:	6145                	addi	sp,sp,48
    800026a8:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800026aa:	00006517          	auipc	a0,0x6
    800026ae:	c5e50513          	addi	a0,a0,-930 # 80008308 <etext+0x308>
    800026b2:	93efe0ef          	jal	800007f0 <panic>
    panic("kerneltrap: interrupts enabled");
    800026b6:	00006517          	auipc	a0,0x6
    800026ba:	c7a50513          	addi	a0,a0,-902 # 80008330 <etext+0x330>
    800026be:	932fe0ef          	jal	800007f0 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    800026c2:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    800026c6:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    800026ca:	85ce                	mv	a1,s3
    800026cc:	00006517          	auipc	a0,0x6
    800026d0:	c8450513          	addi	a0,a0,-892 # 80008350 <etext+0x350>
    800026d4:	e37fd0ef          	jal	8000050a <printk>
    panic("kerneltrap");
    800026d8:	00006517          	auipc	a0,0x6
    800026dc:	ca050513          	addi	a0,a0,-864 # 80008378 <etext+0x378>
    800026e0:	910fe0ef          	jal	800007f0 <panic>
  if (which_dev == 2 && myproc() != 0)
    800026e4:	9beff0ef          	jal	800018a2 <myproc>
    800026e8:	d555                	beqz	a0,80002694 <kerneltrap+0x34>
    yield();
    800026ea:	f90ff0ef          	jal	80001e7a <yield>
    800026ee:	b75d                	j	80002694 <kerneltrap+0x34>

00000000800026f0 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800026f0:	1101                	addi	sp,sp,-32
    800026f2:	ec06                	sd	ra,24(sp)
    800026f4:	e822                	sd	s0,16(sp)
    800026f6:	e426                	sd	s1,8(sp)
    800026f8:	1000                	addi	s0,sp,32
    800026fa:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800026fc:	9a6ff0ef          	jal	800018a2 <myproc>
  switch (n) {
    80002700:	4795                	li	a5,5
    80002702:	0497e163          	bltu	a5,s1,80002744 <argraw+0x54>
    80002706:	048a                	slli	s1,s1,0x2
    80002708:	00006717          	auipc	a4,0x6
    8000270c:	22070713          	addi	a4,a4,544 # 80008928 <states.0+0x30>
    80002710:	94ba                	add	s1,s1,a4
    80002712:	409c                	lw	a5,0(s1)
    80002714:	97ba                	add	a5,a5,a4
    80002716:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002718:	6d3c                	ld	a5,88(a0)
    8000271a:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    8000271c:	60e2                	ld	ra,24(sp)
    8000271e:	6442                	ld	s0,16(sp)
    80002720:	64a2                	ld	s1,8(sp)
    80002722:	6105                	addi	sp,sp,32
    80002724:	8082                	ret
    return p->trapframe->a1;
    80002726:	6d3c                	ld	a5,88(a0)
    80002728:	7fa8                	ld	a0,120(a5)
    8000272a:	bfcd                	j	8000271c <argraw+0x2c>
    return p->trapframe->a2;
    8000272c:	6d3c                	ld	a5,88(a0)
    8000272e:	63c8                	ld	a0,128(a5)
    80002730:	b7f5                	j	8000271c <argraw+0x2c>
    return p->trapframe->a3;
    80002732:	6d3c                	ld	a5,88(a0)
    80002734:	67c8                	ld	a0,136(a5)
    80002736:	b7dd                	j	8000271c <argraw+0x2c>
    return p->trapframe->a4;
    80002738:	6d3c                	ld	a5,88(a0)
    8000273a:	6bc8                	ld	a0,144(a5)
    8000273c:	b7c5                	j	8000271c <argraw+0x2c>
    return p->trapframe->a5;
    8000273e:	6d3c                	ld	a5,88(a0)
    80002740:	6fc8                	ld	a0,152(a5)
    80002742:	bfe9                	j	8000271c <argraw+0x2c>
  panic("argraw");
    80002744:	00006517          	auipc	a0,0x6
    80002748:	c4450513          	addi	a0,a0,-956 # 80008388 <etext+0x388>
    8000274c:	8a4fe0ef          	jal	800007f0 <panic>

0000000080002750 <fetchaddr>:
{
    80002750:	1101                	addi	sp,sp,-32
    80002752:	ec06                	sd	ra,24(sp)
    80002754:	e822                	sd	s0,16(sp)
    80002756:	e426                	sd	s1,8(sp)
    80002758:	e04a                	sd	s2,0(sp)
    8000275a:	1000                	addi	s0,sp,32
    8000275c:	84aa                	mv	s1,a0
    8000275e:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002760:	942ff0ef          	jal	800018a2 <myproc>
  if (addr >= p->sz ||
    80002764:	652c                	ld	a1,72(a0)
    80002766:	02b4f663          	bgeu	s1,a1,80002792 <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    8000276a:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    8000276e:	02f5e463          	bltu	a1,a5,80002796 <fetchaddr+0x46>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    80002772:	4721                	li	a4,8
    80002774:	86a6                	mv	a3,s1
    80002776:	864a                	mv	a2,s2
    80002778:	6928                	ld	a0,80(a0)
    8000277a:	e4bfe0ef          	jal	800015c4 <copyin>
    8000277e:	00a03533          	snez	a0,a0
    80002782:	40a00533          	neg	a0,a0
}
    80002786:	60e2                	ld	ra,24(sp)
    80002788:	6442                	ld	s0,16(sp)
    8000278a:	64a2                	ld	s1,8(sp)
    8000278c:	6902                	ld	s2,0(sp)
    8000278e:	6105                	addi	sp,sp,32
    80002790:	8082                	ret
    return -1;
    80002792:	557d                	li	a0,-1
    80002794:	bfcd                	j	80002786 <fetchaddr+0x36>
    80002796:	557d                	li	a0,-1
    80002798:	b7fd                	j	80002786 <fetchaddr+0x36>

000000008000279a <fetchstr>:
{
    8000279a:	7179                	addi	sp,sp,-48
    8000279c:	f406                	sd	ra,40(sp)
    8000279e:	f022                	sd	s0,32(sp)
    800027a0:	ec26                	sd	s1,24(sp)
    800027a2:	e84a                	sd	s2,16(sp)
    800027a4:	e44e                	sd	s3,8(sp)
    800027a6:	1800                	addi	s0,sp,48
    800027a8:	892a                	mv	s2,a0
    800027aa:	84ae                	mv	s1,a1
    800027ac:	89b2                	mv	s3,a2
  struct proc *p = myproc();
    800027ae:	8f4ff0ef          	jal	800018a2 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    800027b2:	874e                	mv	a4,s3
    800027b4:	86ca                	mv	a3,s2
    800027b6:	8626                	mv	a2,s1
    800027b8:	652c                	ld	a1,72(a0)
    800027ba:	6928                	ld	a0,80(a0)
    800027bc:	e9ffe0ef          	jal	8000165a <copyinstr>
    800027c0:	00054c63          	bltz	a0,800027d8 <fetchstr+0x3e>
  return strlen(buf);
    800027c4:	8526                	mv	a0,s1
    800027c6:	dfefe0ef          	jal	80000dc4 <strlen>
}
    800027ca:	70a2                	ld	ra,40(sp)
    800027cc:	7402                	ld	s0,32(sp)
    800027ce:	64e2                	ld	s1,24(sp)
    800027d0:	6942                	ld	s2,16(sp)
    800027d2:	69a2                	ld	s3,8(sp)
    800027d4:	6145                	addi	sp,sp,48
    800027d6:	8082                	ret
    return -1;
    800027d8:	557d                	li	a0,-1
    800027da:	bfc5                	j	800027ca <fetchstr+0x30>

00000000800027dc <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800027dc:	1101                	addi	sp,sp,-32
    800027de:	ec06                	sd	ra,24(sp)
    800027e0:	e822                	sd	s0,16(sp)
    800027e2:	e426                	sd	s1,8(sp)
    800027e4:	1000                	addi	s0,sp,32
    800027e6:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027e8:	f09ff0ef          	jal	800026f0 <argraw>
    800027ec:	c088                	sw	a0,0(s1)
}
    800027ee:	60e2                	ld	ra,24(sp)
    800027f0:	6442                	ld	s0,16(sp)
    800027f2:	64a2                	ld	s1,8(sp)
    800027f4:	6105                	addi	sp,sp,32
    800027f6:	8082                	ret

00000000800027f8 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800027f8:	1101                	addi	sp,sp,-32
    800027fa:	ec06                	sd	ra,24(sp)
    800027fc:	e822                	sd	s0,16(sp)
    800027fe:	e426                	sd	s1,8(sp)
    80002800:	1000                	addi	s0,sp,32
    80002802:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002804:	eedff0ef          	jal	800026f0 <argraw>
    80002808:	e088                	sd	a0,0(s1)
}
    8000280a:	60e2                	ld	ra,24(sp)
    8000280c:	6442                	ld	s0,16(sp)
    8000280e:	64a2                	ld	s1,8(sp)
    80002810:	6105                	addi	sp,sp,32
    80002812:	8082                	ret

0000000080002814 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002814:	7179                	addi	sp,sp,-48
    80002816:	f406                	sd	ra,40(sp)
    80002818:	f022                	sd	s0,32(sp)
    8000281a:	ec26                	sd	s1,24(sp)
    8000281c:	e84a                	sd	s2,16(sp)
    8000281e:	1800                	addi	s0,sp,48
    80002820:	84ae                	mv	s1,a1
    80002822:	8932                	mv	s2,a2
  uint64 addr;
  argaddr(n, &addr);
    80002824:	fd840593          	addi	a1,s0,-40
    80002828:	fd1ff0ef          	jal	800027f8 <argaddr>
  return fetchstr(addr, buf, max);
    8000282c:	864a                	mv	a2,s2
    8000282e:	85a6                	mv	a1,s1
    80002830:	fd843503          	ld	a0,-40(s0)
    80002834:	f67ff0ef          	jal	8000279a <fetchstr>
}
    80002838:	70a2                	ld	ra,40(sp)
    8000283a:	7402                	ld	s0,32(sp)
    8000283c:	64e2                	ld	s1,24(sp)
    8000283e:	6942                	ld	s2,16(sp)
    80002840:	6145                	addi	sp,sp,48
    80002842:	8082                	ret

0000000080002844 <syscall>:
  // clang-format on
};

void
syscall(void)
{
    80002844:	1101                	addi	sp,sp,-32
    80002846:	ec06                	sd	ra,24(sp)
    80002848:	e822                	sd	s0,16(sp)
    8000284a:	e426                	sd	s1,8(sp)
    8000284c:	e04a                	sd	s2,0(sp)
    8000284e:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002850:	852ff0ef          	jal	800018a2 <myproc>
    80002854:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002856:	05853903          	ld	s2,88(a0)
    8000285a:	0a893783          	ld	a5,168(s2)
    8000285e:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002862:	37fd                	addiw	a5,a5,-1
    80002864:	4761                	li	a4,24
    80002866:	00f76f63          	bltu	a4,a5,80002884 <syscall+0x40>
    8000286a:	00369713          	slli	a4,a3,0x3
    8000286e:	00006797          	auipc	a5,0x6
    80002872:	0d278793          	addi	a5,a5,210 # 80008940 <syscalls>
    80002876:	97ba                	add	a5,a5,a4
    80002878:	639c                	ld	a5,0(a5)
    8000287a:	c789                	beqz	a5,80002884 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    8000287c:	9782                	jalr	a5
    8000287e:	06a93823          	sd	a0,112(s2)
    80002882:	a829                	j	8000289c <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    80002884:	15848613          	addi	a2,s1,344
    80002888:	588c                	lw	a1,48(s1)
    8000288a:	00006517          	auipc	a0,0x6
    8000288e:	b0650513          	addi	a0,a0,-1274 # 80008390 <etext+0x390>
    80002892:	c79fd0ef          	jal	8000050a <printk>
    p->trapframe->a0 = -1;
    80002896:	6cbc                	ld	a5,88(s1)
    80002898:	577d                	li	a4,-1
    8000289a:	fbb8                	sd	a4,112(a5)
  }
}
    8000289c:	60e2                	ld	ra,24(sp)
    8000289e:	6442                	ld	s0,16(sp)
    800028a0:	64a2                	ld	s1,8(sp)
    800028a2:	6902                	ld	s2,0(sp)
    800028a4:	6105                	addi	sp,sp,32
    800028a6:	8082                	ret

00000000800028a8 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    800028a8:	1101                	addi	sp,sp,-32
    800028aa:	ec06                	sd	ra,24(sp)
    800028ac:	e822                	sd	s0,16(sp)
    800028ae:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    800028b0:	fec40593          	addi	a1,s0,-20
    800028b4:	4501                	li	a0,0
    800028b6:	f27ff0ef          	jal	800027dc <argint>
  kexit(n);
    800028ba:	fec42503          	lw	a0,-20(s0)
    800028be:	f10ff0ef          	jal	80001fce <kexit>
  return 0; // not reached
}
    800028c2:	4501                	li	a0,0
    800028c4:	60e2                	ld	ra,24(sp)
    800028c6:	6442                	ld	s0,16(sp)
    800028c8:	6105                	addi	sp,sp,32
    800028ca:	8082                	ret

00000000800028cc <sys_getpid>:

uint64
sys_getpid(void)
{
    800028cc:	1141                	addi	sp,sp,-16
    800028ce:	e406                	sd	ra,8(sp)
    800028d0:	e022                	sd	s0,0(sp)
    800028d2:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800028d4:	fcffe0ef          	jal	800018a2 <myproc>
}
    800028d8:	5908                	lw	a0,48(a0)
    800028da:	60a2                	ld	ra,8(sp)
    800028dc:	6402                	ld	s0,0(sp)
    800028de:	0141                	addi	sp,sp,16
    800028e0:	8082                	ret

00000000800028e2 <sys_fork>:

uint64
sys_fork(void)
{
    800028e2:	1141                	addi	sp,sp,-16
    800028e4:	e406                	sd	ra,8(sp)
    800028e6:	e022                	sd	s0,0(sp)
    800028e8:	0800                	addi	s0,sp,16
  return kfork();
    800028ea:	b14ff0ef          	jal	80001bfe <kfork>
}
    800028ee:	60a2                	ld	ra,8(sp)
    800028f0:	6402                	ld	s0,0(sp)
    800028f2:	0141                	addi	sp,sp,16
    800028f4:	8082                	ret

00000000800028f6 <sys_wait>:

uint64
sys_wait(void)
{
    800028f6:	1101                	addi	sp,sp,-32
    800028f8:	ec06                	sd	ra,24(sp)
    800028fa:	e822                	sd	s0,16(sp)
    800028fc:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    800028fe:	fe840593          	addi	a1,s0,-24
    80002902:	4501                	li	a0,0
    80002904:	ef5ff0ef          	jal	800027f8 <argaddr>
  return kwait(p);
    80002908:	fe843503          	ld	a0,-24(s0)
    8000290c:	81fff0ef          	jal	8000212a <kwait>
}
    80002910:	60e2                	ld	ra,24(sp)
    80002912:	6442                	ld	s0,16(sp)
    80002914:	6105                	addi	sp,sp,32
    80002916:	8082                	ret

0000000080002918 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002918:	7179                	addi	sp,sp,-48
    8000291a:	f406                	sd	ra,40(sp)
    8000291c:	f022                	sd	s0,32(sp)
    8000291e:	ec26                	sd	s1,24(sp)
    80002920:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002922:	fd840593          	addi	a1,s0,-40
    80002926:	4501                	li	a0,0
    80002928:	eb5ff0ef          	jal	800027dc <argint>
  argint(1, &t);
    8000292c:	fdc40593          	addi	a1,s0,-36
    80002930:	4505                	li	a0,1
    80002932:	eabff0ef          	jal	800027dc <argint>
  addr = myproc()->sz;
    80002936:	f6dfe0ef          	jal	800018a2 <myproc>
    8000293a:	6524                	ld	s1,72(a0)

  if (t == SBRK_EAGER || n < 0) {
    8000293c:	fdc42703          	lw	a4,-36(s0)
    80002940:	4785                	li	a5,1
    80002942:	02f70763          	beq	a4,a5,80002970 <sys_sbrk+0x58>
    80002946:	fd842783          	lw	a5,-40(s0)
    8000294a:	0207c363          	bltz	a5,80002970 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    8000294e:	97a6                	add	a5,a5,s1
    80002950:	0297ee63          	bltu	a5,s1,8000298c <sys_sbrk+0x74>
      return -1;
    if (addr + n > TRAPFRAME)
    80002954:	02000737          	lui	a4,0x2000
    80002958:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    8000295a:	0736                	slli	a4,a4,0xd
    8000295c:	02f76a63          	bltu	a4,a5,80002990 <sys_sbrk+0x78>
      return -1;
    myproc()->sz += n;
    80002960:	f43fe0ef          	jal	800018a2 <myproc>
    80002964:	fd842703          	lw	a4,-40(s0)
    80002968:	653c                	ld	a5,72(a0)
    8000296a:	97ba                	add	a5,a5,a4
    8000296c:	e53c                	sd	a5,72(a0)
    8000296e:	a039                	j	8000297c <sys_sbrk+0x64>
    if (growproc(n) < 0) {
    80002970:	fd842503          	lw	a0,-40(s0)
    80002974:	a28ff0ef          	jal	80001b9c <growproc>
    80002978:	00054863          	bltz	a0,80002988 <sys_sbrk+0x70>
  }
  return addr;
}
    8000297c:	8526                	mv	a0,s1
    8000297e:	70a2                	ld	ra,40(sp)
    80002980:	7402                	ld	s0,32(sp)
    80002982:	64e2                	ld	s1,24(sp)
    80002984:	6145                	addi	sp,sp,48
    80002986:	8082                	ret
      return -1;
    80002988:	54fd                	li	s1,-1
    8000298a:	bfcd                	j	8000297c <sys_sbrk+0x64>
      return -1;
    8000298c:	54fd                	li	s1,-1
    8000298e:	b7fd                	j	8000297c <sys_sbrk+0x64>
      return -1;
    80002990:	54fd                	li	s1,-1
    80002992:	b7ed                	j	8000297c <sys_sbrk+0x64>

0000000080002994 <sys_pause>:

uint64
sys_pause(void)
{
    80002994:	7139                	addi	sp,sp,-64
    80002996:	fc06                	sd	ra,56(sp)
    80002998:	f822                	sd	s0,48(sp)
    8000299a:	ec4e                	sd	s3,24(sp)
    8000299c:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    8000299e:	fcc40593          	addi	a1,s0,-52
    800029a2:	4501                	li	a0,0
    800029a4:	e39ff0ef          	jal	800027dc <argint>
  if (n < 0)
    800029a8:	fcc42783          	lw	a5,-52(s0)
    800029ac:	0607cf63          	bltz	a5,80002a2a <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    800029b0:	00017517          	auipc	a0,0x17
    800029b4:	a7050513          	addi	a0,a0,-1424 # 80019420 <tickslock>
    800029b8:	9d8fe0ef          	jal	80000b90 <acquire>
  ticks0 = ticks;
    800029bc:	00009997          	auipc	s3,0x9
    800029c0:	b149a983          	lw	s3,-1260(s3) # 8000b4d0 <ticks>
  while (ticks - ticks0 < n) {
    800029c4:	fcc42783          	lw	a5,-52(s0)
    800029c8:	c7a9                	beqz	a5,80002a12 <sys_pause+0x7e>
    800029ca:	f426                	sd	s1,40(sp)
    800029cc:	f04a                	sd	s2,32(sp)
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    800029ce:	00009917          	auipc	s2,0x9
    800029d2:	b0290913          	addi	s2,s2,-1278 # 8000b4d0 <ticks>
    release(&tickslock);
    800029d6:	00017497          	auipc	s1,0x17
    800029da:	a4a48493          	addi	s1,s1,-1462 # 80019420 <tickslock>
    if (killed(myproc())) {
    800029de:	ec5fe0ef          	jal	800018a2 <myproc>
    800029e2:	f1eff0ef          	jal	80002100 <killed>
    800029e6:	e529                	bnez	a0,80002a30 <sys_pause+0x9c>
    sleep_prepare(&ticks);
    800029e8:	854a                	mv	a0,s2
    800029ea:	cbcff0ef          	jal	80001ea6 <sleep_prepare>
    release(&tickslock);
    800029ee:	8526                	mv	a0,s1
    800029f0:	a2cfe0ef          	jal	80000c1c <release>
    sleep();
    800029f4:	ceeff0ef          	jal	80001ee2 <sleep>
    acquire(&tickslock);
    800029f8:	8526                	mv	a0,s1
    800029fa:	996fe0ef          	jal	80000b90 <acquire>
  while (ticks - ticks0 < n) {
    800029fe:	00092783          	lw	a5,0(s2)
    80002a02:	413787bb          	subw	a5,a5,s3
    80002a06:	fcc42703          	lw	a4,-52(s0)
    80002a0a:	fce7eae3          	bltu	a5,a4,800029de <sys_pause+0x4a>
    80002a0e:	74a2                	ld	s1,40(sp)
    80002a10:	7902                	ld	s2,32(sp)
  }
  release(&tickslock);
    80002a12:	00017517          	auipc	a0,0x17
    80002a16:	a0e50513          	addi	a0,a0,-1522 # 80019420 <tickslock>
    80002a1a:	a02fe0ef          	jal	80000c1c <release>
  return 0;
    80002a1e:	4501                	li	a0,0
}
    80002a20:	70e2                	ld	ra,56(sp)
    80002a22:	7442                	ld	s0,48(sp)
    80002a24:	69e2                	ld	s3,24(sp)
    80002a26:	6121                	addi	sp,sp,64
    80002a28:	8082                	ret
    n = 0;
    80002a2a:	fc042623          	sw	zero,-52(s0)
    80002a2e:	b749                	j	800029b0 <sys_pause+0x1c>
      release(&tickslock);
    80002a30:	00017517          	auipc	a0,0x17
    80002a34:	9f050513          	addi	a0,a0,-1552 # 80019420 <tickslock>
    80002a38:	9e4fe0ef          	jal	80000c1c <release>
      return -1;
    80002a3c:	557d                	li	a0,-1
    80002a3e:	74a2                	ld	s1,40(sp)
    80002a40:	7902                	ld	s2,32(sp)
    80002a42:	bff9                	j	80002a20 <sys_pause+0x8c>

0000000080002a44 <sys_kill>:

uint64
sys_kill(void)
{
    80002a44:	1101                	addi	sp,sp,-32
    80002a46:	ec06                	sd	ra,24(sp)
    80002a48:	e822                	sd	s0,16(sp)
    80002a4a:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002a4c:	fec40593          	addi	a1,s0,-20
    80002a50:	4501                	li	a0,0
    80002a52:	d8bff0ef          	jal	800027dc <argint>
  return kkill(pid);
    80002a56:	fec42503          	lw	a0,-20(s0)
    80002a5a:	e16ff0ef          	jal	80002070 <kkill>
}
    80002a5e:	60e2                	ld	ra,24(sp)
    80002a60:	6442                	ld	s0,16(sp)
    80002a62:	6105                	addi	sp,sp,32
    80002a64:	8082                	ret

0000000080002a66 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002a66:	1101                	addi	sp,sp,-32
    80002a68:	ec06                	sd	ra,24(sp)
    80002a6a:	e822                	sd	s0,16(sp)
    80002a6c:	e426                	sd	s1,8(sp)
    80002a6e:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002a70:	00017517          	auipc	a0,0x17
    80002a74:	9b050513          	addi	a0,a0,-1616 # 80019420 <tickslock>
    80002a78:	918fe0ef          	jal	80000b90 <acquire>
  xticks = ticks;
    80002a7c:	00009497          	auipc	s1,0x9
    80002a80:	a544a483          	lw	s1,-1452(s1) # 8000b4d0 <ticks>
  release(&tickslock);
    80002a84:	00017517          	auipc	a0,0x17
    80002a88:	99c50513          	addi	a0,a0,-1636 # 80019420 <tickslock>
    80002a8c:	990fe0ef          	jal	80000c1c <release>
  return xticks;
}
    80002a90:	02049513          	slli	a0,s1,0x20
    80002a94:	9101                	srli	a0,a0,0x20
    80002a96:	60e2                	ld	ra,24(sp)
    80002a98:	6442                	ld	s0,16(sp)
    80002a9a:	64a2                	ld	s1,8(sp)
    80002a9c:	6105                	addi	sp,sp,32
    80002a9e:	8082                	ret

0000000080002aa0 <rendezvous>:
 * unlocked case, each process calls this only after reading the head. In the
 * spinlock case, each calls it immediately before acquiring the lock.
 */
static void
rendezvous(int worker_id)
{
    80002aa0:	1101                	addi	sp,sp,-32
    80002aa2:	ec06                	sd	ra,24(sp)
    80002aa4:	e822                	sd	s0,16(sp)
    80002aa6:	e426                	sd	s1,8(sp)
    80002aa8:	1000                	addi	s0,sp,32
    80002aaa:	84aa                	mv	s1,a0
  demo.hart[worker_id] = cpuid();
    80002aac:	dcbfe0ef          	jal	80001876 <cpuid>
    80002ab0:	00017797          	auipc	a5,0x17
    80002ab4:	98878793          	addi	a5,a5,-1656 # 80019438 <demo>
    80002ab8:	04d1                	addi	s1,s1,20
    80002aba:	048a                	slli	s1,s1,0x2
    80002abc:	94be                	add	s1,s1,a5
    80002abe:	c488                	sw	a0,8(s1)
  __atomic_fetch_add(&demo.ready, 1, __ATOMIC_ACQ_REL);
    80002ac0:	4705                	li	a4,1
    80002ac2:	05478793          	addi	a5,a5,84
    80002ac6:	06e7a02f          	amoadd.w.aqrl	zero,a4,(a5)
  while (__atomic_load_n(&demo.ready, __ATOMIC_ACQUIRE) < RACE_WORKERS)
    80002aca:	00017697          	auipc	a3,0x17
    80002ace:	96e68693          	addi	a3,a3,-1682 # 80019438 <demo>
    80002ad2:	4705                	li	a4,1
    80002ad4:	a011                	j	80002ad8 <rendezvous+0x38>
    __asm__ volatile("nop");
    80002ad6:	0001                	nop
  while (__atomic_load_n(&demo.ready, __ATOMIC_ACQUIRE) < RACE_WORKERS)
    80002ad8:	05468793          	addi	a5,a3,84
    80002adc:	439c                	lw	a5,0(a5)
    80002ade:	0230000f          	fence	r,rw
    80002ae2:	2781                	sext.w	a5,a5
    80002ae4:	fef759e3          	bge	a4,a5,80002ad6 <rendezvous+0x36>
}
    80002ae8:	60e2                	ld	ra,24(sp)
    80002aea:	6442                	ld	s0,16(sp)
    80002aec:	64a2                	ld	s1,8(sp)
    80002aee:	6105                	addi	sp,sp,32
    80002af0:	8082                	ret

0000000080002af2 <sys_raceinit>:
  }
}

uint64
sys_raceinit(void)
{
    80002af2:	7179                	addi	sp,sp,-48
    80002af4:	f406                	sd	ra,40(sp)
    80002af6:	f022                	sd	s0,32(sp)
    80002af8:	e84a                	sd	s2,16(sp)
    80002afa:	1800                	addi	s0,sp,48
  int mode;
  argint(0, &mode);
    80002afc:	fdc40593          	addi	a1,s0,-36
    80002b00:	4501                	li	a0,0
    80002b02:	cdbff0ef          	jal	800027dc <argint>
  if (mode != RACE_UNLOCKED && mode != RACE_SPINLOCK)
    80002b06:	fdc42903          	lw	s2,-36(s0)
    80002b0a:	0009071b          	sext.w	a4,s2
    80002b0e:	4785                	li	a5,1
    return -1;
    80002b10:	557d                	li	a0,-1
  if (mode != RACE_UNLOCKED && mode != RACE_SPINLOCK)
    80002b12:	06e7ea63          	bltu	a5,a4,80002b86 <sys_raceinit+0x94>
    80002b16:	ec26                	sd	s1,24(sp)
  initlock(&demo.lock, "race-demo");
    80002b18:	00017497          	auipc	s1,0x17
    80002b1c:	92048493          	addi	s1,s1,-1760 # 80019438 <demo>
    80002b20:	00006597          	auipc	a1,0x6
    80002b24:	89058593          	addi	a1,a1,-1904 # 800083b0 <etext+0x3b0>
    80002b28:	8526                	mv	a0,s1
    80002b2a:	ff1fd0ef          	jal	80000b1a <initlock>
  demo.mode = mode;
    80002b2e:	0524a823          	sw	s2,80(s1)
  __atomic_store_n(&demo.ready, 0, __ATOMIC_RELAXED);
    80002b32:	05448793          	addi	a5,s1,84
    80002b36:	0007a023          	sw	zero,0(a5)
    demo.pages[i].id = i;
    80002b3a:	0004ac23          	sw	zero,24(s1)
    demo.pages[i].next = i + 1 < RACE_PAGES ? &demo.pages[i + 1] : 0;
    80002b3e:	00017797          	auipc	a5,0x17
    80002b42:	92278793          	addi	a5,a5,-1758 # 80019460 <demo+0x28>
    80002b46:	f09c                	sd	a5,32(s1)
    demo.pages[i].id = i;
    80002b48:	4785                	li	a5,1
    80002b4a:	d49c                	sw	a5,40(s1)
    demo.pages[i].next = i + 1 < RACE_PAGES ? &demo.pages[i + 1] : 0;
    80002b4c:	00017797          	auipc	a5,0x17
    80002b50:	92478793          	addi	a5,a5,-1756 # 80019470 <demo+0x38>
    80002b54:	f89c                	sd	a5,48(s1)
    demo.pages[i].id = i;
    80002b56:	4789                	li	a5,2
    80002b58:	dc9c                	sw	a5,56(s1)
    demo.pages[i].next = i + 1 < RACE_PAGES ? &demo.pages[i + 1] : 0;
    80002b5a:	0404b023          	sd	zero,64(s1)
  __atomic_store_n(&demo.freelist, &demo.pages[0], __ATOMIC_RELAXED);
    80002b5e:	00017797          	auipc	a5,0x17
    80002b62:	8f278793          	addi	a5,a5,-1806 # 80019450 <demo+0x18>
    80002b66:	04848713          	addi	a4,s1,72
    80002b6a:	e31c                	sd	a5,0(a4)
    demo.hart[i] = -1;
    80002b6c:	57fd                	li	a5,-1
    80002b6e:	ccbc                	sw	a5,88(s1)
    demo.observed[i] = 0;
    80002b70:	0604b023          	sd	zero,96(s1)
    demo.allocated[i] = 0;
    80002b74:	0604b823          	sd	zero,112(s1)
    demo.hart[i] = -1;
    80002b78:	ccfc                	sw	a5,92(s1)
    demo.observed[i] = 0;
    80002b7a:	0604b423          	sd	zero,104(s1)
    demo.allocated[i] = 0;
    80002b7e:	0604bc23          	sd	zero,120(s1)

  reset_demo(mode);
  return 0;
    80002b82:	4501                	li	a0,0
    80002b84:	64e2                	ld	s1,24(sp)
}
    80002b86:	70a2                	ld	ra,40(sp)
    80002b88:	7402                	ld	s0,32(sp)
    80002b8a:	6942                	ld	s2,16(sp)
    80002b8c:	6145                	addi	sp,sp,48
    80002b8e:	8082                	ret

0000000080002b90 <sys_raceworker>:

uint64
sys_raceworker(void)
{
    80002b90:	7139                	addi	sp,sp,-64
    80002b92:	fc06                	sd	ra,56(sp)
    80002b94:	f822                	sd	s0,48(sp)
    80002b96:	f426                	sd	s1,40(sp)
    80002b98:	0080                	addi	s0,sp,64
  int worker_id;
  argint(0, &worker_id);
    80002b9a:	fcc40593          	addi	a1,s0,-52
    80002b9e:	4501                	li	a0,0
    80002ba0:	c3dff0ef          	jal	800027dc <argint>
  if (worker_id < 0 || worker_id >= RACE_WORKERS)
    80002ba4:	fcc42483          	lw	s1,-52(s0)
    80002ba8:	0004871b          	sext.w	a4,s1
    80002bac:	4785                	li	a5,1
    80002bae:	557d                	li	a0,-1
    80002bb0:	00e7f563          	bgeu	a5,a4,80002bba <sys_raceworker+0x2a>
    80002bb4:	a0c9                	j	80002c76 <sys_raceworker+0xe6>
      yield();
    80002bb6:	ac4ff0ef          	jal	80001e7a <yield>
    while (cpuid() != worker_id)
    80002bba:	cbdfe0ef          	jal	80001876 <cpuid>
    80002bbe:	fea49ce3          	bne	s1,a0,80002bb6 <sys_raceworker+0x26>
    push_off();
    80002bc2:	f99fd0ef          	jal	80000b5a <push_off>
    if (cpuid() == worker_id)
    80002bc6:	cb1fe0ef          	jal	80001876 <cpuid>
    80002bca:	00a48563          	beq	s1,a0,80002bd4 <sys_raceworker+0x44>
    pop_off();
    80002bce:	802fe0ef          	jal	80000bd0 <pop_off>
    while (cpuid() != worker_id)
    80002bd2:	b7e5                	j	80002bba <sys_raceworker+0x2a>
    return -1;

  pin_worker_to_hart(worker_id);
  struct race_run *page;

  if (demo.mode == RACE_UNLOCKED) {
    80002bd4:	00017797          	auipc	a5,0x17
    80002bd8:	8b47a783          	lw	a5,-1868(a5) # 80019488 <demo+0x50>
    80002bdc:	e3b1                	bnez	a5,80002c20 <sys_raceworker+0x90>
    page = __atomic_load_n(&demo.freelist, __ATOMIC_RELAXED);
    80002bde:	00017797          	auipc	a5,0x17
    80002be2:	85a78793          	addi	a5,a5,-1958 # 80019438 <demo>
    80002be6:	04878793          	addi	a5,a5,72
    80002bea:	639c                	ld	a5,0(a5)
    struct race_run *next = page ? page->next : 0;
    80002bec:	c3dd                	beqz	a5,80002c92 <sys_raceworker+0x102>
    80002bee:	f04a                	sd	s2,32(sp)
    80002bf0:	ec4e                	sd	s3,24(sp)
    page = __atomic_load_n(&demo.freelist, __ATOMIC_RELAXED);
    80002bf2:	84be                	mv	s1,a5
    struct race_run *next = page ? page->next : 0;
    80002bf4:	0087b983          	ld	s3,8(a5)
    demo.observed[worker_id] = page;
    80002bf8:	fcc42503          	lw	a0,-52(s0)
    80002bfc:	00017917          	auipc	s2,0x17
    80002c00:	83c90913          	addi	s2,s2,-1988 # 80019438 <demo>
    80002c04:	00c50713          	addi	a4,a0,12
    80002c08:	070e                	slli	a4,a4,0x3
    80002c0a:	974a                	add	a4,a4,s2
    80002c0c:	e31c                	sd	a5,0(a4)

    /* Both workers now hold the same old head and its next pointer. */
    rendezvous(worker_id);
    80002c0e:	e93ff0ef          	jal	80002aa0 <rendezvous>

    if (page)
      __atomic_store_n(&demo.freelist, next, __ATOMIC_RELAXED);
    80002c12:	04890793          	addi	a5,s2,72
    80002c16:	0137b023          	sd	s3,0(a5)
    80002c1a:	7902                	ld	s2,32(sp)
    80002c1c:	69e2                	ld	s3,24(sp)
    80002c1e:	a825                	j	80002c56 <sys_raceworker+0xc6>
  } else {
    rendezvous(worker_id);
    80002c20:	fcc42503          	lw	a0,-52(s0)
    80002c24:	e7dff0ef          	jal	80002aa0 <rendezvous>
    acquire(&demo.lock);
    80002c28:	00017497          	auipc	s1,0x17
    80002c2c:	81048493          	addi	s1,s1,-2032 # 80019438 <demo>
    80002c30:	8526                	mv	a0,s1
    80002c32:	f5ffd0ef          	jal	80000b90 <acquire>
    page = __atomic_load_n(&demo.freelist, __ATOMIC_RELAXED);
    80002c36:	04848793          	addi	a5,s1,72
    80002c3a:	6384                	ld	s1,0(a5)
    if (page)
    80002c3c:	e0b1                	bnez	s1,80002c80 <sys_raceworker+0xf0>
      __atomic_store_n(&demo.freelist, page->next, __ATOMIC_RELAXED);
    demo.observed[worker_id] = page;
    80002c3e:	00016517          	auipc	a0,0x16
    80002c42:	7fa50513          	addi	a0,a0,2042 # 80019438 <demo>
    80002c46:	fcc42783          	lw	a5,-52(s0)
    80002c4a:	07b1                	addi	a5,a5,12
    80002c4c:	078e                	slli	a5,a5,0x3
    80002c4e:	97aa                	add	a5,a5,a0
    80002c50:	e384                	sd	s1,0(a5)
    release(&demo.lock);
    80002c52:	fcbfd0ef          	jal	80000c1c <release>
  }

  demo.allocated[worker_id] = page;
    80002c56:	fcc42783          	lw	a5,-52(s0)
    80002c5a:	07b9                	addi	a5,a5,14
    80002c5c:	078e                	slli	a5,a5,0x3
    80002c5e:	00016717          	auipc	a4,0x16
    80002c62:	7da70713          	addi	a4,a4,2010 # 80019438 <demo>
    80002c66:	97ba                	add	a5,a5,a4
    80002c68:	e384                	sd	s1,0(a5)
  pop_off();
    80002c6a:	f67fd0ef          	jal	80000bd0 <pop_off>
  return page ? 0 : -1;
    80002c6e:	0014b513          	seqz	a0,s1
    80002c72:	40a00533          	neg	a0,a0
}
    80002c76:	70e2                	ld	ra,56(sp)
    80002c78:	7442                	ld	s0,48(sp)
    80002c7a:	74a2                	ld	s1,40(sp)
    80002c7c:	6121                	addi	sp,sp,64
    80002c7e:	8082                	ret
      __atomic_store_n(&demo.freelist, page->next, __ATOMIC_RELAXED);
    80002c80:	6498                	ld	a4,8(s1)
    80002c82:	00016797          	auipc	a5,0x16
    80002c86:	7b678793          	addi	a5,a5,1974 # 80019438 <demo>
    80002c8a:	04878793          	addi	a5,a5,72
    80002c8e:	e398                	sd	a4,0(a5)
    80002c90:	b77d                	j	80002c3e <sys_raceworker+0xae>
    demo.observed[worker_id] = page;
    80002c92:	fcc42503          	lw	a0,-52(s0)
    80002c96:	00c50713          	addi	a4,a0,12
    80002c9a:	070e                	slli	a4,a4,0x3
    80002c9c:	00016797          	auipc	a5,0x16
    80002ca0:	79c78793          	addi	a5,a5,1948 # 80019438 <demo>
    80002ca4:	97ba                	add	a5,a5,a4
    80002ca6:	0007b023          	sd	zero,0(a5)
    rendezvous(worker_id);
    80002caa:	df7ff0ef          	jal	80002aa0 <rendezvous>
    page = __atomic_load_n(&demo.freelist, __ATOMIC_RELAXED);
    80002cae:	4481                	li	s1,0
    80002cb0:	b75d                	j	80002c56 <sys_raceworker+0xc6>

0000000080002cb2 <sys_racereport>:
  return valid;
}

uint64
sys_racereport(void)
{
    80002cb2:	711d                	addi	sp,sp,-96
    80002cb4:	ec86                	sd	ra,88(sp)
    80002cb6:	e8a2                	sd	s0,80(sp)
    80002cb8:	e4a6                	sd	s1,72(sp)
    80002cba:	e0ca                	sd	s2,64(sp)
    80002cbc:	fc4e                	sd	s3,56(sp)
    80002cbe:	f852                	sd	s4,48(sp)
    80002cc0:	f456                	sd	s5,40(sp)
    80002cc2:	f05a                	sd	s6,32(sp)
    80002cc4:	1080                	addi	s0,sp,96
  int occurrences[RACE_PAGES] = {0};
    80002cc6:	fa043023          	sd	zero,-96(s0)
    80002cca:	fa042423          	sw	zero,-88(s0)
  int seen[RACE_PAGES] = {0};
    80002cce:	fa043823          	sd	zero,-80(s0)
    80002cd2:	fa042c23          	sw	zero,-72(s0)
    struct race_run *page = demo.allocated[i];
    80002cd6:	00016797          	auipc	a5,0x16
    80002cda:	7d27b783          	ld	a5,2002(a5) # 800194a8 <demo+0x70>
  int valid = 1;
    80002cde:	4905                	li	s2,1
    if (page) {
    80002ce0:	c395                	beqz	a5,80002d04 <sys_racereport+0x52>
  return page ? page->id : -1;
    80002ce2:	439c                	lw	a5,0(a5)
      if (id < 0 || id >= RACE_PAGES)
    80002ce4:	0007869b          	sext.w	a3,a5
    80002ce8:	4709                	li	a4,2
        valid = 0;
    80002cea:	4901                	li	s2,0
      if (id < 0 || id >= RACE_PAGES)
    80002cec:	00d76c63          	bltu	a4,a3,80002d04 <sys_racereport+0x52>
        occurrences[id]++;
    80002cf0:	078a                	slli	a5,a5,0x2
    80002cf2:	fc078793          	addi	a5,a5,-64
    80002cf6:	97a2                	add	a5,a5,s0
    80002cf8:	fe07a703          	lw	a4,-32(a5)
    80002cfc:	2705                	addiw	a4,a4,1
    80002cfe:	fee7a023          	sw	a4,-32(a5)
  int valid = 1;
    80002d02:	4905                	li	s2,1
    struct race_run *page = demo.allocated[i];
    80002d04:	00016797          	auipc	a5,0x16
    80002d08:	7ac7b783          	ld	a5,1964(a5) # 800194b0 <demo+0x78>
    if (page) {
    80002d0c:	c395                	beqz	a5,80002d30 <sys_racereport+0x7e>
  return page ? page->id : -1;
    80002d0e:	439c                	lw	a5,0(a5)
      if (id < 0 || id >= RACE_PAGES)
    80002d10:	0007869b          	sext.w	a3,a5
    80002d14:	4709                	li	a4,2
    80002d16:	00d76c63          	bltu	a4,a3,80002d2e <sys_racereport+0x7c>
        occurrences[id]++;
    80002d1a:	078a                	slli	a5,a5,0x2
    80002d1c:	fc078793          	addi	a5,a5,-64
    80002d20:	97a2                	add	a5,a5,s0
    80002d22:	fe07a703          	lw	a4,-32(a5)
    80002d26:	2705                	addiw	a4,a4,1
    80002d28:	fee7a023          	sw	a4,-32(a5)
    80002d2c:	a011                	j	80002d30 <sys_racereport+0x7e>
        valid = 0;
    80002d2e:	4901                	li	s2,0
  struct race_run *page = __atomic_load_n(&demo.freelist, __ATOMIC_RELAXED);
    80002d30:	00016797          	auipc	a5,0x16
    80002d34:	70878793          	addi	a5,a5,1800 # 80019438 <demo>
    80002d38:	04878793          	addi	a5,a5,72
    80002d3c:	6398                	ld	a4,0(a5)
  while (page && steps < RACE_PAGES) {
    80002d3e:	c329                	beqz	a4,80002d80 <sys_racereport+0xce>
    80002d40:	460d                	li	a2,3
    if (id < 0 || id >= RACE_PAGES || seen[id]) {
    80002d42:	4589                	li	a1,2
    seen[id] = 1;
    80002d44:	4505                	li	a0,1
  return page ? page->id : -1;
    80002d46:	431c                	lw	a5,0(a4)
    if (id < 0 || id >= RACE_PAGES || seen[id]) {
    80002d48:	0007869b          	sext.w	a3,a5
    80002d4c:	02d5e963          	bltu	a1,a3,80002d7e <sys_racereport+0xcc>
    80002d50:	00279693          	slli	a3,a5,0x2
    80002d54:	fc068693          	addi	a3,a3,-64
    80002d58:	96a2                	add	a3,a3,s0
    80002d5a:	ff06a683          	lw	a3,-16(a3)
    80002d5e:	e285                	bnez	a3,80002d7e <sys_racereport+0xcc>
    seen[id] = 1;
    80002d60:	078a                	slli	a5,a5,0x2
    80002d62:	fc078793          	addi	a5,a5,-64
    80002d66:	97a2                	add	a5,a5,s0
    80002d68:	fea7a823          	sw	a0,-16(a5)
    occurrences[id]++;
    80002d6c:	fe07a683          	lw	a3,-32(a5)
    80002d70:	2685                	addiw	a3,a3,1
    80002d72:	fed7a023          	sw	a3,-32(a5)
    page = page->next;
    80002d76:	6718                	ld	a4,8(a4)
  while (page && steps < RACE_PAGES) {
    80002d78:	c701                	beqz	a4,80002d80 <sys_racereport+0xce>
    80002d7a:	367d                	addiw	a2,a2,-1 # fff <_entry-0x7ffff001>
    80002d7c:	f669                	bnez	a2,80002d46 <sys_racereport+0x94>
    valid = 0;
    80002d7e:	4901                	li	s2,0
    if (occurrences[i] == 1)
    80002d80:	fa042a03          	lw	s4,-96(s0)
    80002d84:	4785                	li	a5,1
    80002d86:	00fa0463          	beq	s4,a5,80002d8e <sys_racereport+0xdc>
    80002d8a:	4a01                	li	s4,0
      valid = 0;
    80002d8c:	4901                	li	s2,0
    if (occurrences[i] == 1)
    80002d8e:	fa442703          	lw	a4,-92(s0)
    80002d92:	4785                	li	a5,1
    80002d94:	16f70863          	beq	a4,a5,80002f04 <sys_racereport+0x252>
      valid = 0;
    80002d98:	4901                	li	s2,0
    if (occurrences[i] == 1)
    80002d9a:	fa842703          	lw	a4,-88(s0)
    80002d9e:	4785                	li	a5,1
    80002da0:	16f70063          	beq	a4,a5,80002f00 <sys_racereport+0x24e>
      valid = 0;
    80002da4:	4901                	li	s2,0
  int exactly_once;
  int consistent = audit_state(&exactly_once);
  struct race_run *head = __atomic_load_n(&demo.freelist, __ATOMIC_RELAXED);
    80002da6:	00016797          	auipc	a5,0x16
    80002daa:	69278793          	addi	a5,a5,1682 # 80019438 <demo>
    80002dae:	04878713          	addi	a4,a5,72
    80002db2:	00073b03          	ld	s6,0(a4)
  int duplicate = demo.allocated[0] != 0 &&
    80002db6:	7bbc                	ld	a5,112(a5)
    80002db8:	4981                	li	s3,0
    80002dba:	cb89                	beqz	a5,80002dcc <sys_racereport+0x11a>
    80002dbc:	00016997          	auipc	s3,0x16
    80002dc0:	6f49b983          	ld	s3,1780(s3) # 800194b0 <demo+0x78>
    80002dc4:	40f989b3          	sub	s3,s3,a5
    80002dc8:	0019b993          	seqz	s3,s3
                  demo.allocated[0] == demo.allocated[1];
  int two_harts = demo.hart[0] >= 0 && demo.hart[1] >= 0 &&
    80002dcc:	00016797          	auipc	a5,0x16
    80002dd0:	6c47a783          	lw	a5,1732(a5) # 80019490 <demo+0x58>
    80002dd4:	4481                	li	s1,0
    80002dd6:	0007cb63          	bltz	a5,80002dec <sys_racereport+0x13a>
    80002dda:	00016717          	auipc	a4,0x16
    80002dde:	6ba72703          	lw	a4,1722(a4) # 80019494 <demo+0x5c>
    80002de2:	00074563          	bltz	a4,80002dec <sys_racereport+0x13a>
    80002de6:	8f99                	sub	a5,a5,a4
    80002de8:	00f034b3          	snez	s1,a5
                  demo.hart[0] != demo.hart[1];
  int expected;

  printk("\n[xv6 race demo] %s\n",
    80002dec:	00016797          	auipc	a5,0x16
    80002df0:	69c7a783          	lw	a5,1692(a5) # 80019488 <demo+0x50>
    80002df4:	00005597          	auipc	a1,0x5
    80002df8:	5e458593          	addi	a1,a1,1508 # 800083d8 <etext+0x3d8>
    80002dfc:	e789                	bnez	a5,80002e06 <sys_racereport+0x154>
    80002dfe:	00005597          	auipc	a1,0x5
    80002e02:	5c258593          	addi	a1,a1,1474 # 800083c0 <etext+0x3c0>
    80002e06:	00005517          	auipc	a0,0x5
    80002e0a:	62a50513          	addi	a0,a0,1578 # 80008430 <etext+0x430>
    80002e0e:	efcfd0ef          	jal	8000050a <printk>
         demo.mode == RACE_UNLOCKED ? "UNLOCKED free-list pop" :
                                      "SPINLOCK free-list pop");
  printk("  user workers ran on harts %d and %d\n",
    80002e12:	00016a97          	auipc	s5,0x16
    80002e16:	626a8a93          	addi	s5,s5,1574 # 80019438 <demo>
    80002e1a:	05caa603          	lw	a2,92(s5)
    80002e1e:	058aa583          	lw	a1,88(s5)
    80002e22:	00005517          	auipc	a0,0x5
    80002e26:	62650513          	addi	a0,a0,1574 # 80008448 <etext+0x448>
    80002e2a:	ee0fd0ef          	jal	8000050a <printk>
         demo.hart[0], demo.hart[1]);
  if (demo.mode == RACE_UNLOCKED)
    80002e2e:	050aa783          	lw	a5,80(s5)
    80002e32:	cbf9                	beqz	a5,80002f08 <sys_racereport+0x256>
    printk("  head values read: P%d and P%d\n",
           page_id(demo.observed[0]), page_id(demo.observed[1]));
  printk("  allocated pages: P%d and P%d\n",
    80002e34:	00016797          	auipc	a5,0x16
    80002e38:	6747b783          	ld	a5,1652(a5) # 800194a8 <demo+0x70>
  return page ? page->id : -1;
    80002e3c:	0e078d63          	beqz	a5,80002f36 <sys_racereport+0x284>
    80002e40:	438c                	lw	a1,0(a5)
  printk("  allocated pages: P%d and P%d\n",
    80002e42:	00016797          	auipc	a5,0x16
    80002e46:	66e7b783          	ld	a5,1646(a5) # 800194b0 <demo+0x78>
  return page ? page->id : -1;
    80002e4a:	0e078863          	beqz	a5,80002f3a <sys_racereport+0x288>
    80002e4e:	4390                	lw	a2,0(a5)
  printk("  allocated pages: P%d and P%d\n",
    80002e50:	00005517          	auipc	a0,0x5
    80002e54:	64850513          	addi	a0,a0,1608 # 80008498 <etext+0x498>
    80002e58:	eb2fd0ef          	jal	8000050a <printk>
         page_id(demo.allocated[0]), page_id(demo.allocated[1]));
  printk("  same page returned twice: %s\n", duplicate ? "YES" : "NO");
    80002e5c:	00005597          	auipc	a1,0x5
    80002e60:	59c58593          	addi	a1,a1,1436 # 800083f8 <etext+0x3f8>
    80002e64:	00098663          	beqz	s3,80002e70 <sys_racereport+0x1be>
    80002e68:	00005597          	auipc	a1,0x5
    80002e6c:	58858593          	addi	a1,a1,1416 # 800083f0 <etext+0x3f0>
    80002e70:	00005517          	auipc	a0,0x5
    80002e74:	64850513          	addi	a0,a0,1608 # 800084b8 <etext+0x4b8>
    80002e78:	e92fd0ef          	jal	8000050a <printk>
  return page ? page->id : -1;
    80002e7c:	0c0b0163          	beqz	s6,80002f3e <sys_racereport+0x28c>
    80002e80:	000b2583          	lw	a1,0(s6)
  printk("  free-list head after both pops: P%d\n", page_id(head));
    80002e84:	00005517          	auipc	a0,0x5
    80002e88:	65450513          	addi	a0,a0,1620 # 800084d8 <etext+0x4d8>
    80002e8c:	e7efd0ef          	jal	8000050a <printk>
  printk("  page IDs appearing exactly once: %d / %d\n",
    80002e90:	460d                	li	a2,3
    80002e92:	85d2                	mv	a1,s4
    80002e94:	00005517          	auipc	a0,0x5
    80002e98:	66c50513          	addi	a0,a0,1644 # 80008500 <etext+0x500>
    80002e9c:	e6efd0ef          	jal	8000050a <printk>
         exactly_once, RACE_PAGES);
  printk("  invariant: %s\n", consistent ? "CONSISTENT" : "INCONSISTENT");
    80002ea0:	00005597          	auipc	a1,0x5
    80002ea4:	57058593          	addi	a1,a1,1392 # 80008410 <etext+0x410>
    80002ea8:	00090663          	beqz	s2,80002eb4 <sys_racereport+0x202>
    80002eac:	00005597          	auipc	a1,0x5
    80002eb0:	55458593          	addi	a1,a1,1364 # 80008400 <etext+0x400>
    80002eb4:	00005517          	auipc	a0,0x5
    80002eb8:	67c50513          	addi	a0,a0,1660 # 80008530 <etext+0x530>
    80002ebc:	e4efd0ef          	jal	8000050a <printk>

  if (demo.mode == RACE_UNLOCKED)
    80002ec0:	00016797          	auipc	a5,0x16
    80002ec4:	5c87a783          	lw	a5,1480(a5) # 80019488 <demo+0x50>
    80002ec8:	e7cd                	bnez	a5,80002f72 <sys_racereport+0x2c0>
  else
    expected = two_harts && !duplicate && consistent &&
               exactly_once == RACE_PAGES && page_id(head) == 2 &&
               page_id(demo.allocated[0]) != page_id(demo.allocated[1]);

  printk("  xv6 check: %s\n", expected ? "PASS" : "FAIL");
    80002eca:	00005597          	auipc	a1,0x5
    80002ece:	55e58593          	addi	a1,a1,1374 # 80008428 <etext+0x428>
               page_id(demo.observed[0]) == 0 &&
    80002ed2:	0e048f63          	beqz	s1,80002fd0 <sys_racereport+0x31e>
    expected = two_harts && duplicate && !consistent &&
    80002ed6:	0e098863          	beqz	s3,80002fc6 <sys_racereport+0x314>
    80002eda:	10091d63          	bnez	s2,80002ff4 <sys_racereport+0x342>
    80002ede:	4789                	li	a5,2
    80002ee0:	84ca                	mv	s1,s2
    80002ee2:	0efa1763          	bne	s4,a5,80002fd0 <sys_racereport+0x31e>
  return page ? page->id : -1;
    80002ee6:	100b0d63          	beqz	s6,80003000 <sys_racereport+0x34e>
    80002eea:	000b2483          	lw	s1,0(s6)
               exactly_once == RACE_PAGES - 1 && page_id(head) == 1 &&
    80002eee:	4785                	li	a5,1
    80002ef0:	04f48963          	beq	s1,a5,80002f42 <sys_racereport+0x290>
    80002ef4:	84ca                	mv	s1,s2
  printk("  xv6 check: %s\n", expected ? "PASS" : "FAIL");
    80002ef6:	00005597          	auipc	a1,0x5
    80002efa:	53258593          	addi	a1,a1,1330 # 80008428 <etext+0x428>
    80002efe:	a8c9                	j	80002fd0 <sys_racereport+0x31e>
      (*exactly_once)++;
    80002f00:	2a05                	addiw	s4,s4,1
    80002f02:	b555                	j	80002da6 <sys_racereport+0xf4>
    80002f04:	2a05                	addiw	s4,s4,1
    80002f06:	bd51                	j	80002d9a <sys_racereport+0xe8>
    printk("  head values read: P%d and P%d\n",
    80002f08:	00016797          	auipc	a5,0x16
    80002f0c:	5907b783          	ld	a5,1424(a5) # 80019498 <demo+0x60>
  return page ? page->id : -1;
    80002f10:	cf99                	beqz	a5,80002f2e <sys_racereport+0x27c>
    80002f12:	438c                	lw	a1,0(a5)
    printk("  head values read: P%d and P%d\n",
    80002f14:	00016797          	auipc	a5,0x16
    80002f18:	58c7b783          	ld	a5,1420(a5) # 800194a0 <demo+0x68>
  return page ? page->id : -1;
    80002f1c:	cb99                	beqz	a5,80002f32 <sys_racereport+0x280>
    80002f1e:	4390                	lw	a2,0(a5)
    printk("  head values read: P%d and P%d\n",
    80002f20:	00005517          	auipc	a0,0x5
    80002f24:	55050513          	addi	a0,a0,1360 # 80008470 <etext+0x470>
    80002f28:	de2fd0ef          	jal	8000050a <printk>
    80002f2c:	b721                	j	80002e34 <sys_racereport+0x182>
  return page ? page->id : -1;
    80002f2e:	55fd                	li	a1,-1
    80002f30:	b7d5                	j	80002f14 <sys_racereport+0x262>
    80002f32:	567d                	li	a2,-1
    80002f34:	b7f5                	j	80002f20 <sys_racereport+0x26e>
    80002f36:	55fd                	li	a1,-1
    80002f38:	b729                	j	80002e42 <sys_racereport+0x190>
    80002f3a:	567d                	li	a2,-1
    80002f3c:	bf11                	j	80002e50 <sys_racereport+0x19e>
    80002f3e:	55fd                	li	a1,-1
    80002f40:	b791                	j	80002e84 <sys_racereport+0x1d2>
               page_id(demo.observed[0]) == 0 &&
    80002f42:	00016797          	auipc	a5,0x16
    80002f46:	5567b783          	ld	a5,1366(a5) # 80019498 <demo+0x60>
  return page ? page->id : -1;
    80002f4a:	c3e1                	beqz	a5,8000300a <sys_racereport+0x358>
    80002f4c:	439c                	lw	a5,0(a5)
               exactly_once == RACE_PAGES - 1 && page_id(head) == 1 &&
    80002f4e:	e7e1                	bnez	a5,80003016 <sys_racereport+0x364>
               page_id(demo.observed[1]) == 0;
    80002f50:	00016717          	auipc	a4,0x16
    80002f54:	55073703          	ld	a4,1360(a4) # 800194a0 <demo+0x68>
  return page ? page->id : -1;
    80002f58:	c769                	beqz	a4,80003022 <sys_racereport+0x370>
               page_id(demo.observed[0]) == 0 &&
    80002f5a:	4318                	lw	a4,0(a4)
  printk("  xv6 check: %s\n", expected ? "PASS" : "FAIL");
    80002f5c:	00005597          	auipc	a1,0x5
    80002f60:	4c458593          	addi	a1,a1,1220 # 80008420 <etext+0x420>
               page_id(demo.observed[0]) == 0 &&
    80002f64:	c735                	beqz	a4,80002fd0 <sys_racereport+0x31e>
    80002f66:	84be                	mv	s1,a5
  printk("  xv6 check: %s\n", expected ? "PASS" : "FAIL");
    80002f68:	00005597          	auipc	a1,0x5
    80002f6c:	4c058593          	addi	a1,a1,1216 # 80008428 <etext+0x428>
    80002f70:	a085                	j	80002fd0 <sys_racereport+0x31e>
    80002f72:	00005597          	auipc	a1,0x5
    80002f76:	4b658593          	addi	a1,a1,1206 # 80008428 <etext+0x428>
               exactly_once == RACE_PAGES && page_id(head) == 2 &&
    80002f7a:	c8b9                	beqz	s1,80002fd0 <sys_racereport+0x31e>
    expected = two_harts && !duplicate && consistent &&
    80002f7c:	0a099963          	bnez	s3,8000302e <sys_racereport+0x37c>
    80002f80:	0a090d63          	beqz	s2,8000303a <sys_racereport+0x388>
    80002f84:	478d                	li	a5,3
    80002f86:	84ce                	mv	s1,s3
    80002f88:	04fa1463          	bne	s4,a5,80002fd0 <sys_racereport+0x31e>
  return page ? page->id : -1;
    80002f8c:	0a0b0d63          	beqz	s6,80003046 <sys_racereport+0x394>
               exactly_once == RACE_PAGES && page_id(head) == 2 &&
    80002f90:	000b2703          	lw	a4,0(s6)
    80002f94:	4789                	li	a5,2
    80002f96:	02f71d63          	bne	a4,a5,80002fd0 <sys_racereport+0x31e>
               page_id(demo.allocated[0]) != page_id(demo.allocated[1]);
    80002f9a:	00016797          	auipc	a5,0x16
    80002f9e:	50e7b783          	ld	a5,1294(a5) # 800194a8 <demo+0x70>
  return page ? page->id : -1;
    80002fa2:	cfcd                	beqz	a5,8000305c <sys_racereport+0x3aa>
    80002fa4:	4398                	lw	a4,0(a5)
               page_id(demo.allocated[0]) != page_id(demo.allocated[1]);
    80002fa6:	00016797          	auipc	a5,0x16
    80002faa:	50a7b783          	ld	a5,1290(a5) # 800194b0 <demo+0x78>
  return page ? page->id : -1;
    80002fae:	cb91                	beqz	a5,80002fc2 <sys_racereport+0x310>
    80002fb0:	439c                	lw	a5,0(a5)
               exactly_once == RACE_PAGES && page_id(head) == 2 &&
    80002fb2:	08e78f63          	beq	a5,a4,80003050 <sys_racereport+0x39e>
    expected = two_harts && !duplicate && consistent &&
    80002fb6:	84ca                	mv	s1,s2
  printk("  xv6 check: %s\n", expected ? "PASS" : "FAIL");
    80002fb8:	00005597          	auipc	a1,0x5
    80002fbc:	46858593          	addi	a1,a1,1128 # 80008420 <etext+0x420>
    80002fc0:	a801                	j	80002fd0 <sys_racereport+0x31e>
  return page ? page->id : -1;
    80002fc2:	57fd                	li	a5,-1
    80002fc4:	b7fd                	j	80002fb2 <sys_racereport+0x300>
    80002fc6:	84ce                	mv	s1,s3
  printk("  xv6 check: %s\n", expected ? "PASS" : "FAIL");
    80002fc8:	00005597          	auipc	a1,0x5
    80002fcc:	46058593          	addi	a1,a1,1120 # 80008428 <etext+0x428>
    80002fd0:	00005517          	auipc	a0,0x5
    80002fd4:	57850513          	addi	a0,a0,1400 # 80008548 <etext+0x548>
    80002fd8:	d32fd0ef          	jal	8000050a <printk>
  return expected ? 0 : -1;
    80002fdc:	fff48513          	addi	a0,s1,-1
}
    80002fe0:	60e6                	ld	ra,88(sp)
    80002fe2:	6446                	ld	s0,80(sp)
    80002fe4:	64a6                	ld	s1,72(sp)
    80002fe6:	6906                	ld	s2,64(sp)
    80002fe8:	79e2                	ld	s3,56(sp)
    80002fea:	7a42                	ld	s4,48(sp)
    80002fec:	7aa2                	ld	s5,40(sp)
    80002fee:	7b02                	ld	s6,32(sp)
    80002ff0:	6125                	addi	sp,sp,96
    80002ff2:	8082                	ret
    80002ff4:	84be                	mv	s1,a5
  printk("  xv6 check: %s\n", expected ? "PASS" : "FAIL");
    80002ff6:	00005597          	auipc	a1,0x5
    80002ffa:	43258593          	addi	a1,a1,1074 # 80008428 <etext+0x428>
    80002ffe:	bfc9                	j	80002fd0 <sys_racereport+0x31e>
    80003000:	00005597          	auipc	a1,0x5
    80003004:	42858593          	addi	a1,a1,1064 # 80008428 <etext+0x428>
    80003008:	b7e1                	j	80002fd0 <sys_racereport+0x31e>
    8000300a:	84ca                	mv	s1,s2
    8000300c:	00005597          	auipc	a1,0x5
    80003010:	41c58593          	addi	a1,a1,1052 # 80008428 <etext+0x428>
    80003014:	bf75                	j	80002fd0 <sys_racereport+0x31e>
    80003016:	84ca                	mv	s1,s2
    80003018:	00005597          	auipc	a1,0x5
    8000301c:	41058593          	addi	a1,a1,1040 # 80008428 <etext+0x428>
    80003020:	bf45                	j	80002fd0 <sys_racereport+0x31e>
    80003022:	84be                	mv	s1,a5
    80003024:	00005597          	auipc	a1,0x5
    80003028:	40458593          	addi	a1,a1,1028 # 80008428 <etext+0x428>
    8000302c:	b755                	j	80002fd0 <sys_racereport+0x31e>
    8000302e:	4481                	li	s1,0
    80003030:	00005597          	auipc	a1,0x5
    80003034:	3f858593          	addi	a1,a1,1016 # 80008428 <etext+0x428>
    80003038:	bf61                	j	80002fd0 <sys_racereport+0x31e>
    8000303a:	84ca                	mv	s1,s2
    8000303c:	00005597          	auipc	a1,0x5
    80003040:	3ec58593          	addi	a1,a1,1004 # 80008428 <etext+0x428>
    80003044:	b771                	j	80002fd0 <sys_racereport+0x31e>
    80003046:	00005597          	auipc	a1,0x5
    8000304a:	3e258593          	addi	a1,a1,994 # 80008428 <etext+0x428>
    8000304e:	b749                	j	80002fd0 <sys_racereport+0x31e>
    80003050:	84ce                	mv	s1,s3
    80003052:	00005597          	auipc	a1,0x5
    80003056:	3d658593          	addi	a1,a1,982 # 80008428 <etext+0x428>
    8000305a:	bf9d                	j	80002fd0 <sys_racereport+0x31e>
               page_id(demo.allocated[0]) != page_id(demo.allocated[1]);
    8000305c:	00016797          	auipc	a5,0x16
    80003060:	4547b783          	ld	a5,1108(a5) # 800194b0 <demo+0x78>
  return page ? page->id : -1;
    80003064:	577d                	li	a4,-1
  printk("  xv6 check: %s\n", expected ? "PASS" : "FAIL");
    80003066:	00005597          	auipc	a1,0x5
    8000306a:	3c258593          	addi	a1,a1,962 # 80008428 <etext+0x428>
  return page ? page->id : -1;
    8000306e:	f3a9                	bnez	a5,80002fb0 <sys_racereport+0x2fe>
    80003070:	b785                	j	80002fd0 <sys_racereport+0x31e>

0000000080003072 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80003072:	7179                	addi	sp,sp,-48
    80003074:	f406                	sd	ra,40(sp)
    80003076:	f022                	sd	s0,32(sp)
    80003078:	ec26                	sd	s1,24(sp)
    8000307a:	e84a                	sd	s2,16(sp)
    8000307c:	e44e                	sd	s3,8(sp)
    8000307e:	e052                	sd	s4,0(sp)
    80003080:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80003082:	00005597          	auipc	a1,0x5
    80003086:	4de58593          	addi	a1,a1,1246 # 80008560 <etext+0x560>
    8000308a:	00016517          	auipc	a0,0x16
    8000308e:	42e50513          	addi	a0,a0,1070 # 800194b8 <bcache>
    80003092:	a89fd0ef          	jal	80000b1a <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80003096:	0001e797          	auipc	a5,0x1e
    8000309a:	42278793          	addi	a5,a5,1058 # 800214b8 <bcache+0x8000>
    8000309e:	0001e717          	auipc	a4,0x1e
    800030a2:	68270713          	addi	a4,a4,1666 # 80021720 <bcache+0x8268>
    800030a6:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    800030aa:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    800030ae:	00016497          	auipc	s1,0x16
    800030b2:	42248493          	addi	s1,s1,1058 # 800194d0 <bcache+0x18>
    b->next = bcache.head.next;
    800030b6:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    800030b8:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    800030ba:	00005a17          	auipc	s4,0x5
    800030be:	4aea0a13          	addi	s4,s4,1198 # 80008568 <etext+0x568>
    b->next = bcache.head.next;
    800030c2:	2b893783          	ld	a5,696(s2)
    800030c6:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    800030c8:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    800030cc:	85d2                	mv	a1,s4
    800030ce:	01048513          	addi	a0,s1,16
    800030d2:	414010ef          	jal	800044e6 <initsleeplock>
    bcache.head.next->prev = b;
    800030d6:	2b893783          	ld	a5,696(s2)
    800030da:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    800030dc:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    800030e0:	45848493          	addi	s1,s1,1112
    800030e4:	fd349fe3          	bne	s1,s3,800030c2 <binit+0x50>
  }
}
    800030e8:	70a2                	ld	ra,40(sp)
    800030ea:	7402                	ld	s0,32(sp)
    800030ec:	64e2                	ld	s1,24(sp)
    800030ee:	6942                	ld	s2,16(sp)
    800030f0:	69a2                	ld	s3,8(sp)
    800030f2:	6a02                	ld	s4,0(sp)
    800030f4:	6145                	addi	sp,sp,48
    800030f6:	8082                	ret

00000000800030f8 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    800030f8:	7179                	addi	sp,sp,-48
    800030fa:	f406                	sd	ra,40(sp)
    800030fc:	f022                	sd	s0,32(sp)
    800030fe:	ec26                	sd	s1,24(sp)
    80003100:	e84a                	sd	s2,16(sp)
    80003102:	e44e                	sd	s3,8(sp)
    80003104:	1800                	addi	s0,sp,48
    80003106:	892a                	mv	s2,a0
    80003108:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    8000310a:	00016517          	auipc	a0,0x16
    8000310e:	3ae50513          	addi	a0,a0,942 # 800194b8 <bcache>
    80003112:	a7ffd0ef          	jal	80000b90 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80003116:	0001e497          	auipc	s1,0x1e
    8000311a:	65a4b483          	ld	s1,1626(s1) # 80021770 <bcache+0x82b8>
    8000311e:	0001e797          	auipc	a5,0x1e
    80003122:	60278793          	addi	a5,a5,1538 # 80021720 <bcache+0x8268>
    80003126:	02f48b63          	beq	s1,a5,8000315c <bread+0x64>
    8000312a:	873e                	mv	a4,a5
    8000312c:	a021                	j	80003134 <bread+0x3c>
    8000312e:	68a4                	ld	s1,80(s1)
    80003130:	02e48663          	beq	s1,a4,8000315c <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    80003134:	449c                	lw	a5,8(s1)
    80003136:	ff279ce3          	bne	a5,s2,8000312e <bread+0x36>
    8000313a:	44dc                	lw	a5,12(s1)
    8000313c:	ff3799e3          	bne	a5,s3,8000312e <bread+0x36>
      b->refcnt++;
    80003140:	40bc                	lw	a5,64(s1)
    80003142:	2785                	addiw	a5,a5,1
    80003144:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80003146:	00016517          	auipc	a0,0x16
    8000314a:	37250513          	addi	a0,a0,882 # 800194b8 <bcache>
    8000314e:	acffd0ef          	jal	80000c1c <release>
      acquiresleep(&b->lock);
    80003152:	01048513          	addi	a0,s1,16
    80003156:	3c6010ef          	jal	8000451c <acquiresleep>
      return b;
    8000315a:	a889                	j	800031ac <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    8000315c:	0001e497          	auipc	s1,0x1e
    80003160:	60c4b483          	ld	s1,1548(s1) # 80021768 <bcache+0x82b0>
    80003164:	0001e797          	auipc	a5,0x1e
    80003168:	5bc78793          	addi	a5,a5,1468 # 80021720 <bcache+0x8268>
    8000316c:	00f48863          	beq	s1,a5,8000317c <bread+0x84>
    80003170:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    80003172:	40bc                	lw	a5,64(s1)
    80003174:	cb91                	beqz	a5,80003188 <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80003176:	64a4                	ld	s1,72(s1)
    80003178:	fee49de3          	bne	s1,a4,80003172 <bread+0x7a>
  panic("bget: no buffers");
    8000317c:	00005517          	auipc	a0,0x5
    80003180:	3f450513          	addi	a0,a0,1012 # 80008570 <etext+0x570>
    80003184:	e6cfd0ef          	jal	800007f0 <panic>
      b->dev = dev;
    80003188:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    8000318c:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80003190:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80003194:	4785                	li	a5,1
    80003196:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80003198:	00016517          	auipc	a0,0x16
    8000319c:	32050513          	addi	a0,a0,800 # 800194b8 <bcache>
    800031a0:	a7dfd0ef          	jal	80000c1c <release>
      acquiresleep(&b->lock);
    800031a4:	01048513          	addi	a0,s1,16
    800031a8:	374010ef          	jal	8000451c <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    800031ac:	409c                	lw	a5,0(s1)
    800031ae:	cb89                	beqz	a5,800031c0 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    800031b0:	8526                	mv	a0,s1
    800031b2:	70a2                	ld	ra,40(sp)
    800031b4:	7402                	ld	s0,32(sp)
    800031b6:	64e2                	ld	s1,24(sp)
    800031b8:	6942                	ld	s2,16(sp)
    800031ba:	69a2                	ld	s3,8(sp)
    800031bc:	6145                	addi	sp,sp,48
    800031be:	8082                	ret
    virtio_disk_rw(b, 0);
    800031c0:	4581                	li	a1,0
    800031c2:	8526                	mv	a0,s1
    800031c4:	4a5020ef          	jal	80005e68 <virtio_disk_rw>
    b->valid = 1;
    800031c8:	4785                	li	a5,1
    800031ca:	c09c                	sw	a5,0(s1)
  return b;
    800031cc:	b7d5                	j	800031b0 <bread+0xb8>

00000000800031ce <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    800031ce:	1101                	addi	sp,sp,-32
    800031d0:	ec06                	sd	ra,24(sp)
    800031d2:	e822                	sd	s0,16(sp)
    800031d4:	e426                	sd	s1,8(sp)
    800031d6:	1000                	addi	s0,sp,32
    800031d8:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    800031da:	0541                	addi	a0,a0,16
    800031dc:	3cc010ef          	jal	800045a8 <holdingsleep>
    800031e0:	c911                	beqz	a0,800031f4 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    800031e2:	4585                	li	a1,1
    800031e4:	8526                	mv	a0,s1
    800031e6:	483020ef          	jal	80005e68 <virtio_disk_rw>
}
    800031ea:	60e2                	ld	ra,24(sp)
    800031ec:	6442                	ld	s0,16(sp)
    800031ee:	64a2                	ld	s1,8(sp)
    800031f0:	6105                	addi	sp,sp,32
    800031f2:	8082                	ret
    panic("bwrite");
    800031f4:	00005517          	auipc	a0,0x5
    800031f8:	39450513          	addi	a0,a0,916 # 80008588 <etext+0x588>
    800031fc:	df4fd0ef          	jal	800007f0 <panic>

0000000080003200 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80003200:	1101                	addi	sp,sp,-32
    80003202:	ec06                	sd	ra,24(sp)
    80003204:	e822                	sd	s0,16(sp)
    80003206:	e426                	sd	s1,8(sp)
    80003208:	e04a                	sd	s2,0(sp)
    8000320a:	1000                	addi	s0,sp,32
    8000320c:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    8000320e:	01050913          	addi	s2,a0,16
    80003212:	854a                	mv	a0,s2
    80003214:	394010ef          	jal	800045a8 <holdingsleep>
    80003218:	c135                	beqz	a0,8000327c <brelse+0x7c>
    panic("brelse");

  releasesleep(&b->lock);
    8000321a:	854a                	mv	a0,s2
    8000321c:	354010ef          	jal	80004570 <releasesleep>

  acquire(&bcache.lock);
    80003220:	00016517          	auipc	a0,0x16
    80003224:	29850513          	addi	a0,a0,664 # 800194b8 <bcache>
    80003228:	969fd0ef          	jal	80000b90 <acquire>
  b->refcnt--;
    8000322c:	40bc                	lw	a5,64(s1)
    8000322e:	37fd                	addiw	a5,a5,-1
    80003230:	0007871b          	sext.w	a4,a5
    80003234:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80003236:	e71d                	bnez	a4,80003264 <brelse+0x64>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80003238:	68b8                	ld	a4,80(s1)
    8000323a:	64bc                	ld	a5,72(s1)
    8000323c:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    8000323e:	68b8                	ld	a4,80(s1)
    80003240:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80003242:	0001e797          	auipc	a5,0x1e
    80003246:	27678793          	addi	a5,a5,630 # 800214b8 <bcache+0x8000>
    8000324a:	2b87b703          	ld	a4,696(a5)
    8000324e:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80003250:	0001e717          	auipc	a4,0x1e
    80003254:	4d070713          	addi	a4,a4,1232 # 80021720 <bcache+0x8268>
    80003258:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    8000325a:	2b87b703          	ld	a4,696(a5)
    8000325e:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80003260:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    80003264:	00016517          	auipc	a0,0x16
    80003268:	25450513          	addi	a0,a0,596 # 800194b8 <bcache>
    8000326c:	9b1fd0ef          	jal	80000c1c <release>
}
    80003270:	60e2                	ld	ra,24(sp)
    80003272:	6442                	ld	s0,16(sp)
    80003274:	64a2                	ld	s1,8(sp)
    80003276:	6902                	ld	s2,0(sp)
    80003278:	6105                	addi	sp,sp,32
    8000327a:	8082                	ret
    panic("brelse");
    8000327c:	00005517          	auipc	a0,0x5
    80003280:	31450513          	addi	a0,a0,788 # 80008590 <etext+0x590>
    80003284:	d6cfd0ef          	jal	800007f0 <panic>

0000000080003288 <bpin>:

void
bpin(struct buf *b)
{
    80003288:	1101                	addi	sp,sp,-32
    8000328a:	ec06                	sd	ra,24(sp)
    8000328c:	e822                	sd	s0,16(sp)
    8000328e:	e426                	sd	s1,8(sp)
    80003290:	1000                	addi	s0,sp,32
    80003292:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003294:	00016517          	auipc	a0,0x16
    80003298:	22450513          	addi	a0,a0,548 # 800194b8 <bcache>
    8000329c:	8f5fd0ef          	jal	80000b90 <acquire>
  b->refcnt++;
    800032a0:	40bc                	lw	a5,64(s1)
    800032a2:	2785                	addiw	a5,a5,1
    800032a4:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800032a6:	00016517          	auipc	a0,0x16
    800032aa:	21250513          	addi	a0,a0,530 # 800194b8 <bcache>
    800032ae:	96ffd0ef          	jal	80000c1c <release>
}
    800032b2:	60e2                	ld	ra,24(sp)
    800032b4:	6442                	ld	s0,16(sp)
    800032b6:	64a2                	ld	s1,8(sp)
    800032b8:	6105                	addi	sp,sp,32
    800032ba:	8082                	ret

00000000800032bc <bunpin>:

void
bunpin(struct buf *b)
{
    800032bc:	1101                	addi	sp,sp,-32
    800032be:	ec06                	sd	ra,24(sp)
    800032c0:	e822                	sd	s0,16(sp)
    800032c2:	e426                	sd	s1,8(sp)
    800032c4:	1000                	addi	s0,sp,32
    800032c6:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800032c8:	00016517          	auipc	a0,0x16
    800032cc:	1f050513          	addi	a0,a0,496 # 800194b8 <bcache>
    800032d0:	8c1fd0ef          	jal	80000b90 <acquire>
  b->refcnt--;
    800032d4:	40bc                	lw	a5,64(s1)
    800032d6:	37fd                	addiw	a5,a5,-1
    800032d8:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800032da:	00016517          	auipc	a0,0x16
    800032de:	1de50513          	addi	a0,a0,478 # 800194b8 <bcache>
    800032e2:	93bfd0ef          	jal	80000c1c <release>
}
    800032e6:	60e2                	ld	ra,24(sp)
    800032e8:	6442                	ld	s0,16(sp)
    800032ea:	64a2                	ld	s1,8(sp)
    800032ec:	6105                	addi	sp,sp,32
    800032ee:	8082                	ret

00000000800032f0 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    800032f0:	1101                	addi	sp,sp,-32
    800032f2:	ec06                	sd	ra,24(sp)
    800032f4:	e822                	sd	s0,16(sp)
    800032f6:	e426                	sd	s1,8(sp)
    800032f8:	e04a                	sd	s2,0(sp)
    800032fa:	1000                	addi	s0,sp,32
    800032fc:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    800032fe:	00d5d59b          	srliw	a1,a1,0xd
    80003302:	0001f797          	auipc	a5,0x1f
    80003306:	8927a783          	lw	a5,-1902(a5) # 80021b94 <sb+0x1c>
    8000330a:	9dbd                	addw	a1,a1,a5
    8000330c:	dedff0ef          	jal	800030f8 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003310:	0074f713          	andi	a4,s1,7
    80003314:	4785                	li	a5,1
    80003316:	00e797bb          	sllw	a5,a5,a4
  if ((bp->data[bi / 8] & m) == 0)
    8000331a:	14ce                	slli	s1,s1,0x33
    8000331c:	90d9                	srli	s1,s1,0x36
    8000331e:	00950733          	add	a4,a0,s1
    80003322:	05874703          	lbu	a4,88(a4)
    80003326:	00e7f6b3          	and	a3,a5,a4
    8000332a:	c29d                	beqz	a3,80003350 <bfree+0x60>
    8000332c:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    8000332e:	94aa                	add	s1,s1,a0
    80003330:	fff7c793          	not	a5,a5
    80003334:	8f7d                	and	a4,a4,a5
    80003336:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    8000333a:	07a010ef          	jal	800043b4 <log_write>
  brelse(bp);
    8000333e:	854a                	mv	a0,s2
    80003340:	ec1ff0ef          	jal	80003200 <brelse>
}
    80003344:	60e2                	ld	ra,24(sp)
    80003346:	6442                	ld	s0,16(sp)
    80003348:	64a2                	ld	s1,8(sp)
    8000334a:	6902                	ld	s2,0(sp)
    8000334c:	6105                	addi	sp,sp,32
    8000334e:	8082                	ret
    panic("freeing free block");
    80003350:	00005517          	auipc	a0,0x5
    80003354:	24850513          	addi	a0,a0,584 # 80008598 <etext+0x598>
    80003358:	c98fd0ef          	jal	800007f0 <panic>

000000008000335c <balloc>:
{
    8000335c:	711d                	addi	sp,sp,-96
    8000335e:	ec86                	sd	ra,88(sp)
    80003360:	e8a2                	sd	s0,80(sp)
    80003362:	e4a6                	sd	s1,72(sp)
    80003364:	1080                	addi	s0,sp,96
  for (b = 0; b < sb.size; b += BPB) {
    80003366:	0001f797          	auipc	a5,0x1f
    8000336a:	8167a783          	lw	a5,-2026(a5) # 80021b7c <sb+0x4>
    8000336e:	0e078f63          	beqz	a5,8000346c <balloc+0x110>
    80003372:	e0ca                	sd	s2,64(sp)
    80003374:	fc4e                	sd	s3,56(sp)
    80003376:	f852                	sd	s4,48(sp)
    80003378:	f456                	sd	s5,40(sp)
    8000337a:	f05a                	sd	s6,32(sp)
    8000337c:	ec5e                	sd	s7,24(sp)
    8000337e:	e862                	sd	s8,16(sp)
    80003380:	e466                	sd	s9,8(sp)
    80003382:	8baa                	mv	s7,a0
    80003384:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80003386:	0001eb17          	auipc	s6,0x1e
    8000338a:	7f2b0b13          	addi	s6,s6,2034 # 80021b78 <sb>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    8000338e:	4c01                	li	s8,0
      m = 1 << (bi % 8);
    80003390:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003392:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    80003394:	6c89                	lui	s9,0x2
    80003396:	a0b5                	j	80003402 <balloc+0xa6>
        bp->data[bi / 8] |= m;           // Mark block in use.
    80003398:	97ca                	add	a5,a5,s2
    8000339a:	8e55                	or	a2,a2,a3
    8000339c:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    800033a0:	854a                	mv	a0,s2
    800033a2:	012010ef          	jal	800043b4 <log_write>
        brelse(bp);
    800033a6:	854a                	mv	a0,s2
    800033a8:	e59ff0ef          	jal	80003200 <brelse>
  bp = bread(dev, bno);
    800033ac:	85a6                	mv	a1,s1
    800033ae:	855e                	mv	a0,s7
    800033b0:	d49ff0ef          	jal	800030f8 <bread>
    800033b4:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800033b6:	40000613          	li	a2,1024
    800033ba:	4581                	li	a1,0
    800033bc:	05850513          	addi	a0,a0,88
    800033c0:	895fd0ef          	jal	80000c54 <memset>
  log_write(bp);
    800033c4:	854a                	mv	a0,s2
    800033c6:	7ef000ef          	jal	800043b4 <log_write>
  brelse(bp);
    800033ca:	854a                	mv	a0,s2
    800033cc:	e35ff0ef          	jal	80003200 <brelse>
}
    800033d0:	6906                	ld	s2,64(sp)
    800033d2:	79e2                	ld	s3,56(sp)
    800033d4:	7a42                	ld	s4,48(sp)
    800033d6:	7aa2                	ld	s5,40(sp)
    800033d8:	7b02                	ld	s6,32(sp)
    800033da:	6be2                	ld	s7,24(sp)
    800033dc:	6c42                	ld	s8,16(sp)
    800033de:	6ca2                	ld	s9,8(sp)
}
    800033e0:	8526                	mv	a0,s1
    800033e2:	60e6                	ld	ra,88(sp)
    800033e4:	6446                	ld	s0,80(sp)
    800033e6:	64a6                	ld	s1,72(sp)
    800033e8:	6125                	addi	sp,sp,96
    800033ea:	8082                	ret
    brelse(bp);
    800033ec:	854a                	mv	a0,s2
    800033ee:	e13ff0ef          	jal	80003200 <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    800033f2:	015c87bb          	addw	a5,s9,s5
    800033f6:	00078a9b          	sext.w	s5,a5
    800033fa:	004b2703          	lw	a4,4(s6)
    800033fe:	04eaff63          	bgeu	s5,a4,8000345c <balloc+0x100>
    bp = bread(dev, BBLOCK(b, sb));
    80003402:	41fad79b          	sraiw	a5,s5,0x1f
    80003406:	0137d79b          	srliw	a5,a5,0x13
    8000340a:	015787bb          	addw	a5,a5,s5
    8000340e:	40d7d79b          	sraiw	a5,a5,0xd
    80003412:	01cb2583          	lw	a1,28(s6)
    80003416:	9dbd                	addw	a1,a1,a5
    80003418:	855e                	mv	a0,s7
    8000341a:	cdfff0ef          	jal	800030f8 <bread>
    8000341e:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003420:	004b2503          	lw	a0,4(s6)
    80003424:	000a849b          	sext.w	s1,s5
    80003428:	8762                	mv	a4,s8
    8000342a:	fca4f1e3          	bgeu	s1,a0,800033ec <balloc+0x90>
      m = 1 << (bi % 8);
    8000342e:	00777693          	andi	a3,a4,7
    80003432:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    80003436:	41f7579b          	sraiw	a5,a4,0x1f
    8000343a:	01d7d79b          	srliw	a5,a5,0x1d
    8000343e:	9fb9                	addw	a5,a5,a4
    80003440:	4037d79b          	sraiw	a5,a5,0x3
    80003444:	00f90633          	add	a2,s2,a5
    80003448:	05864603          	lbu	a2,88(a2)
    8000344c:	00c6f5b3          	and	a1,a3,a2
    80003450:	d5a1                	beqz	a1,80003398 <balloc+0x3c>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003452:	2705                	addiw	a4,a4,1
    80003454:	2485                	addiw	s1,s1,1
    80003456:	fd471ae3          	bne	a4,s4,8000342a <balloc+0xce>
    8000345a:	bf49                	j	800033ec <balloc+0x90>
    8000345c:	6906                	ld	s2,64(sp)
    8000345e:	79e2                	ld	s3,56(sp)
    80003460:	7a42                	ld	s4,48(sp)
    80003462:	7aa2                	ld	s5,40(sp)
    80003464:	7b02                	ld	s6,32(sp)
    80003466:	6be2                	ld	s7,24(sp)
    80003468:	6c42                	ld	s8,16(sp)
    8000346a:	6ca2                	ld	s9,8(sp)
  printk("balloc: out of blocks\n");
    8000346c:	00005517          	auipc	a0,0x5
    80003470:	14450513          	addi	a0,a0,324 # 800085b0 <etext+0x5b0>
    80003474:	896fd0ef          	jal	8000050a <printk>
  return 0;
    80003478:	4481                	li	s1,0
    8000347a:	b79d                	j	800033e0 <balloc+0x84>

000000008000347c <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    8000347c:	7179                	addi	sp,sp,-48
    8000347e:	f406                	sd	ra,40(sp)
    80003480:	f022                	sd	s0,32(sp)
    80003482:	ec26                	sd	s1,24(sp)
    80003484:	e84a                	sd	s2,16(sp)
    80003486:	e44e                	sd	s3,8(sp)
    80003488:	1800                	addi	s0,sp,48
    8000348a:	89aa                	mv	s3,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    8000348c:	47ad                	li	a5,11
    8000348e:	02b7e663          	bltu	a5,a1,800034ba <bmap+0x3e>
    if ((addr = ip->addrs[bn]) == 0) {
    80003492:	02059793          	slli	a5,a1,0x20
    80003496:	01e7d593          	srli	a1,a5,0x1e
    8000349a:	00b504b3          	add	s1,a0,a1
    8000349e:	0504a903          	lw	s2,80(s1)
    800034a2:	06091a63          	bnez	s2,80003516 <bmap+0x9a>
      addr = balloc(ip->dev);
    800034a6:	4108                	lw	a0,0(a0)
    800034a8:	eb5ff0ef          	jal	8000335c <balloc>
    800034ac:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    800034b0:	06090363          	beqz	s2,80003516 <bmap+0x9a>
        return 0;
      ip->addrs[bn] = addr;
    800034b4:	0524a823          	sw	s2,80(s1)
    800034b8:	a8b9                	j	80003516 <bmap+0x9a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800034ba:	ff45849b          	addiw	s1,a1,-12
    800034be:	0004871b          	sext.w	a4,s1

  if (bn < NINDIRECT) {
    800034c2:	0ff00793          	li	a5,255
    800034c6:	06e7ee63          	bltu	a5,a4,80003542 <bmap+0xc6>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    800034ca:	08052903          	lw	s2,128(a0)
    800034ce:	00091d63          	bnez	s2,800034e8 <bmap+0x6c>
      addr = balloc(ip->dev);
    800034d2:	4108                	lw	a0,0(a0)
    800034d4:	e89ff0ef          	jal	8000335c <balloc>
    800034d8:	0005091b          	sext.w	s2,a0
      if (addr == 0)
    800034dc:	02090d63          	beqz	s2,80003516 <bmap+0x9a>
    800034e0:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    800034e2:	0929a023          	sw	s2,128(s3)
    800034e6:	a011                	j	800034ea <bmap+0x6e>
    800034e8:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    800034ea:	85ca                	mv	a1,s2
    800034ec:	0009a503          	lw	a0,0(s3)
    800034f0:	c09ff0ef          	jal	800030f8 <bread>
    800034f4:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    800034f6:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    800034fa:	02049713          	slli	a4,s1,0x20
    800034fe:	01e75593          	srli	a1,a4,0x1e
    80003502:	00b784b3          	add	s1,a5,a1
    80003506:	0004a903          	lw	s2,0(s1)
    8000350a:	00090e63          	beqz	s2,80003526 <bmap+0xaa>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000350e:	8552                	mv	a0,s4
    80003510:	cf1ff0ef          	jal	80003200 <brelse>
    return addr;
    80003514:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80003516:	854a                	mv	a0,s2
    80003518:	70a2                	ld	ra,40(sp)
    8000351a:	7402                	ld	s0,32(sp)
    8000351c:	64e2                	ld	s1,24(sp)
    8000351e:	6942                	ld	s2,16(sp)
    80003520:	69a2                	ld	s3,8(sp)
    80003522:	6145                	addi	sp,sp,48
    80003524:	8082                	ret
      addr = balloc(ip->dev);
    80003526:	0009a503          	lw	a0,0(s3)
    8000352a:	e33ff0ef          	jal	8000335c <balloc>
    8000352e:	0005091b          	sext.w	s2,a0
      if (addr) {
    80003532:	fc090ee3          	beqz	s2,8000350e <bmap+0x92>
        a[bn] = addr;
    80003536:	0124a023          	sw	s2,0(s1)
        log_write(bp);
    8000353a:	8552                	mv	a0,s4
    8000353c:	679000ef          	jal	800043b4 <log_write>
    80003540:	b7f9                	j	8000350e <bmap+0x92>
    80003542:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80003544:	00005517          	auipc	a0,0x5
    80003548:	08450513          	addi	a0,a0,132 # 800085c8 <etext+0x5c8>
    8000354c:	aa4fd0ef          	jal	800007f0 <panic>

0000000080003550 <iget>:
{
    80003550:	7179                	addi	sp,sp,-48
    80003552:	f406                	sd	ra,40(sp)
    80003554:	f022                	sd	s0,32(sp)
    80003556:	ec26                	sd	s1,24(sp)
    80003558:	e84a                	sd	s2,16(sp)
    8000355a:	e44e                	sd	s3,8(sp)
    8000355c:	e052                	sd	s4,0(sp)
    8000355e:	1800                	addi	s0,sp,48
    80003560:	89aa                	mv	s3,a0
    80003562:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80003564:	0001e517          	auipc	a0,0x1e
    80003568:	63450513          	addi	a0,a0,1588 # 80021b98 <itable>
    8000356c:	e24fd0ef          	jal	80000b90 <acquire>
  empty = 0;
    80003570:	4901                	li	s2,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80003572:	0001e497          	auipc	s1,0x1e
    80003576:	63e48493          	addi	s1,s1,1598 # 80021bb0 <itable+0x18>
    8000357a:	00020697          	auipc	a3,0x20
    8000357e:	0c668693          	addi	a3,a3,198 # 80023640 <log>
    80003582:	a039                	j	80003590 <iget+0x40>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    80003584:	02090963          	beqz	s2,800035b6 <iget+0x66>
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80003588:	08848493          	addi	s1,s1,136
    8000358c:	02d48863          	beq	s1,a3,800035bc <iget+0x6c>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    80003590:	449c                	lw	a5,8(s1)
    80003592:	fef059e3          	blez	a5,80003584 <iget+0x34>
    80003596:	4098                	lw	a4,0(s1)
    80003598:	ff3716e3          	bne	a4,s3,80003584 <iget+0x34>
    8000359c:	40d8                	lw	a4,4(s1)
    8000359e:	ff4713e3          	bne	a4,s4,80003584 <iget+0x34>
      ip->ref++;
    800035a2:	2785                	addiw	a5,a5,1
    800035a4:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800035a6:	0001e517          	auipc	a0,0x1e
    800035aa:	5f250513          	addi	a0,a0,1522 # 80021b98 <itable>
    800035ae:	e6efd0ef          	jal	80000c1c <release>
      return ip;
    800035b2:	8926                	mv	s2,s1
    800035b4:	a02d                	j	800035de <iget+0x8e>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    800035b6:	fbe9                	bnez	a5,80003588 <iget+0x38>
      empty = ip;
    800035b8:	8926                	mv	s2,s1
    800035ba:	b7f9                	j	80003588 <iget+0x38>
  if (empty == 0)
    800035bc:	02090a63          	beqz	s2,800035f0 <iget+0xa0>
  ip->dev = dev;
    800035c0:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    800035c4:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    800035c8:	4785                	li	a5,1
    800035ca:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    800035ce:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    800035d2:	0001e517          	auipc	a0,0x1e
    800035d6:	5c650513          	addi	a0,a0,1478 # 80021b98 <itable>
    800035da:	e42fd0ef          	jal	80000c1c <release>
}
    800035de:	854a                	mv	a0,s2
    800035e0:	70a2                	ld	ra,40(sp)
    800035e2:	7402                	ld	s0,32(sp)
    800035e4:	64e2                	ld	s1,24(sp)
    800035e6:	6942                	ld	s2,16(sp)
    800035e8:	69a2                	ld	s3,8(sp)
    800035ea:	6a02                	ld	s4,0(sp)
    800035ec:	6145                	addi	sp,sp,48
    800035ee:	8082                	ret
    panic("iget: no inodes");
    800035f0:	00005517          	auipc	a0,0x5
    800035f4:	ff050513          	addi	a0,a0,-16 # 800085e0 <etext+0x5e0>
    800035f8:	9f8fd0ef          	jal	800007f0 <panic>

00000000800035fc <iinit>:
{
    800035fc:	7179                	addi	sp,sp,-48
    800035fe:	f406                	sd	ra,40(sp)
    80003600:	f022                	sd	s0,32(sp)
    80003602:	ec26                	sd	s1,24(sp)
    80003604:	e84a                	sd	s2,16(sp)
    80003606:	e44e                	sd	s3,8(sp)
    80003608:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000360a:	00005597          	auipc	a1,0x5
    8000360e:	fe658593          	addi	a1,a1,-26 # 800085f0 <etext+0x5f0>
    80003612:	0001e517          	auipc	a0,0x1e
    80003616:	58650513          	addi	a0,a0,1414 # 80021b98 <itable>
    8000361a:	d00fd0ef          	jal	80000b1a <initlock>
  for (i = 0; i < NINODE; i++) {
    8000361e:	0001e497          	auipc	s1,0x1e
    80003622:	5a248493          	addi	s1,s1,1442 # 80021bc0 <itable+0x28>
    80003626:	00020997          	auipc	s3,0x20
    8000362a:	02a98993          	addi	s3,s3,42 # 80023650 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000362e:	00005917          	auipc	s2,0x5
    80003632:	fca90913          	addi	s2,s2,-54 # 800085f8 <etext+0x5f8>
    80003636:	85ca                	mv	a1,s2
    80003638:	8526                	mv	a0,s1
    8000363a:	6ad000ef          	jal	800044e6 <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    8000363e:	08848493          	addi	s1,s1,136
    80003642:	ff349ae3          	bne	s1,s3,80003636 <iinit+0x3a>
}
    80003646:	70a2                	ld	ra,40(sp)
    80003648:	7402                	ld	s0,32(sp)
    8000364a:	64e2                	ld	s1,24(sp)
    8000364c:	6942                	ld	s2,16(sp)
    8000364e:	69a2                	ld	s3,8(sp)
    80003650:	6145                	addi	sp,sp,48
    80003652:	8082                	ret

0000000080003654 <ialloc>:
{
    80003654:	7139                	addi	sp,sp,-64
    80003656:	fc06                	sd	ra,56(sp)
    80003658:	f822                	sd	s0,48(sp)
    8000365a:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    8000365c:	0001e717          	auipc	a4,0x1e
    80003660:	52872703          	lw	a4,1320(a4) # 80021b84 <sb+0xc>
    80003664:	4785                	li	a5,1
    80003666:	06e7f063          	bgeu	a5,a4,800036c6 <ialloc+0x72>
    8000366a:	f426                	sd	s1,40(sp)
    8000366c:	f04a                	sd	s2,32(sp)
    8000366e:	ec4e                	sd	s3,24(sp)
    80003670:	e852                	sd	s4,16(sp)
    80003672:	e456                	sd	s5,8(sp)
    80003674:	e05a                	sd	s6,0(sp)
    80003676:	8aaa                	mv	s5,a0
    80003678:	8b2e                	mv	s6,a1
    8000367a:	4905                	li	s2,1
    bp = bread(dev, IBLOCK(inum, sb));
    8000367c:	0001ea17          	auipc	s4,0x1e
    80003680:	4fca0a13          	addi	s4,s4,1276 # 80021b78 <sb>
    80003684:	00495593          	srli	a1,s2,0x4
    80003688:	018a2783          	lw	a5,24(s4)
    8000368c:	9dbd                	addw	a1,a1,a5
    8000368e:	8556                	mv	a0,s5
    80003690:	a69ff0ef          	jal	800030f8 <bread>
    80003694:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    80003696:	05850993          	addi	s3,a0,88
    8000369a:	00f97793          	andi	a5,s2,15
    8000369e:	079a                	slli	a5,a5,0x6
    800036a0:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    800036a2:	00099783          	lh	a5,0(s3)
    800036a6:	cb9d                	beqz	a5,800036dc <ialloc+0x88>
    brelse(bp);
    800036a8:	b59ff0ef          	jal	80003200 <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    800036ac:	0905                	addi	s2,s2,1
    800036ae:	00ca2703          	lw	a4,12(s4)
    800036b2:	0009079b          	sext.w	a5,s2
    800036b6:	fce7e7e3          	bltu	a5,a4,80003684 <ialloc+0x30>
    800036ba:	74a2                	ld	s1,40(sp)
    800036bc:	7902                	ld	s2,32(sp)
    800036be:	69e2                	ld	s3,24(sp)
    800036c0:	6a42                	ld	s4,16(sp)
    800036c2:	6aa2                	ld	s5,8(sp)
    800036c4:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    800036c6:	00005517          	auipc	a0,0x5
    800036ca:	f3a50513          	addi	a0,a0,-198 # 80008600 <etext+0x600>
    800036ce:	e3dfc0ef          	jal	8000050a <printk>
  return 0;
    800036d2:	4501                	li	a0,0
}
    800036d4:	70e2                	ld	ra,56(sp)
    800036d6:	7442                	ld	s0,48(sp)
    800036d8:	6121                	addi	sp,sp,64
    800036da:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800036dc:	04000613          	li	a2,64
    800036e0:	4581                	li	a1,0
    800036e2:	854e                	mv	a0,s3
    800036e4:	d70fd0ef          	jal	80000c54 <memset>
      dip->type = type;
    800036e8:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    800036ec:	8526                	mv	a0,s1
    800036ee:	4c7000ef          	jal	800043b4 <log_write>
      brelse(bp);
    800036f2:	8526                	mv	a0,s1
    800036f4:	b0dff0ef          	jal	80003200 <brelse>
      return iget(dev, inum);
    800036f8:	0009059b          	sext.w	a1,s2
    800036fc:	8556                	mv	a0,s5
    800036fe:	e53ff0ef          	jal	80003550 <iget>
    80003702:	74a2                	ld	s1,40(sp)
    80003704:	7902                	ld	s2,32(sp)
    80003706:	69e2                	ld	s3,24(sp)
    80003708:	6a42                	ld	s4,16(sp)
    8000370a:	6aa2                	ld	s5,8(sp)
    8000370c:	6b02                	ld	s6,0(sp)
    8000370e:	b7d9                	j	800036d4 <ialloc+0x80>

0000000080003710 <iupdate>:
{
    80003710:	1101                	addi	sp,sp,-32
    80003712:	ec06                	sd	ra,24(sp)
    80003714:	e822                	sd	s0,16(sp)
    80003716:	e426                	sd	s1,8(sp)
    80003718:	e04a                	sd	s2,0(sp)
    8000371a:	1000                	addi	s0,sp,32
    8000371c:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000371e:	415c                	lw	a5,4(a0)
    80003720:	0047d79b          	srliw	a5,a5,0x4
    80003724:	0001e597          	auipc	a1,0x1e
    80003728:	46c5a583          	lw	a1,1132(a1) # 80021b90 <sb+0x18>
    8000372c:	9dbd                	addw	a1,a1,a5
    8000372e:	4108                	lw	a0,0(a0)
    80003730:	9c9ff0ef          	jal	800030f8 <bread>
    80003734:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    80003736:	05850793          	addi	a5,a0,88
    8000373a:	40d8                	lw	a4,4(s1)
    8000373c:	8b3d                	andi	a4,a4,15
    8000373e:	071a                	slli	a4,a4,0x6
    80003740:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003742:	04449703          	lh	a4,68(s1)
    80003746:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000374a:	04649703          	lh	a4,70(s1)
    8000374e:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003752:	04849703          	lh	a4,72(s1)
    80003756:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000375a:	04a49703          	lh	a4,74(s1)
    8000375e:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003762:	44f8                	lw	a4,76(s1)
    80003764:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003766:	03400613          	li	a2,52
    8000376a:	05048593          	addi	a1,s1,80
    8000376e:	00c78513          	addi	a0,a5,12
    80003772:	d3efd0ef          	jal	80000cb0 <memmove>
  log_write(bp);
    80003776:	854a                	mv	a0,s2
    80003778:	43d000ef          	jal	800043b4 <log_write>
  brelse(bp);
    8000377c:	854a                	mv	a0,s2
    8000377e:	a83ff0ef          	jal	80003200 <brelse>
}
    80003782:	60e2                	ld	ra,24(sp)
    80003784:	6442                	ld	s0,16(sp)
    80003786:	64a2                	ld	s1,8(sp)
    80003788:	6902                	ld	s2,0(sp)
    8000378a:	6105                	addi	sp,sp,32
    8000378c:	8082                	ret

000000008000378e <idup>:
{
    8000378e:	1101                	addi	sp,sp,-32
    80003790:	ec06                	sd	ra,24(sp)
    80003792:	e822                	sd	s0,16(sp)
    80003794:	e426                	sd	s1,8(sp)
    80003796:	1000                	addi	s0,sp,32
    80003798:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000379a:	0001e517          	auipc	a0,0x1e
    8000379e:	3fe50513          	addi	a0,a0,1022 # 80021b98 <itable>
    800037a2:	beefd0ef          	jal	80000b90 <acquire>
  ip->ref++;
    800037a6:	449c                	lw	a5,8(s1)
    800037a8:	2785                	addiw	a5,a5,1
    800037aa:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800037ac:	0001e517          	auipc	a0,0x1e
    800037b0:	3ec50513          	addi	a0,a0,1004 # 80021b98 <itable>
    800037b4:	c68fd0ef          	jal	80000c1c <release>
}
    800037b8:	8526                	mv	a0,s1
    800037ba:	60e2                	ld	ra,24(sp)
    800037bc:	6442                	ld	s0,16(sp)
    800037be:	64a2                	ld	s1,8(sp)
    800037c0:	6105                	addi	sp,sp,32
    800037c2:	8082                	ret

00000000800037c4 <ilock>:
{
    800037c4:	1101                	addi	sp,sp,-32
    800037c6:	ec06                	sd	ra,24(sp)
    800037c8:	e822                	sd	s0,16(sp)
    800037ca:	e426                	sd	s1,8(sp)
    800037cc:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    800037ce:	cd19                	beqz	a0,800037ec <ilock+0x28>
    800037d0:	84aa                	mv	s1,a0
    800037d2:	451c                	lw	a5,8(a0)
    800037d4:	00f05c63          	blez	a5,800037ec <ilock+0x28>
  acquiresleep(&ip->lock);
    800037d8:	0541                	addi	a0,a0,16
    800037da:	543000ef          	jal	8000451c <acquiresleep>
  if (ip->valid == 0) {
    800037de:	40bc                	lw	a5,64(s1)
    800037e0:	cf89                	beqz	a5,800037fa <ilock+0x36>
}
    800037e2:	60e2                	ld	ra,24(sp)
    800037e4:	6442                	ld	s0,16(sp)
    800037e6:	64a2                	ld	s1,8(sp)
    800037e8:	6105                	addi	sp,sp,32
    800037ea:	8082                	ret
    800037ec:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800037ee:	00005517          	auipc	a0,0x5
    800037f2:	e2a50513          	addi	a0,a0,-470 # 80008618 <etext+0x618>
    800037f6:	ffbfc0ef          	jal	800007f0 <panic>
    800037fa:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800037fc:	40dc                	lw	a5,4(s1)
    800037fe:	0047d79b          	srliw	a5,a5,0x4
    80003802:	0001e597          	auipc	a1,0x1e
    80003806:	38e5a583          	lw	a1,910(a1) # 80021b90 <sb+0x18>
    8000380a:	9dbd                	addw	a1,a1,a5
    8000380c:	4088                	lw	a0,0(s1)
    8000380e:	8ebff0ef          	jal	800030f8 <bread>
    80003812:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    80003814:	05850593          	addi	a1,a0,88
    80003818:	40dc                	lw	a5,4(s1)
    8000381a:	8bbd                	andi	a5,a5,15
    8000381c:	079a                	slli	a5,a5,0x6
    8000381e:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003820:	00059783          	lh	a5,0(a1)
    80003824:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003828:	00259783          	lh	a5,2(a1)
    8000382c:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003830:	00459783          	lh	a5,4(a1)
    80003834:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003838:	00659783          	lh	a5,6(a1)
    8000383c:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003840:	459c                	lw	a5,8(a1)
    80003842:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003844:	03400613          	li	a2,52
    80003848:	05b1                	addi	a1,a1,12
    8000384a:	05048513          	addi	a0,s1,80
    8000384e:	c62fd0ef          	jal	80000cb0 <memmove>
    brelse(bp);
    80003852:	854a                	mv	a0,s2
    80003854:	9adff0ef          	jal	80003200 <brelse>
    ip->valid = 1;
    80003858:	4785                	li	a5,1
    8000385a:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    8000385c:	04449783          	lh	a5,68(s1)
    80003860:	c399                	beqz	a5,80003866 <ilock+0xa2>
    80003862:	6902                	ld	s2,0(sp)
    80003864:	bfbd                	j	800037e2 <ilock+0x1e>
      panic("ilock: no type");
    80003866:	00005517          	auipc	a0,0x5
    8000386a:	dba50513          	addi	a0,a0,-582 # 80008620 <etext+0x620>
    8000386e:	f83fc0ef          	jal	800007f0 <panic>

0000000080003872 <iunlock>:
{
    80003872:	1101                	addi	sp,sp,-32
    80003874:	ec06                	sd	ra,24(sp)
    80003876:	e822                	sd	s0,16(sp)
    80003878:	e426                	sd	s1,8(sp)
    8000387a:	e04a                	sd	s2,0(sp)
    8000387c:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000387e:	c505                	beqz	a0,800038a6 <iunlock+0x34>
    80003880:	84aa                	mv	s1,a0
    80003882:	01050913          	addi	s2,a0,16
    80003886:	854a                	mv	a0,s2
    80003888:	521000ef          	jal	800045a8 <holdingsleep>
    8000388c:	cd09                	beqz	a0,800038a6 <iunlock+0x34>
    8000388e:	449c                	lw	a5,8(s1)
    80003890:	00f05b63          	blez	a5,800038a6 <iunlock+0x34>
  releasesleep(&ip->lock);
    80003894:	854a                	mv	a0,s2
    80003896:	4db000ef          	jal	80004570 <releasesleep>
}
    8000389a:	60e2                	ld	ra,24(sp)
    8000389c:	6442                	ld	s0,16(sp)
    8000389e:	64a2                	ld	s1,8(sp)
    800038a0:	6902                	ld	s2,0(sp)
    800038a2:	6105                	addi	sp,sp,32
    800038a4:	8082                	ret
    panic("iunlock");
    800038a6:	00005517          	auipc	a0,0x5
    800038aa:	d8a50513          	addi	a0,a0,-630 # 80008630 <etext+0x630>
    800038ae:	f43fc0ef          	jal	800007f0 <panic>

00000000800038b2 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800038b2:	7179                	addi	sp,sp,-48
    800038b4:	f406                	sd	ra,40(sp)
    800038b6:	f022                	sd	s0,32(sp)
    800038b8:	ec26                	sd	s1,24(sp)
    800038ba:	e84a                	sd	s2,16(sp)
    800038bc:	e44e                	sd	s3,8(sp)
    800038be:	1800                	addi	s0,sp,48
    800038c0:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    800038c2:	05050493          	addi	s1,a0,80
    800038c6:	08050913          	addi	s2,a0,128
    800038ca:	a021                	j	800038d2 <itrunc+0x20>
    800038cc:	0491                	addi	s1,s1,4
    800038ce:	01248b63          	beq	s1,s2,800038e4 <itrunc+0x32>
    if (ip->addrs[i]) {
    800038d2:	408c                	lw	a1,0(s1)
    800038d4:	dde5                	beqz	a1,800038cc <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800038d6:	0009a503          	lw	a0,0(s3)
    800038da:	a17ff0ef          	jal	800032f0 <bfree>
      ip->addrs[i] = 0;
    800038de:	0004a023          	sw	zero,0(s1)
    800038e2:	b7ed                	j	800038cc <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    800038e4:	0809a583          	lw	a1,128(s3)
    800038e8:	ed89                	bnez	a1,80003902 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800038ea:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800038ee:	854e                	mv	a0,s3
    800038f0:	e21ff0ef          	jal	80003710 <iupdate>
}
    800038f4:	70a2                	ld	ra,40(sp)
    800038f6:	7402                	ld	s0,32(sp)
    800038f8:	64e2                	ld	s1,24(sp)
    800038fa:	6942                	ld	s2,16(sp)
    800038fc:	69a2                	ld	s3,8(sp)
    800038fe:	6145                	addi	sp,sp,48
    80003900:	8082                	ret
    80003902:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003904:	0009a503          	lw	a0,0(s3)
    80003908:	ff0ff0ef          	jal	800030f8 <bread>
    8000390c:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    8000390e:	05850493          	addi	s1,a0,88
    80003912:	45850913          	addi	s2,a0,1112
    80003916:	a021                	j	8000391e <itrunc+0x6c>
    80003918:	0491                	addi	s1,s1,4
    8000391a:	01248963          	beq	s1,s2,8000392c <itrunc+0x7a>
      if (a[j])
    8000391e:	408c                	lw	a1,0(s1)
    80003920:	dde5                	beqz	a1,80003918 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003922:	0009a503          	lw	a0,0(s3)
    80003926:	9cbff0ef          	jal	800032f0 <bfree>
    8000392a:	b7fd                	j	80003918 <itrunc+0x66>
    brelse(bp);
    8000392c:	8552                	mv	a0,s4
    8000392e:	8d3ff0ef          	jal	80003200 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003932:	0809a583          	lw	a1,128(s3)
    80003936:	0009a503          	lw	a0,0(s3)
    8000393a:	9b7ff0ef          	jal	800032f0 <bfree>
    ip->addrs[NDIRECT] = 0;
    8000393e:	0809a023          	sw	zero,128(s3)
    80003942:	6a02                	ld	s4,0(sp)
    80003944:	b75d                	j	800038ea <itrunc+0x38>

0000000080003946 <iput>:
{
    80003946:	7179                	addi	sp,sp,-48
    80003948:	f406                	sd	ra,40(sp)
    8000394a:	f022                	sd	s0,32(sp)
    8000394c:	ec26                	sd	s1,24(sp)
    8000394e:	1800                	addi	s0,sp,48
    80003950:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003952:	0001e517          	auipc	a0,0x1e
    80003956:	24650513          	addi	a0,a0,582 # 80021b98 <itable>
    8000395a:	a36fd0ef          	jal	80000b90 <acquire>
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    8000395e:	449c                	lw	a5,8(s1)
    80003960:	4705                	li	a4,1
    80003962:	00e78f63          	beq	a5,a4,80003980 <iput+0x3a>
  ip->ref--;
    80003966:	37fd                	addiw	a5,a5,-1
    80003968:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000396a:	0001e517          	auipc	a0,0x1e
    8000396e:	22e50513          	addi	a0,a0,558 # 80021b98 <itable>
    80003972:	aaafd0ef          	jal	80000c1c <release>
}
    80003976:	70a2                	ld	ra,40(sp)
    80003978:	7402                	ld	s0,32(sp)
    8000397a:	64e2                	ld	s1,24(sp)
    8000397c:	6145                	addi	sp,sp,48
    8000397e:	8082                	ret
  int last = (ip->ref == 1 && ip->valid && ip->nlink == 0);
    80003980:	40b8                	lw	a4,64(s1)
    80003982:	d375                	beqz	a4,80003966 <iput+0x20>
    80003984:	e84a                	sd	s2,16(sp)
    80003986:	e052                	sd	s4,0(sp)
  uint dev = ip->dev, inum = ip->inum;
    80003988:	0004aa03          	lw	s4,0(s1)
    8000398c:	0044a903          	lw	s2,4(s1)
  if (last) {
    80003990:	04a49703          	lh	a4,74(s1)
    80003994:	ef35                	bnez	a4,80003a10 <iput+0xca>
    80003996:	e44e                	sd	s3,8(sp)
    acquiresleep(&ip->lock);
    80003998:	01048993          	addi	s3,s1,16
    8000399c:	854e                	mv	a0,s3
    8000399e:	37f000ef          	jal	8000451c <acquiresleep>
    release(&itable.lock);
    800039a2:	0001e517          	auipc	a0,0x1e
    800039a6:	1f650513          	addi	a0,a0,502 # 80021b98 <itable>
    800039aa:	a72fd0ef          	jal	80000c1c <release>
    itrunc(ip); // free the data blocks (type stays nonzero on disk)
    800039ae:	8526                	mv	a0,s1
    800039b0:	f03ff0ef          	jal	800038b2 <itrunc>
    ip->valid = 0;
    800039b4:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800039b8:	854e                	mv	a0,s3
    800039ba:	3b7000ef          	jal	80004570 <releasesleep>
    acquire(&itable.lock);
    800039be:	0001e517          	auipc	a0,0x1e
    800039c2:	1da50513          	addi	a0,a0,474 # 80021b98 <itable>
    800039c6:	9cafd0ef          	jal	80000b90 <acquire>
  ip->ref--;
    800039ca:	449c                	lw	a5,8(s1)
    800039cc:	37fd                	addiw	a5,a5,-1
    800039ce:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800039d0:	0001e517          	auipc	a0,0x1e
    800039d4:	1c850513          	addi	a0,a0,456 # 80021b98 <itable>
    800039d8:	a44fd0ef          	jal	80000c1c <release>
  struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800039dc:	0049559b          	srliw	a1,s2,0x4
    800039e0:	0001e797          	auipc	a5,0x1e
    800039e4:	1b07a783          	lw	a5,432(a5) # 80021b90 <sb+0x18>
    800039e8:	9dbd                	addw	a1,a1,a5
    800039ea:	8552                	mv	a0,s4
    800039ec:	f0cff0ef          	jal	800030f8 <bread>
    800039f0:	84aa                	mv	s1,a0
  struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    800039f2:	00f97913          	andi	s2,s2,15
  dip->type = 0;
    800039f6:	091a                	slli	s2,s2,0x6
    800039f8:	992a                	add	s2,s2,a0
    800039fa:	04091c23          	sh	zero,88(s2)
  log_write(bp);
    800039fe:	1b7000ef          	jal	800043b4 <log_write>
  brelse(bp);
    80003a02:	8526                	mv	a0,s1
    80003a04:	ffcff0ef          	jal	80003200 <brelse>
}
    80003a08:	6942                	ld	s2,16(sp)
    80003a0a:	69a2                	ld	s3,8(sp)
    80003a0c:	6a02                	ld	s4,0(sp)
    80003a0e:	b7a5                	j	80003976 <iput+0x30>
    80003a10:	6942                	ld	s2,16(sp)
    80003a12:	6a02                	ld	s4,0(sp)
    80003a14:	bf89                	j	80003966 <iput+0x20>

0000000080003a16 <iunlockput>:
{
    80003a16:	1101                	addi	sp,sp,-32
    80003a18:	ec06                	sd	ra,24(sp)
    80003a1a:	e822                	sd	s0,16(sp)
    80003a1c:	e426                	sd	s1,8(sp)
    80003a1e:	1000                	addi	s0,sp,32
    80003a20:	84aa                	mv	s1,a0
  iunlock(ip);
    80003a22:	e51ff0ef          	jal	80003872 <iunlock>
  iput(ip);
    80003a26:	8526                	mv	a0,s1
    80003a28:	f1fff0ef          	jal	80003946 <iput>
}
    80003a2c:	60e2                	ld	ra,24(sp)
    80003a2e:	6442                	ld	s0,16(sp)
    80003a30:	64a2                	ld	s1,8(sp)
    80003a32:	6105                	addi	sp,sp,32
    80003a34:	8082                	ret

0000000080003a36 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003a36:	0001e717          	auipc	a4,0x1e
    80003a3a:	14e72703          	lw	a4,334(a4) # 80021b84 <sb+0xc>
    80003a3e:	4785                	li	a5,1
    80003a40:	0ae7ff63          	bgeu	a5,a4,80003afe <ireclaim+0xc8>
{
    80003a44:	7139                	addi	sp,sp,-64
    80003a46:	fc06                	sd	ra,56(sp)
    80003a48:	f822                	sd	s0,48(sp)
    80003a4a:	f426                	sd	s1,40(sp)
    80003a4c:	f04a                	sd	s2,32(sp)
    80003a4e:	ec4e                	sd	s3,24(sp)
    80003a50:	e852                	sd	s4,16(sp)
    80003a52:	e456                	sd	s5,8(sp)
    80003a54:	e05a                	sd	s6,0(sp)
    80003a56:	0080                	addi	s0,sp,64
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003a58:	4485                	li	s1,1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003a5a:	00050a1b          	sext.w	s4,a0
    80003a5e:	0001ea97          	auipc	s5,0x1e
    80003a62:	11aa8a93          	addi	s5,s5,282 # 80021b78 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    80003a66:	00005b17          	auipc	s6,0x5
    80003a6a:	bd2b0b13          	addi	s6,s6,-1070 # 80008638 <etext+0x638>
    80003a6e:	a099                	j	80003ab4 <ireclaim+0x7e>
    80003a70:	85ce                	mv	a1,s3
    80003a72:	855a                	mv	a0,s6
    80003a74:	a97fc0ef          	jal	8000050a <printk>
      ip = iget(dev, inum);
    80003a78:	85ce                	mv	a1,s3
    80003a7a:	8552                	mv	a0,s4
    80003a7c:	ad5ff0ef          	jal	80003550 <iget>
    80003a80:	89aa                	mv	s3,a0
    brelse(bp);
    80003a82:	854a                	mv	a0,s2
    80003a84:	f7cff0ef          	jal	80003200 <brelse>
    if (ip) {
    80003a88:	00098f63          	beqz	s3,80003aa6 <ireclaim+0x70>
      begin_op();
    80003a8c:	782000ef          	jal	8000420e <begin_op>
      ilock(ip);
    80003a90:	854e                	mv	a0,s3
    80003a92:	d33ff0ef          	jal	800037c4 <ilock>
      iunlock(ip);
    80003a96:	854e                	mv	a0,s3
    80003a98:	ddbff0ef          	jal	80003872 <iunlock>
      iput(ip);
    80003a9c:	854e                	mv	a0,s3
    80003a9e:	ea9ff0ef          	jal	80003946 <iput>
      end_op();
    80003aa2:	7f2000ef          	jal	80004294 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003aa6:	0485                	addi	s1,s1,1
    80003aa8:	00caa703          	lw	a4,12(s5)
    80003aac:	0004879b          	sext.w	a5,s1
    80003ab0:	02e7fd63          	bgeu	a5,a4,80003aea <ireclaim+0xb4>
    80003ab4:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003ab8:	0044d593          	srli	a1,s1,0x4
    80003abc:	018aa783          	lw	a5,24(s5)
    80003ac0:	9dbd                	addw	a1,a1,a5
    80003ac2:	8552                	mv	a0,s4
    80003ac4:	e34ff0ef          	jal	800030f8 <bread>
    80003ac8:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003aca:	05850793          	addi	a5,a0,88
    80003ace:	00f9f713          	andi	a4,s3,15
    80003ad2:	071a                	slli	a4,a4,0x6
    80003ad4:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    80003ad6:	00079703          	lh	a4,0(a5)
    80003ada:	c701                	beqz	a4,80003ae2 <ireclaim+0xac>
    80003adc:	00679783          	lh	a5,6(a5)
    80003ae0:	dbc1                	beqz	a5,80003a70 <ireclaim+0x3a>
    brelse(bp);
    80003ae2:	854a                	mv	a0,s2
    80003ae4:	f1cff0ef          	jal	80003200 <brelse>
    if (ip) {
    80003ae8:	bf7d                	j	80003aa6 <ireclaim+0x70>
}
    80003aea:	70e2                	ld	ra,56(sp)
    80003aec:	7442                	ld	s0,48(sp)
    80003aee:	74a2                	ld	s1,40(sp)
    80003af0:	7902                	ld	s2,32(sp)
    80003af2:	69e2                	ld	s3,24(sp)
    80003af4:	6a42                	ld	s4,16(sp)
    80003af6:	6aa2                	ld	s5,8(sp)
    80003af8:	6b02                	ld	s6,0(sp)
    80003afa:	6121                	addi	sp,sp,64
    80003afc:	8082                	ret
    80003afe:	8082                	ret

0000000080003b00 <fsinit>:
{
    80003b00:	7179                	addi	sp,sp,-48
    80003b02:	f406                	sd	ra,40(sp)
    80003b04:	f022                	sd	s0,32(sp)
    80003b06:	ec26                	sd	s1,24(sp)
    80003b08:	e84a                	sd	s2,16(sp)
    80003b0a:	e44e                	sd	s3,8(sp)
    80003b0c:	1800                	addi	s0,sp,48
    80003b0e:	84aa                	mv	s1,a0
  bp = bread(dev, 1);
    80003b10:	4585                	li	a1,1
    80003b12:	de6ff0ef          	jal	800030f8 <bread>
    80003b16:	892a                	mv	s2,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003b18:	0001e997          	auipc	s3,0x1e
    80003b1c:	06098993          	addi	s3,s3,96 # 80021b78 <sb>
    80003b20:	02000613          	li	a2,32
    80003b24:	05850593          	addi	a1,a0,88
    80003b28:	854e                	mv	a0,s3
    80003b2a:	986fd0ef          	jal	80000cb0 <memmove>
  brelse(bp);
    80003b2e:	854a                	mv	a0,s2
    80003b30:	ed0ff0ef          	jal	80003200 <brelse>
  if (sb.magic != FSMAGIC)
    80003b34:	0009a703          	lw	a4,0(s3)
    80003b38:	102037b7          	lui	a5,0x10203
    80003b3c:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003b40:	02f71363          	bne	a4,a5,80003b66 <fsinit+0x66>
  initlog(dev, &sb);
    80003b44:	0001e597          	auipc	a1,0x1e
    80003b48:	03458593          	addi	a1,a1,52 # 80021b78 <sb>
    80003b4c:	8526                	mv	a0,s1
    80003b4e:	642000ef          	jal	80004190 <initlog>
  ireclaim(dev);
    80003b52:	8526                	mv	a0,s1
    80003b54:	ee3ff0ef          	jal	80003a36 <ireclaim>
}
    80003b58:	70a2                	ld	ra,40(sp)
    80003b5a:	7402                	ld	s0,32(sp)
    80003b5c:	64e2                	ld	s1,24(sp)
    80003b5e:	6942                	ld	s2,16(sp)
    80003b60:	69a2                	ld	s3,8(sp)
    80003b62:	6145                	addi	sp,sp,48
    80003b64:	8082                	ret
    panic("invalid file system");
    80003b66:	00005517          	auipc	a0,0x5
    80003b6a:	af250513          	addi	a0,a0,-1294 # 80008658 <etext+0x658>
    80003b6e:	c83fc0ef          	jal	800007f0 <panic>

0000000080003b72 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003b72:	1141                	addi	sp,sp,-16
    80003b74:	e422                	sd	s0,8(sp)
    80003b76:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003b78:	411c                	lw	a5,0(a0)
    80003b7a:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003b7c:	415c                	lw	a5,4(a0)
    80003b7e:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003b80:	04451783          	lh	a5,68(a0)
    80003b84:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003b88:	04a51783          	lh	a5,74(a0)
    80003b8c:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003b90:	04c56783          	lwu	a5,76(a0)
    80003b94:	e99c                	sd	a5,16(a1)
}
    80003b96:	6422                	ld	s0,8(sp)
    80003b98:	0141                	addi	sp,sp,16
    80003b9a:	8082                	ret

0000000080003b9c <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003b9c:	457c                	lw	a5,76(a0)
    80003b9e:	0ed7eb63          	bltu	a5,a3,80003c94 <readi+0xf8>
{
    80003ba2:	7159                	addi	sp,sp,-112
    80003ba4:	f486                	sd	ra,104(sp)
    80003ba6:	f0a2                	sd	s0,96(sp)
    80003ba8:	eca6                	sd	s1,88(sp)
    80003baa:	e0d2                	sd	s4,64(sp)
    80003bac:	fc56                	sd	s5,56(sp)
    80003bae:	f85a                	sd	s6,48(sp)
    80003bb0:	f45e                	sd	s7,40(sp)
    80003bb2:	1880                	addi	s0,sp,112
    80003bb4:	8b2a                	mv	s6,a0
    80003bb6:	8bae                	mv	s7,a1
    80003bb8:	8a32                	mv	s4,a2
    80003bba:	84b6                	mv	s1,a3
    80003bbc:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003bbe:	9f35                	addw	a4,a4,a3
    return 0;
    80003bc0:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    80003bc2:	0cd76063          	bltu	a4,a3,80003c82 <readi+0xe6>
    80003bc6:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    80003bc8:	00e7f463          	bgeu	a5,a4,80003bd0 <readi+0x34>
    n = ip->size - off;
    80003bcc:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003bd0:	080a8f63          	beqz	s5,80003c6e <readi+0xd2>
    80003bd4:	e8ca                	sd	s2,80(sp)
    80003bd6:	f062                	sd	s8,32(sp)
    80003bd8:	ec66                	sd	s9,24(sp)
    80003bda:	e86a                	sd	s10,16(sp)
    80003bdc:	e46e                	sd	s11,8(sp)
    80003bde:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003be0:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003be4:	5c7d                	li	s8,-1
    80003be6:	a80d                	j	80003c18 <readi+0x7c>
    80003be8:	020d1d93          	slli	s11,s10,0x20
    80003bec:	020ddd93          	srli	s11,s11,0x20
    80003bf0:	05890613          	addi	a2,s2,88
    80003bf4:	86ee                	mv	a3,s11
    80003bf6:	963a                	add	a2,a2,a4
    80003bf8:	85d2                	mv	a1,s4
    80003bfa:	855e                	mv	a0,s7
    80003bfc:	e3efe0ef          	jal	8000223a <either_copyout>
    80003c00:	05850763          	beq	a0,s8,80003c4e <readi+0xb2>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003c04:	854a                	mv	a0,s2
    80003c06:	dfaff0ef          	jal	80003200 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003c0a:	013d09bb          	addw	s3,s10,s3
    80003c0e:	009d04bb          	addw	s1,s10,s1
    80003c12:	9a6e                	add	s4,s4,s11
    80003c14:	0559f763          	bgeu	s3,s5,80003c62 <readi+0xc6>
    uint addr = bmap(ip, off / BSIZE);
    80003c18:	00a4d59b          	srliw	a1,s1,0xa
    80003c1c:	855a                	mv	a0,s6
    80003c1e:	85fff0ef          	jal	8000347c <bmap>
    80003c22:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    80003c26:	c5b1                	beqz	a1,80003c72 <readi+0xd6>
    bp = bread(ip->dev, addr);
    80003c28:	000b2503          	lw	a0,0(s6)
    80003c2c:	cccff0ef          	jal	800030f8 <bread>
    80003c30:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003c32:	3ff4f713          	andi	a4,s1,1023
    80003c36:	40ec87bb          	subw	a5,s9,a4
    80003c3a:	413a86bb          	subw	a3,s5,s3
    80003c3e:	8d3e                	mv	s10,a5
    80003c40:	2781                	sext.w	a5,a5
    80003c42:	0006861b          	sext.w	a2,a3
    80003c46:	faf671e3          	bgeu	a2,a5,80003be8 <readi+0x4c>
    80003c4a:	8d36                	mv	s10,a3
    80003c4c:	bf71                	j	80003be8 <readi+0x4c>
      brelse(bp);
    80003c4e:	854a                	mv	a0,s2
    80003c50:	db0ff0ef          	jal	80003200 <brelse>
      tot = -1;
    80003c54:	59fd                	li	s3,-1
      break;
    80003c56:	6946                	ld	s2,80(sp)
    80003c58:	7c02                	ld	s8,32(sp)
    80003c5a:	6ce2                	ld	s9,24(sp)
    80003c5c:	6d42                	ld	s10,16(sp)
    80003c5e:	6da2                	ld	s11,8(sp)
    80003c60:	a831                	j	80003c7c <readi+0xe0>
    80003c62:	6946                	ld	s2,80(sp)
    80003c64:	7c02                	ld	s8,32(sp)
    80003c66:	6ce2                	ld	s9,24(sp)
    80003c68:	6d42                	ld	s10,16(sp)
    80003c6a:	6da2                	ld	s11,8(sp)
    80003c6c:	a801                	j	80003c7c <readi+0xe0>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003c6e:	89d6                	mv	s3,s5
    80003c70:	a031                	j	80003c7c <readi+0xe0>
    80003c72:	6946                	ld	s2,80(sp)
    80003c74:	7c02                	ld	s8,32(sp)
    80003c76:	6ce2                	ld	s9,24(sp)
    80003c78:	6d42                	ld	s10,16(sp)
    80003c7a:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003c7c:	0009851b          	sext.w	a0,s3
    80003c80:	69a6                	ld	s3,72(sp)
}
    80003c82:	70a6                	ld	ra,104(sp)
    80003c84:	7406                	ld	s0,96(sp)
    80003c86:	64e6                	ld	s1,88(sp)
    80003c88:	6a06                	ld	s4,64(sp)
    80003c8a:	7ae2                	ld	s5,56(sp)
    80003c8c:	7b42                	ld	s6,48(sp)
    80003c8e:	7ba2                	ld	s7,40(sp)
    80003c90:	6165                	addi	sp,sp,112
    80003c92:	8082                	ret
    return 0;
    80003c94:	4501                	li	a0,0
}
    80003c96:	8082                	ret

0000000080003c98 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003c98:	457c                	lw	a5,76(a0)
    80003c9a:	10d7e363          	bltu	a5,a3,80003da0 <writei+0x108>
{
    80003c9e:	7159                	addi	sp,sp,-112
    80003ca0:	f486                	sd	ra,104(sp)
    80003ca2:	f0a2                	sd	s0,96(sp)
    80003ca4:	e8ca                	sd	s2,80(sp)
    80003ca6:	e0d2                	sd	s4,64(sp)
    80003ca8:	fc56                	sd	s5,56(sp)
    80003caa:	f85a                	sd	s6,48(sp)
    80003cac:	f45e                	sd	s7,40(sp)
    80003cae:	1880                	addi	s0,sp,112
    80003cb0:	8aaa                	mv	s5,a0
    80003cb2:	8bae                	mv	s7,a1
    80003cb4:	8a32                	mv	s4,a2
    80003cb6:	8936                	mv	s2,a3
    80003cb8:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    80003cba:	00e687bb          	addw	a5,a3,a4
    80003cbe:	0ed7e363          	bltu	a5,a3,80003da4 <writei+0x10c>
    return -1;
  if (off + n > MAXFILE * BSIZE)
    80003cc2:	00043737          	lui	a4,0x43
    80003cc6:	0ef76163          	bltu	a4,a5,80003da8 <writei+0x110>
    80003cca:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003ccc:	0c0b0263          	beqz	s6,80003d90 <writei+0xf8>
    80003cd0:	eca6                	sd	s1,88(sp)
    80003cd2:	f062                	sd	s8,32(sp)
    80003cd4:	ec66                	sd	s9,24(sp)
    80003cd6:	e86a                	sd	s10,16(sp)
    80003cd8:	e46e                	sd	s11,8(sp)
    80003cda:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003cdc:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003ce0:	5c7d                	li	s8,-1
    80003ce2:	a825                	j	80003d1a <writei+0x82>
    80003ce4:	020d1d93          	slli	s11,s10,0x20
    80003ce8:	020ddd93          	srli	s11,s11,0x20
    80003cec:	05848513          	addi	a0,s1,88
    80003cf0:	86ee                	mv	a3,s11
    80003cf2:	8652                	mv	a2,s4
    80003cf4:	85de                	mv	a1,s7
    80003cf6:	953a                	add	a0,a0,a4
    80003cf8:	d8efe0ef          	jal	80002286 <either_copyin>
    80003cfc:	05850a63          	beq	a0,s8,80003d50 <writei+0xb8>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    80003d00:	8526                	mv	a0,s1
    80003d02:	6b2000ef          	jal	800043b4 <log_write>
    brelse(bp);
    80003d06:	8526                	mv	a0,s1
    80003d08:	cf8ff0ef          	jal	80003200 <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003d0c:	013d09bb          	addw	s3,s10,s3
    80003d10:	012d093b          	addw	s2,s10,s2
    80003d14:	9a6e                	add	s4,s4,s11
    80003d16:	0569f363          	bgeu	s3,s6,80003d5c <writei+0xc4>
    uint addr = bmap(ip, off / BSIZE);
    80003d1a:	00a9559b          	srliw	a1,s2,0xa
    80003d1e:	8556                	mv	a0,s5
    80003d20:	f5cff0ef          	jal	8000347c <bmap>
    80003d24:	0005059b          	sext.w	a1,a0
    if (addr == 0)
    80003d28:	c995                	beqz	a1,80003d5c <writei+0xc4>
    bp = bread(ip->dev, addr);
    80003d2a:	000aa503          	lw	a0,0(s5)
    80003d2e:	bcaff0ef          	jal	800030f8 <bread>
    80003d32:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003d34:	3ff97713          	andi	a4,s2,1023
    80003d38:	40ec87bb          	subw	a5,s9,a4
    80003d3c:	413b06bb          	subw	a3,s6,s3
    80003d40:	8d3e                	mv	s10,a5
    80003d42:	2781                	sext.w	a5,a5
    80003d44:	0006861b          	sext.w	a2,a3
    80003d48:	f8f67ee3          	bgeu	a2,a5,80003ce4 <writei+0x4c>
    80003d4c:	8d36                	mv	s10,a3
    80003d4e:	bf59                	j	80003ce4 <writei+0x4c>
      log_write(bp);
    80003d50:	8526                	mv	a0,s1
    80003d52:	662000ef          	jal	800043b4 <log_write>
      brelse(bp);
    80003d56:	8526                	mv	a0,s1
    80003d58:	ca8ff0ef          	jal	80003200 <brelse>
  }

  if (off > ip->size)
    80003d5c:	04caa783          	lw	a5,76(s5)
    80003d60:	0327fa63          	bgeu	a5,s2,80003d94 <writei+0xfc>
    ip->size = off;
    80003d64:	052aa623          	sw	s2,76(s5)
    80003d68:	64e6                	ld	s1,88(sp)
    80003d6a:	7c02                	ld	s8,32(sp)
    80003d6c:	6ce2                	ld	s9,24(sp)
    80003d6e:	6d42                	ld	s10,16(sp)
    80003d70:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003d72:	8556                	mv	a0,s5
    80003d74:	99dff0ef          	jal	80003710 <iupdate>

  return tot;
    80003d78:	0009851b          	sext.w	a0,s3
    80003d7c:	69a6                	ld	s3,72(sp)
}
    80003d7e:	70a6                	ld	ra,104(sp)
    80003d80:	7406                	ld	s0,96(sp)
    80003d82:	6946                	ld	s2,80(sp)
    80003d84:	6a06                	ld	s4,64(sp)
    80003d86:	7ae2                	ld	s5,56(sp)
    80003d88:	7b42                	ld	s6,48(sp)
    80003d8a:	7ba2                	ld	s7,40(sp)
    80003d8c:	6165                	addi	sp,sp,112
    80003d8e:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003d90:	89da                	mv	s3,s6
    80003d92:	b7c5                	j	80003d72 <writei+0xda>
    80003d94:	64e6                	ld	s1,88(sp)
    80003d96:	7c02                	ld	s8,32(sp)
    80003d98:	6ce2                	ld	s9,24(sp)
    80003d9a:	6d42                	ld	s10,16(sp)
    80003d9c:	6da2                	ld	s11,8(sp)
    80003d9e:	bfd1                	j	80003d72 <writei+0xda>
    return -1;
    80003da0:	557d                	li	a0,-1
}
    80003da2:	8082                	ret
    return -1;
    80003da4:	557d                	li	a0,-1
    80003da6:	bfe1                	j	80003d7e <writei+0xe6>
    return -1;
    80003da8:	557d                	li	a0,-1
    80003daa:	bfd1                	j	80003d7e <writei+0xe6>

0000000080003dac <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003dac:	1141                	addi	sp,sp,-16
    80003dae:	e406                	sd	ra,8(sp)
    80003db0:	e022                	sd	s0,0(sp)
    80003db2:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003db4:	4639                	li	a2,14
    80003db6:	f6bfc0ef          	jal	80000d20 <strncmp>
}
    80003dba:	60a2                	ld	ra,8(sp)
    80003dbc:	6402                	ld	s0,0(sp)
    80003dbe:	0141                	addi	sp,sp,16
    80003dc0:	8082                	ret

0000000080003dc2 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003dc2:	7139                	addi	sp,sp,-64
    80003dc4:	fc06                	sd	ra,56(sp)
    80003dc6:	f822                	sd	s0,48(sp)
    80003dc8:	f426                	sd	s1,40(sp)
    80003dca:	f04a                	sd	s2,32(sp)
    80003dcc:	ec4e                	sd	s3,24(sp)
    80003dce:	e852                	sd	s4,16(sp)
    80003dd0:	0080                	addi	s0,sp,64
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    80003dd2:	04451703          	lh	a4,68(a0)
    80003dd6:	4785                	li	a5,1
    80003dd8:	00f71a63          	bne	a4,a5,80003dec <dirlookup+0x2a>
    80003ddc:	892a                	mv	s2,a0
    80003dde:	89ae                	mv	s3,a1
    80003de0:	8a32                	mv	s4,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003de2:	457c                	lw	a5,76(a0)
    80003de4:	4481                	li	s1,0
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003de6:	4501                	li	a0,0
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003de8:	e39d                	bnez	a5,80003e0e <dirlookup+0x4c>
    80003dea:	a095                	j	80003e4e <dirlookup+0x8c>
    panic("dirlookup not DIR");
    80003dec:	00005517          	auipc	a0,0x5
    80003df0:	88450513          	addi	a0,a0,-1916 # 80008670 <etext+0x670>
    80003df4:	9fdfc0ef          	jal	800007f0 <panic>
      panic("dirlookup read");
    80003df8:	00005517          	auipc	a0,0x5
    80003dfc:	89050513          	addi	a0,a0,-1904 # 80008688 <etext+0x688>
    80003e00:	9f1fc0ef          	jal	800007f0 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003e04:	24c1                	addiw	s1,s1,16
    80003e06:	04c92783          	lw	a5,76(s2)
    80003e0a:	04f4f163          	bgeu	s1,a5,80003e4c <dirlookup+0x8a>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003e0e:	4741                	li	a4,16
    80003e10:	86a6                	mv	a3,s1
    80003e12:	fc040613          	addi	a2,s0,-64
    80003e16:	4581                	li	a1,0
    80003e18:	854a                	mv	a0,s2
    80003e1a:	d83ff0ef          	jal	80003b9c <readi>
    80003e1e:	47c1                	li	a5,16
    80003e20:	fcf51ce3          	bne	a0,a5,80003df8 <dirlookup+0x36>
    if (de.inum == 0)
    80003e24:	fc045783          	lhu	a5,-64(s0)
    80003e28:	dff1                	beqz	a5,80003e04 <dirlookup+0x42>
    if (namecmp(name, de.name) == 0) {
    80003e2a:	fc240593          	addi	a1,s0,-62
    80003e2e:	854e                	mv	a0,s3
    80003e30:	f7dff0ef          	jal	80003dac <namecmp>
    80003e34:	f961                	bnez	a0,80003e04 <dirlookup+0x42>
      if (poff)
    80003e36:	000a0463          	beqz	s4,80003e3e <dirlookup+0x7c>
        *poff = off;
    80003e3a:	009a2023          	sw	s1,0(s4)
      return iget(dp->dev, inum);
    80003e3e:	fc045583          	lhu	a1,-64(s0)
    80003e42:	00092503          	lw	a0,0(s2)
    80003e46:	f0aff0ef          	jal	80003550 <iget>
    80003e4a:	a011                	j	80003e4e <dirlookup+0x8c>
  return 0;
    80003e4c:	4501                	li	a0,0
}
    80003e4e:	70e2                	ld	ra,56(sp)
    80003e50:	7442                	ld	s0,48(sp)
    80003e52:	74a2                	ld	s1,40(sp)
    80003e54:	7902                	ld	s2,32(sp)
    80003e56:	69e2                	ld	s3,24(sp)
    80003e58:	6a42                	ld	s4,16(sp)
    80003e5a:	6121                	addi	sp,sp,64
    80003e5c:	8082                	ret

0000000080003e5e <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    80003e5e:	711d                	addi	sp,sp,-96
    80003e60:	ec86                	sd	ra,88(sp)
    80003e62:	e8a2                	sd	s0,80(sp)
    80003e64:	e4a6                	sd	s1,72(sp)
    80003e66:	e0ca                	sd	s2,64(sp)
    80003e68:	fc4e                	sd	s3,56(sp)
    80003e6a:	f852                	sd	s4,48(sp)
    80003e6c:	f456                	sd	s5,40(sp)
    80003e6e:	f05a                	sd	s6,32(sp)
    80003e70:	ec5e                	sd	s7,24(sp)
    80003e72:	e862                	sd	s8,16(sp)
    80003e74:	e466                	sd	s9,8(sp)
    80003e76:	1080                	addi	s0,sp,96
    80003e78:	84aa                	mv	s1,a0
    80003e7a:	8b2e                	mv	s6,a1
    80003e7c:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    80003e7e:	00054703          	lbu	a4,0(a0)
    80003e82:	02f00793          	li	a5,47
    80003e86:	00f70e63          	beq	a4,a5,80003ea2 <namex+0x44>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003e8a:	a19fd0ef          	jal	800018a2 <myproc>
    80003e8e:	15053503          	ld	a0,336(a0)
    80003e92:	8fdff0ef          	jal	8000378e <idup>
    80003e96:	8a2a                	mv	s4,a0
  while (*path == '/')
    80003e98:	02f00913          	li	s2,47
  if (len >= DIRSIZ)
    80003e9c:	4c35                	li	s8,13

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    80003e9e:	4b85                	li	s7,1
    80003ea0:	a075                	j	80003f4c <namex+0xee>
    ip = iget(ROOTDEV, ROOTINO);
    80003ea2:	4585                	li	a1,1
    80003ea4:	4505                	li	a0,1
    80003ea6:	eaaff0ef          	jal	80003550 <iget>
    80003eaa:	8a2a                	mv	s4,a0
    80003eac:	b7f5                	j	80003e98 <namex+0x3a>
      iunlockput(ip);
    80003eae:	8552                	mv	a0,s4
    80003eb0:	b67ff0ef          	jal	80003a16 <iunlockput>
      return 0;
    80003eb4:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80003eb6:	8552                	mv	a0,s4
    80003eb8:	60e6                	ld	ra,88(sp)
    80003eba:	6446                	ld	s0,80(sp)
    80003ebc:	64a6                	ld	s1,72(sp)
    80003ebe:	6906                	ld	s2,64(sp)
    80003ec0:	79e2                	ld	s3,56(sp)
    80003ec2:	7a42                	ld	s4,48(sp)
    80003ec4:	7aa2                	ld	s5,40(sp)
    80003ec6:	7b02                	ld	s6,32(sp)
    80003ec8:	6be2                	ld	s7,24(sp)
    80003eca:	6c42                	ld	s8,16(sp)
    80003ecc:	6ca2                	ld	s9,8(sp)
    80003ece:	6125                	addi	sp,sp,96
    80003ed0:	8082                	ret
      iunlockput(ip);
    80003ed2:	8552                	mv	a0,s4
    80003ed4:	b43ff0ef          	jal	80003a16 <iunlockput>
      return 0;
    80003ed8:	4a01                	li	s4,0
    80003eda:	bff1                	j	80003eb6 <namex+0x58>
      iunlock(ip);
    80003edc:	8552                	mv	a0,s4
    80003ede:	995ff0ef          	jal	80003872 <iunlock>
      return ip;
    80003ee2:	bfd1                	j	80003eb6 <namex+0x58>
      iunlockput(ip);
    80003ee4:	8552                	mv	a0,s4
    80003ee6:	b31ff0ef          	jal	80003a16 <iunlockput>
      return 0;
    80003eea:	8a4e                	mv	s4,s3
    80003eec:	b7e9                	j	80003eb6 <namex+0x58>
  len = path - s;
    80003eee:	40998633          	sub	a2,s3,s1
    80003ef2:	00060c9b          	sext.w	s9,a2
  if (len >= DIRSIZ)
    80003ef6:	099c5363          	bge	s8,s9,80003f7c <namex+0x11e>
    memmove(name, s, DIRSIZ);
    80003efa:	4639                	li	a2,14
    80003efc:	85a6                	mv	a1,s1
    80003efe:	8556                	mv	a0,s5
    80003f00:	db1fc0ef          	jal	80000cb0 <memmove>
    80003f04:	84ce                	mv	s1,s3
  while (*path == '/')
    80003f06:	0004c783          	lbu	a5,0(s1)
    80003f0a:	09279363          	bne	a5,s2,80003f90 <namex+0x132>
    path++;
    80003f0e:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003f10:	0004c783          	lbu	a5,0(s1)
    80003f14:	ff278de3          	beq	a5,s2,80003f0e <namex+0xb0>
    ilock(ip);
    80003f18:	8552                	mv	a0,s4
    80003f1a:	8abff0ef          	jal	800037c4 <ilock>
    if (ip->type != T_DIR) {
    80003f1e:	044a1783          	lh	a5,68(s4)
    80003f22:	f97796e3          	bne	a5,s7,80003eae <namex+0x50>
    if (ip->nlink == 0) {
    80003f26:	04aa1783          	lh	a5,74(s4)
    80003f2a:	d7c5                	beqz	a5,80003ed2 <namex+0x74>
    if (nameiparent && *path == '\0') {
    80003f2c:	000b0563          	beqz	s6,80003f36 <namex+0xd8>
    80003f30:	0004c783          	lbu	a5,0(s1)
    80003f34:	d7c5                	beqz	a5,80003edc <namex+0x7e>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    80003f36:	4601                	li	a2,0
    80003f38:	85d6                	mv	a1,s5
    80003f3a:	8552                	mv	a0,s4
    80003f3c:	e87ff0ef          	jal	80003dc2 <dirlookup>
    80003f40:	89aa                	mv	s3,a0
    80003f42:	d14d                	beqz	a0,80003ee4 <namex+0x86>
    iunlockput(ip);
    80003f44:	8552                	mv	a0,s4
    80003f46:	ad1ff0ef          	jal	80003a16 <iunlockput>
    ip = next;
    80003f4a:	8a4e                	mv	s4,s3
  while (*path == '/')
    80003f4c:	0004c783          	lbu	a5,0(s1)
    80003f50:	01279763          	bne	a5,s2,80003f5e <namex+0x100>
    path++;
    80003f54:	0485                	addi	s1,s1,1
  while (*path == '/')
    80003f56:	0004c783          	lbu	a5,0(s1)
    80003f5a:	ff278de3          	beq	a5,s2,80003f54 <namex+0xf6>
  if (*path == 0)
    80003f5e:	cb95                	beqz	a5,80003f92 <namex+0x134>
  while (*path != '/' && *path != 0)
    80003f60:	0004c783          	lbu	a5,0(s1)
    80003f64:	89a6                	mv	s3,s1
  len = path - s;
    80003f66:	4c81                	li	s9,0
    80003f68:	4601                	li	a2,0
  while (*path != '/' && *path != 0)
    80003f6a:	01278963          	beq	a5,s2,80003f7c <namex+0x11e>
    80003f6e:	d3c1                	beqz	a5,80003eee <namex+0x90>
    path++;
    80003f70:	0985                	addi	s3,s3,1
  while (*path != '/' && *path != 0)
    80003f72:	0009c783          	lbu	a5,0(s3)
    80003f76:	ff279ce3          	bne	a5,s2,80003f6e <namex+0x110>
    80003f7a:	bf95                	j	80003eee <namex+0x90>
    memmove(name, s, len);
    80003f7c:	2601                	sext.w	a2,a2
    80003f7e:	85a6                	mv	a1,s1
    80003f80:	8556                	mv	a0,s5
    80003f82:	d2ffc0ef          	jal	80000cb0 <memmove>
    name[len] = 0;
    80003f86:	9cd6                	add	s9,s9,s5
    80003f88:	000c8023          	sb	zero,0(s9) # 2000 <_entry-0x7fffe000>
    80003f8c:	84ce                	mv	s1,s3
    80003f8e:	bfa5                	j	80003f06 <namex+0xa8>
  while ((path = skipelem(path, name)) != 0) {
    80003f90:	f4c1                	bnez	s1,80003f18 <namex+0xba>
  if (nameiparent) {
    80003f92:	f20b02e3          	beqz	s6,80003eb6 <namex+0x58>
    iput(ip);
    80003f96:	8552                	mv	a0,s4
    80003f98:	9afff0ef          	jal	80003946 <iput>
    return 0;
    80003f9c:	4a01                	li	s4,0
    80003f9e:	bf21                	j	80003eb6 <namex+0x58>

0000000080003fa0 <dirlink>:
{
    80003fa0:	7139                	addi	sp,sp,-64
    80003fa2:	fc06                	sd	ra,56(sp)
    80003fa4:	f822                	sd	s0,48(sp)
    80003fa6:	f04a                	sd	s2,32(sp)
    80003fa8:	ec4e                	sd	s3,24(sp)
    80003faa:	e852                	sd	s4,16(sp)
    80003fac:	0080                	addi	s0,sp,64
    80003fae:	892a                	mv	s2,a0
    80003fb0:	8a2e                	mv	s4,a1
    80003fb2:	89b2                	mv	s3,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80003fb4:	4601                	li	a2,0
    80003fb6:	e0dff0ef          	jal	80003dc2 <dirlookup>
    80003fba:	e535                	bnez	a0,80004026 <dirlink+0x86>
    80003fbc:	f426                	sd	s1,40(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003fbe:	04c92483          	lw	s1,76(s2)
    80003fc2:	c48d                	beqz	s1,80003fec <dirlink+0x4c>
    80003fc4:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003fc6:	4741                	li	a4,16
    80003fc8:	86a6                	mv	a3,s1
    80003fca:	fc040613          	addi	a2,s0,-64
    80003fce:	4581                	li	a1,0
    80003fd0:	854a                	mv	a0,s2
    80003fd2:	bcbff0ef          	jal	80003b9c <readi>
    80003fd6:	47c1                	li	a5,16
    80003fd8:	04f51b63          	bne	a0,a5,8000402e <dirlink+0x8e>
    if (de.inum == 0)
    80003fdc:	fc045783          	lhu	a5,-64(s0)
    80003fe0:	c791                	beqz	a5,80003fec <dirlink+0x4c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80003fe2:	24c1                	addiw	s1,s1,16
    80003fe4:	04c92783          	lw	a5,76(s2)
    80003fe8:	fcf4efe3          	bltu	s1,a5,80003fc6 <dirlink+0x26>
  strncpy(de.name, name, DIRSIZ);
    80003fec:	4639                	li	a2,14
    80003fee:	85d2                	mv	a1,s4
    80003ff0:	fc240513          	addi	a0,s0,-62
    80003ff4:	d63fc0ef          	jal	80000d56 <strncpy>
  de.inum = inum;
    80003ff8:	fd341023          	sh	s3,-64(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003ffc:	4741                	li	a4,16
    80003ffe:	86a6                	mv	a3,s1
    80004000:	fc040613          	addi	a2,s0,-64
    80004004:	4581                	li	a1,0
    80004006:	854a                	mv	a0,s2
    80004008:	c91ff0ef          	jal	80003c98 <writei>
    8000400c:	1541                	addi	a0,a0,-16
    8000400e:	00a03533          	snez	a0,a0
    80004012:	40a00533          	neg	a0,a0
    80004016:	74a2                	ld	s1,40(sp)
}
    80004018:	70e2                	ld	ra,56(sp)
    8000401a:	7442                	ld	s0,48(sp)
    8000401c:	7902                	ld	s2,32(sp)
    8000401e:	69e2                	ld	s3,24(sp)
    80004020:	6a42                	ld	s4,16(sp)
    80004022:	6121                	addi	sp,sp,64
    80004024:	8082                	ret
    iput(ip);
    80004026:	921ff0ef          	jal	80003946 <iput>
    return -1;
    8000402a:	557d                	li	a0,-1
    8000402c:	b7f5                	j	80004018 <dirlink+0x78>
      panic("dirlink read");
    8000402e:	00004517          	auipc	a0,0x4
    80004032:	66a50513          	addi	a0,a0,1642 # 80008698 <etext+0x698>
    80004036:	fbafc0ef          	jal	800007f0 <panic>

000000008000403a <namei>:

struct inode *
namei(char *path)
{
    8000403a:	1101                	addi	sp,sp,-32
    8000403c:	ec06                	sd	ra,24(sp)
    8000403e:	e822                	sd	s0,16(sp)
    80004040:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80004042:	fe040613          	addi	a2,s0,-32
    80004046:	4581                	li	a1,0
    80004048:	e17ff0ef          	jal	80003e5e <namex>
}
    8000404c:	60e2                	ld	ra,24(sp)
    8000404e:	6442                	ld	s0,16(sp)
    80004050:	6105                	addi	sp,sp,32
    80004052:	8082                	ret

0000000080004054 <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80004054:	1141                	addi	sp,sp,-16
    80004056:	e406                	sd	ra,8(sp)
    80004058:	e022                	sd	s0,0(sp)
    8000405a:	0800                	addi	s0,sp,16
    8000405c:	862e                	mv	a2,a1
  return namex(path, 1, name);
    8000405e:	4585                	li	a1,1
    80004060:	dffff0ef          	jal	80003e5e <namex>
}
    80004064:	60a2                	ld	ra,8(sp)
    80004066:	6402                	ld	s0,0(sp)
    80004068:	0141                	addi	sp,sp,16
    8000406a:	8082                	ret

000000008000406c <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    8000406c:	1101                	addi	sp,sp,-32
    8000406e:	ec06                	sd	ra,24(sp)
    80004070:	e822                	sd	s0,16(sp)
    80004072:	e426                	sd	s1,8(sp)
    80004074:	e04a                	sd	s2,0(sp)
    80004076:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80004078:	0001f917          	auipc	s2,0x1f
    8000407c:	5c890913          	addi	s2,s2,1480 # 80023640 <log>
    80004080:	01892583          	lw	a1,24(s2)
    80004084:	02492503          	lw	a0,36(s2)
    80004088:	870ff0ef          	jal	800030f8 <bread>
    8000408c:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    8000408e:	02c92603          	lw	a2,44(s2)
    80004092:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80004094:	00c05f63          	blez	a2,800040b2 <write_head+0x46>
    80004098:	0001f717          	auipc	a4,0x1f
    8000409c:	5d870713          	addi	a4,a4,1496 # 80023670 <log+0x30>
    800040a0:	87aa                	mv	a5,a0
    800040a2:	060a                	slli	a2,a2,0x2
    800040a4:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    800040a6:	4314                	lw	a3,0(a4)
    800040a8:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    800040aa:	0711                	addi	a4,a4,4
    800040ac:	0791                	addi	a5,a5,4
    800040ae:	fec79ce3          	bne	a5,a2,800040a6 <write_head+0x3a>
  }
  bwrite(buf);
    800040b2:	8526                	mv	a0,s1
    800040b4:	91aff0ef          	jal	800031ce <bwrite>
  brelse(buf);
    800040b8:	8526                	mv	a0,s1
    800040ba:	946ff0ef          	jal	80003200 <brelse>
}
    800040be:	60e2                	ld	ra,24(sp)
    800040c0:	6442                	ld	s0,16(sp)
    800040c2:	64a2                	ld	s1,8(sp)
    800040c4:	6902                	ld	s2,0(sp)
    800040c6:	6105                	addi	sp,sp,32
    800040c8:	8082                	ret

00000000800040ca <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    800040ca:	0001f797          	auipc	a5,0x1f
    800040ce:	5a27a783          	lw	a5,1442(a5) # 8002366c <log+0x2c>
    800040d2:	0af05e63          	blez	a5,8000418e <install_trans+0xc4>
{
    800040d6:	715d                	addi	sp,sp,-80
    800040d8:	e486                	sd	ra,72(sp)
    800040da:	e0a2                	sd	s0,64(sp)
    800040dc:	fc26                	sd	s1,56(sp)
    800040de:	f84a                	sd	s2,48(sp)
    800040e0:	f44e                	sd	s3,40(sp)
    800040e2:	f052                	sd	s4,32(sp)
    800040e4:	ec56                	sd	s5,24(sp)
    800040e6:	e85a                	sd	s6,16(sp)
    800040e8:	e45e                	sd	s7,8(sp)
    800040ea:	0880                	addi	s0,sp,80
    800040ec:	8b2a                	mv	s6,a0
    800040ee:	0001fa97          	auipc	s5,0x1f
    800040f2:	582a8a93          	addi	s5,s5,1410 # 80023670 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    800040f6:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    800040f8:	00004b97          	auipc	s7,0x4
    800040fc:	5b0b8b93          	addi	s7,s7,1456 # 800086a8 <etext+0x6a8>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80004100:	0001fa17          	auipc	s4,0x1f
    80004104:	540a0a13          	addi	s4,s4,1344 # 80023640 <log>
    80004108:	a025                	j	80004130 <install_trans+0x66>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    8000410a:	000aa603          	lw	a2,0(s5)
    8000410e:	85ce                	mv	a1,s3
    80004110:	855e                	mv	a0,s7
    80004112:	bf8fc0ef          	jal	8000050a <printk>
    80004116:	a839                	j	80004134 <install_trans+0x6a>
    brelse(lbuf);
    80004118:	854a                	mv	a0,s2
    8000411a:	8e6ff0ef          	jal	80003200 <brelse>
    brelse(dbuf);
    8000411e:	8526                	mv	a0,s1
    80004120:	8e0ff0ef          	jal	80003200 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004124:	2985                	addiw	s3,s3,1
    80004126:	0a91                	addi	s5,s5,4
    80004128:	02ca2783          	lw	a5,44(s4)
    8000412c:	04f9d663          	bge	s3,a5,80004178 <install_trans+0xae>
    if (recovering) {
    80004130:	fc0b1de3          	bnez	s6,8000410a <install_trans+0x40>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    80004134:	018a2583          	lw	a1,24(s4)
    80004138:	013585bb          	addw	a1,a1,s3
    8000413c:	2585                	addiw	a1,a1,1
    8000413e:	024a2503          	lw	a0,36(s4)
    80004142:	fb7fe0ef          	jal	800030f8 <bread>
    80004146:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80004148:	000aa583          	lw	a1,0(s5)
    8000414c:	024a2503          	lw	a0,36(s4)
    80004150:	fa9fe0ef          	jal	800030f8 <bread>
    80004154:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80004156:	40000613          	li	a2,1024
    8000415a:	05890593          	addi	a1,s2,88
    8000415e:	05850513          	addi	a0,a0,88
    80004162:	b4ffc0ef          	jal	80000cb0 <memmove>
    bwrite(dbuf);                           // write dst to disk
    80004166:	8526                	mv	a0,s1
    80004168:	866ff0ef          	jal	800031ce <bwrite>
    if (recovering == 0)
    8000416c:	fa0b16e3          	bnez	s6,80004118 <install_trans+0x4e>
      bunpin(dbuf);
    80004170:	8526                	mv	a0,s1
    80004172:	94aff0ef          	jal	800032bc <bunpin>
    80004176:	b74d                	j	80004118 <install_trans+0x4e>
}
    80004178:	60a6                	ld	ra,72(sp)
    8000417a:	6406                	ld	s0,64(sp)
    8000417c:	74e2                	ld	s1,56(sp)
    8000417e:	7942                	ld	s2,48(sp)
    80004180:	79a2                	ld	s3,40(sp)
    80004182:	7a02                	ld	s4,32(sp)
    80004184:	6ae2                	ld	s5,24(sp)
    80004186:	6b42                	ld	s6,16(sp)
    80004188:	6ba2                	ld	s7,8(sp)
    8000418a:	6161                	addi	sp,sp,80
    8000418c:	8082                	ret
    8000418e:	8082                	ret

0000000080004190 <initlog>:
{
    80004190:	7179                	addi	sp,sp,-48
    80004192:	f406                	sd	ra,40(sp)
    80004194:	f022                	sd	s0,32(sp)
    80004196:	ec26                	sd	s1,24(sp)
    80004198:	e84a                	sd	s2,16(sp)
    8000419a:	e44e                	sd	s3,8(sp)
    8000419c:	1800                	addi	s0,sp,48
    8000419e:	892a                	mv	s2,a0
    800041a0:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    800041a2:	0001f497          	auipc	s1,0x1f
    800041a6:	49e48493          	addi	s1,s1,1182 # 80023640 <log>
    800041aa:	00004597          	auipc	a1,0x4
    800041ae:	51e58593          	addi	a1,a1,1310 # 800086c8 <etext+0x6c8>
    800041b2:	8526                	mv	a0,s1
    800041b4:	967fc0ef          	jal	80000b1a <initlock>
  log.start = sb->logstart;
    800041b8:	0149a583          	lw	a1,20(s3)
    800041bc:	cc8c                	sw	a1,24(s1)
  log.dev = dev;
    800041be:	0324a223          	sw	s2,36(s1)
  struct buf *buf = bread(log.dev, log.start);
    800041c2:	854a                	mv	a0,s2
    800041c4:	f35fe0ef          	jal	800030f8 <bread>
  log.lh.n = lh->n;
    800041c8:	4d30                	lw	a2,88(a0)
    800041ca:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    800041cc:	00c05f63          	blez	a2,800041ea <initlog+0x5a>
    800041d0:	87aa                	mv	a5,a0
    800041d2:	0001f717          	auipc	a4,0x1f
    800041d6:	49e70713          	addi	a4,a4,1182 # 80023670 <log+0x30>
    800041da:	060a                	slli	a2,a2,0x2
    800041dc:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    800041de:	4ff4                	lw	a3,92(a5)
    800041e0:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    800041e2:	0791                	addi	a5,a5,4
    800041e4:	0711                	addi	a4,a4,4
    800041e6:	fec79ce3          	bne	a5,a2,800041de <initlog+0x4e>
  brelse(buf);
    800041ea:	816ff0ef          	jal	80003200 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800041ee:	4505                	li	a0,1
    800041f0:	edbff0ef          	jal	800040ca <install_trans>
  log.lh.n = 0;
    800041f4:	0001f797          	auipc	a5,0x1f
    800041f8:	4607ac23          	sw	zero,1144(a5) # 8002366c <log+0x2c>
  write_head(); // clear the log
    800041fc:	e71ff0ef          	jal	8000406c <write_head>
}
    80004200:	70a2                	ld	ra,40(sp)
    80004202:	7402                	ld	s0,32(sp)
    80004204:	64e2                	ld	s1,24(sp)
    80004206:	6942                	ld	s2,16(sp)
    80004208:	69a2                	ld	s3,8(sp)
    8000420a:	6145                	addi	sp,sp,48
    8000420c:	8082                	ret

000000008000420e <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    8000420e:	1101                	addi	sp,sp,-32
    80004210:	ec06                	sd	ra,24(sp)
    80004212:	e822                	sd	s0,16(sp)
    80004214:	e426                	sd	s1,8(sp)
    80004216:	e04a                	sd	s2,0(sp)
    80004218:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    8000421a:	0001f517          	auipc	a0,0x1f
    8000421e:	42650513          	addi	a0,a0,1062 # 80023640 <log>
    80004222:	96ffc0ef          	jal	80000b90 <acquire>
  while (1) {
    if (log.committing) {
    80004226:	0001f497          	auipc	s1,0x1f
    8000422a:	41a48493          	addi	s1,s1,1050 # 80023640 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    8000422e:	4979                	li	s2,30
    80004230:	a821                	j	80004248 <begin_op+0x3a>
      sleep_prepare(&log);
    80004232:	8526                	mv	a0,s1
    80004234:	c73fd0ef          	jal	80001ea6 <sleep_prepare>
      release(&log.lock);
    80004238:	8526                	mv	a0,s1
    8000423a:	9e3fc0ef          	jal	80000c1c <release>
      sleep();
    8000423e:	ca5fd0ef          	jal	80001ee2 <sleep>
      acquire(&log.lock);
    80004242:	8526                	mv	a0,s1
    80004244:	94dfc0ef          	jal	80000b90 <acquire>
    if (log.committing) {
    80004248:	509c                	lw	a5,32(s1)
    8000424a:	f7e5                	bnez	a5,80004232 <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    8000424c:	4cd8                	lw	a4,28(s1)
    8000424e:	2705                	addiw	a4,a4,1
    80004250:	0027179b          	slliw	a5,a4,0x2
    80004254:	9fb9                	addw	a5,a5,a4
    80004256:	0017979b          	slliw	a5,a5,0x1
    8000425a:	54d4                	lw	a3,44(s1)
    8000425c:	9fb5                	addw	a5,a5,a3
    8000425e:	00f95e63          	bge	s2,a5,8000427a <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80004262:	8526                	mv	a0,s1
    80004264:	c43fd0ef          	jal	80001ea6 <sleep_prepare>
      release(&log.lock);
    80004268:	8526                	mv	a0,s1
    8000426a:	9b3fc0ef          	jal	80000c1c <release>
      sleep();
    8000426e:	c75fd0ef          	jal	80001ee2 <sleep>
      acquire(&log.lock);
    80004272:	8526                	mv	a0,s1
    80004274:	91dfc0ef          	jal	80000b90 <acquire>
    80004278:	bfc1                	j	80004248 <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    8000427a:	0001f517          	auipc	a0,0x1f
    8000427e:	3c650513          	addi	a0,a0,966 # 80023640 <log>
    80004282:	cd58                	sw	a4,28(a0)
      release(&log.lock);
    80004284:	999fc0ef          	jal	80000c1c <release>
      break;
    }
  }
}
    80004288:	60e2                	ld	ra,24(sp)
    8000428a:	6442                	ld	s0,16(sp)
    8000428c:	64a2                	ld	s1,8(sp)
    8000428e:	6902                	ld	s2,0(sp)
    80004290:	6105                	addi	sp,sp,32
    80004292:	8082                	ret

0000000080004294 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80004294:	7139                	addi	sp,sp,-64
    80004296:	fc06                	sd	ra,56(sp)
    80004298:	f822                	sd	s0,48(sp)
    8000429a:	f426                	sd	s1,40(sp)
    8000429c:	f04a                	sd	s2,32(sp)
    8000429e:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    800042a0:	0001f497          	auipc	s1,0x1f
    800042a4:	3a048493          	addi	s1,s1,928 # 80023640 <log>
    800042a8:	8526                	mv	a0,s1
    800042aa:	8e7fc0ef          	jal	80000b90 <acquire>
  log.outstanding -= 1;
    800042ae:	4cdc                	lw	a5,28(s1)
    800042b0:	37fd                	addiw	a5,a5,-1
    800042b2:	0007891b          	sext.w	s2,a5
    800042b6:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    800042b8:	509c                	lw	a5,32(s1)
    800042ba:	e3b1                	bnez	a5,800042fe <end_op+0x6a>
    panic("log.committing");
  if (log.outstanding == 0) {
    800042bc:	04091a63          	bnez	s2,80004310 <end_op+0x7c>
    do_commit = 1;
    log.committing = 1;
    800042c0:	0001f497          	auipc	s1,0x1f
    800042c4:	38048493          	addi	s1,s1,896 # 80023640 <log>
    800042c8:	4785                	li	a5,1
    800042ca:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800042cc:	8526                	mv	a0,s1
    800042ce:	94ffc0ef          	jal	80000c1c <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800042d2:	54dc                	lw	a5,44(s1)
    800042d4:	04f04e63          	bgtz	a5,80004330 <end_op+0x9c>
    acquire(&log.lock);
    800042d8:	0001f497          	auipc	s1,0x1f
    800042dc:	36848493          	addi	s1,s1,872 # 80023640 <log>
    800042e0:	8526                	mv	a0,s1
    800042e2:	8affc0ef          	jal	80000b90 <acquire>
    log.committing = 0;
    800042e6:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    800042ea:	549c                	lw	a5,40(s1)
    800042ec:	2785                	addiw	a5,a5,1
    800042ee:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    800042f0:	8526                	mv	a0,s1
    800042f2:	c21fd0ef          	jal	80001f12 <wakeup>
    release(&log.lock);
    800042f6:	8526                	mv	a0,s1
    800042f8:	925fc0ef          	jal	80000c1c <release>
}
    800042fc:	a025                	j	80004324 <end_op+0x90>
    800042fe:	ec4e                	sd	s3,24(sp)
    80004300:	e852                	sd	s4,16(sp)
    80004302:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80004304:	00004517          	auipc	a0,0x4
    80004308:	3cc50513          	addi	a0,a0,972 # 800086d0 <etext+0x6d0>
    8000430c:	ce4fc0ef          	jal	800007f0 <panic>
    wakeup(&log);
    80004310:	0001f497          	auipc	s1,0x1f
    80004314:	33048493          	addi	s1,s1,816 # 80023640 <log>
    80004318:	8526                	mv	a0,s1
    8000431a:	bf9fd0ef          	jal	80001f12 <wakeup>
  release(&log.lock);
    8000431e:	8526                	mv	a0,s1
    80004320:	8fdfc0ef          	jal	80000c1c <release>
}
    80004324:	70e2                	ld	ra,56(sp)
    80004326:	7442                	ld	s0,48(sp)
    80004328:	74a2                	ld	s1,40(sp)
    8000432a:	7902                	ld	s2,32(sp)
    8000432c:	6121                	addi	sp,sp,64
    8000432e:	8082                	ret
    80004330:	ec4e                	sd	s3,24(sp)
    80004332:	e852                	sd	s4,16(sp)
    80004334:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80004336:	0001fa97          	auipc	s5,0x1f
    8000433a:	33aa8a93          	addi	s5,s5,826 # 80023670 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    8000433e:	0001fa17          	auipc	s4,0x1f
    80004342:	302a0a13          	addi	s4,s4,770 # 80023640 <log>
    80004346:	018a2583          	lw	a1,24(s4)
    8000434a:	012585bb          	addw	a1,a1,s2
    8000434e:	2585                	addiw	a1,a1,1
    80004350:	024a2503          	lw	a0,36(s4)
    80004354:	da5fe0ef          	jal	800030f8 <bread>
    80004358:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    8000435a:	000aa583          	lw	a1,0(s5)
    8000435e:	024a2503          	lw	a0,36(s4)
    80004362:	d97fe0ef          	jal	800030f8 <bread>
    80004366:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80004368:	40000613          	li	a2,1024
    8000436c:	05850593          	addi	a1,a0,88
    80004370:	05848513          	addi	a0,s1,88
    80004374:	93dfc0ef          	jal	80000cb0 <memmove>
    bwrite(to); // write the log
    80004378:	8526                	mv	a0,s1
    8000437a:	e55fe0ef          	jal	800031ce <bwrite>
    brelse(from);
    8000437e:	854e                	mv	a0,s3
    80004380:	e81fe0ef          	jal	80003200 <brelse>
    brelse(to);
    80004384:	8526                	mv	a0,s1
    80004386:	e7bfe0ef          	jal	80003200 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    8000438a:	2905                	addiw	s2,s2,1
    8000438c:	0a91                	addi	s5,s5,4
    8000438e:	02ca2783          	lw	a5,44(s4)
    80004392:	faf94ae3          	blt	s2,a5,80004346 <end_op+0xb2>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    80004396:	cd7ff0ef          	jal	8000406c <write_head>
    install_trans(0); // Now install writes to home locations
    8000439a:	4501                	li	a0,0
    8000439c:	d2fff0ef          	jal	800040ca <install_trans>
    log.lh.n = 0;
    800043a0:	0001f797          	auipc	a5,0x1f
    800043a4:	2c07a623          	sw	zero,716(a5) # 8002366c <log+0x2c>
    write_head(); // Erase the transaction from the log
    800043a8:	cc5ff0ef          	jal	8000406c <write_head>
    800043ac:	69e2                	ld	s3,24(sp)
    800043ae:	6a42                	ld	s4,16(sp)
    800043b0:	6aa2                	ld	s5,8(sp)
    800043b2:	b71d                	j	800042d8 <end_op+0x44>

00000000800043b4 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    800043b4:	1101                	addi	sp,sp,-32
    800043b6:	ec06                	sd	ra,24(sp)
    800043b8:	e822                	sd	s0,16(sp)
    800043ba:	e426                	sd	s1,8(sp)
    800043bc:	e04a                	sd	s2,0(sp)
    800043be:	1000                	addi	s0,sp,32
    800043c0:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800043c2:	0001f917          	auipc	s2,0x1f
    800043c6:	27e90913          	addi	s2,s2,638 # 80023640 <log>
    800043ca:	854a                	mv	a0,s2
    800043cc:	fc4fc0ef          	jal	80000b90 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    800043d0:	02c92603          	lw	a2,44(s2)
    800043d4:	47f5                	li	a5,29
    800043d6:	04c7cc63          	blt	a5,a2,8000442e <log_write+0x7a>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800043da:	0001f797          	auipc	a5,0x1f
    800043de:	2827a783          	lw	a5,642(a5) # 8002365c <log+0x1c>
    800043e2:	04f05c63          	blez	a5,8000443a <log_write+0x86>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800043e6:	4781                	li	a5,0
    800043e8:	04c05f63          	blez	a2,80004446 <log_write+0x92>
    if (log.lh.block[i] == b->blockno) // log absorption
    800043ec:	44cc                	lw	a1,12(s1)
    800043ee:	0001f717          	auipc	a4,0x1f
    800043f2:	28270713          	addi	a4,a4,642 # 80023670 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800043f6:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    800043f8:	4314                	lw	a3,0(a4)
    800043fa:	04b68663          	beq	a3,a1,80004446 <log_write+0x92>
  for (i = 0; i < log.lh.n; i++) {
    800043fe:	2785                	addiw	a5,a5,1
    80004400:	0711                	addi	a4,a4,4
    80004402:	fef61be3          	bne	a2,a5,800043f8 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80004406:	0621                	addi	a2,a2,8
    80004408:	060a                	slli	a2,a2,0x2
    8000440a:	0001f797          	auipc	a5,0x1f
    8000440e:	23678793          	addi	a5,a5,566 # 80023640 <log>
    80004412:	97b2                	add	a5,a5,a2
    80004414:	44d8                	lw	a4,12(s1)
    80004416:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    80004418:	8526                	mv	a0,s1
    8000441a:	e6ffe0ef          	jal	80003288 <bpin>
    log.lh.n++;
    8000441e:	0001f717          	auipc	a4,0x1f
    80004422:	22270713          	addi	a4,a4,546 # 80023640 <log>
    80004426:	575c                	lw	a5,44(a4)
    80004428:	2785                	addiw	a5,a5,1
    8000442a:	d75c                	sw	a5,44(a4)
    8000442c:	a80d                	j	8000445e <log_write+0xaa>
    panic("too big a transaction");
    8000442e:	00004517          	auipc	a0,0x4
    80004432:	2b250513          	addi	a0,a0,690 # 800086e0 <etext+0x6e0>
    80004436:	bbafc0ef          	jal	800007f0 <panic>
    panic("log_write outside of trans");
    8000443a:	00004517          	auipc	a0,0x4
    8000443e:	2be50513          	addi	a0,a0,702 # 800086f8 <etext+0x6f8>
    80004442:	baefc0ef          	jal	800007f0 <panic>
  log.lh.block[i] = b->blockno;
    80004446:	00878693          	addi	a3,a5,8
    8000444a:	068a                	slli	a3,a3,0x2
    8000444c:	0001f717          	auipc	a4,0x1f
    80004450:	1f470713          	addi	a4,a4,500 # 80023640 <log>
    80004454:	9736                	add	a4,a4,a3
    80004456:	44d4                	lw	a3,12(s1)
    80004458:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    8000445a:	faf60fe3          	beq	a2,a5,80004418 <log_write+0x64>
  }
  release(&log.lock);
    8000445e:	0001f517          	auipc	a0,0x1f
    80004462:	1e250513          	addi	a0,a0,482 # 80023640 <log>
    80004466:	fb6fc0ef          	jal	80000c1c <release>
}
    8000446a:	60e2                	ld	ra,24(sp)
    8000446c:	6442                	ld	s0,16(sp)
    8000446e:	64a2                	ld	s1,8(sp)
    80004470:	6902                	ld	s2,0(sp)
    80004472:	6105                	addi	sp,sp,32
    80004474:	8082                	ret

0000000080004476 <sys_sync>:

uint64
sys_sync(void)
{
    80004476:	1101                	addi	sp,sp,-32
    80004478:	ec06                	sd	ra,24(sp)
    8000447a:	e822                	sd	s0,16(sp)
    8000447c:	e426                	sd	s1,8(sp)
    8000447e:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80004480:	0001f497          	auipc	s1,0x1f
    80004484:	1c048493          	addi	s1,s1,448 # 80023640 <log>
    80004488:	8526                	mv	a0,s1
    8000448a:	f06fc0ef          	jal	80000b90 <acquire>
  if (log.committing || log.outstanding > 0) {
    8000448e:	509c                	lw	a5,32(s1)
    80004490:	e799                	bnez	a5,8000449e <sys_sync+0x28>
    80004492:	0001f797          	auipc	a5,0x1f
    80004496:	1ca7a783          	lw	a5,458(a5) # 8002365c <log+0x1c>
    8000449a:	02f05a63          	blez	a5,800044ce <sys_sync+0x58>
    8000449e:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    800044a0:	0001f917          	auipc	s2,0x1f
    800044a4:	1c892903          	lw	s2,456(s2) # 80023668 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    800044a8:	0001f497          	auipc	s1,0x1f
    800044ac:	19848493          	addi	s1,s1,408 # 80023640 <log>
    800044b0:	8526                	mv	a0,s1
    800044b2:	9f5fd0ef          	jal	80001ea6 <sleep_prepare>
      release(&log.lock);
    800044b6:	8526                	mv	a0,s1
    800044b8:	f64fc0ef          	jal	80000c1c <release>
      sleep();
    800044bc:	a27fd0ef          	jal	80001ee2 <sleep>
      acquire(&log.lock);
    800044c0:	8526                	mv	a0,s1
    800044c2:	ecefc0ef          	jal	80000b90 <acquire>
    while (log.ncommit < n) {
    800044c6:	549c                	lw	a5,40(s1)
    800044c8:	fef954e3          	bge	s2,a5,800044b0 <sys_sync+0x3a>
    800044cc:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    800044ce:	0001f517          	auipc	a0,0x1f
    800044d2:	17250513          	addi	a0,a0,370 # 80023640 <log>
    800044d6:	f46fc0ef          	jal	80000c1c <release>
  return 0;
}
    800044da:	4501                	li	a0,0
    800044dc:	60e2                	ld	ra,24(sp)
    800044de:	6442                	ld	s0,16(sp)
    800044e0:	64a2                	ld	s1,8(sp)
    800044e2:	6105                	addi	sp,sp,32
    800044e4:	8082                	ret

00000000800044e6 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800044e6:	1101                	addi	sp,sp,-32
    800044e8:	ec06                	sd	ra,24(sp)
    800044ea:	e822                	sd	s0,16(sp)
    800044ec:	e426                	sd	s1,8(sp)
    800044ee:	e04a                	sd	s2,0(sp)
    800044f0:	1000                	addi	s0,sp,32
    800044f2:	84aa                	mv	s1,a0
    800044f4:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800044f6:	00004597          	auipc	a1,0x4
    800044fa:	22258593          	addi	a1,a1,546 # 80008718 <etext+0x718>
    800044fe:	0521                	addi	a0,a0,8
    80004500:	e1afc0ef          	jal	80000b1a <initlock>
  lk->name = name;
    80004504:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80004508:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000450c:	0204a423          	sw	zero,40(s1)
}
    80004510:	60e2                	ld	ra,24(sp)
    80004512:	6442                	ld	s0,16(sp)
    80004514:	64a2                	ld	s1,8(sp)
    80004516:	6902                	ld	s2,0(sp)
    80004518:	6105                	addi	sp,sp,32
    8000451a:	8082                	ret

000000008000451c <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    8000451c:	1101                	addi	sp,sp,-32
    8000451e:	ec06                	sd	ra,24(sp)
    80004520:	e822                	sd	s0,16(sp)
    80004522:	e426                	sd	s1,8(sp)
    80004524:	e04a                	sd	s2,0(sp)
    80004526:	1000                	addi	s0,sp,32
    80004528:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000452a:	00850913          	addi	s2,a0,8
    8000452e:	854a                	mv	a0,s2
    80004530:	e60fc0ef          	jal	80000b90 <acquire>
  while (lk->locked) {
    80004534:	409c                	lw	a5,0(s1)
    80004536:	cf91                	beqz	a5,80004552 <acquiresleep+0x36>
    sleep_prepare(lk);
    80004538:	8526                	mv	a0,s1
    8000453a:	96dfd0ef          	jal	80001ea6 <sleep_prepare>
    release(&lk->lk);
    8000453e:	854a                	mv	a0,s2
    80004540:	edcfc0ef          	jal	80000c1c <release>
    sleep();
    80004544:	99ffd0ef          	jal	80001ee2 <sleep>
    acquire(&lk->lk);
    80004548:	854a                	mv	a0,s2
    8000454a:	e46fc0ef          	jal	80000b90 <acquire>
  while (lk->locked) {
    8000454e:	409c                	lw	a5,0(s1)
    80004550:	f7e5                	bnez	a5,80004538 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80004552:	4785                	li	a5,1
    80004554:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004556:	b4cfd0ef          	jal	800018a2 <myproc>
    8000455a:	591c                	lw	a5,48(a0)
    8000455c:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    8000455e:	854a                	mv	a0,s2
    80004560:	ebcfc0ef          	jal	80000c1c <release>
}
    80004564:	60e2                	ld	ra,24(sp)
    80004566:	6442                	ld	s0,16(sp)
    80004568:	64a2                	ld	s1,8(sp)
    8000456a:	6902                	ld	s2,0(sp)
    8000456c:	6105                	addi	sp,sp,32
    8000456e:	8082                	ret

0000000080004570 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80004570:	1101                	addi	sp,sp,-32
    80004572:	ec06                	sd	ra,24(sp)
    80004574:	e822                	sd	s0,16(sp)
    80004576:	e426                	sd	s1,8(sp)
    80004578:	e04a                	sd	s2,0(sp)
    8000457a:	1000                	addi	s0,sp,32
    8000457c:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000457e:	00850913          	addi	s2,a0,8
    80004582:	854a                	mv	a0,s2
    80004584:	e0cfc0ef          	jal	80000b90 <acquire>
  lk->locked = 0;
    80004588:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000458c:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80004590:	8526                	mv	a0,s1
    80004592:	981fd0ef          	jal	80001f12 <wakeup>
  release(&lk->lk);
    80004596:	854a                	mv	a0,s2
    80004598:	e84fc0ef          	jal	80000c1c <release>
}
    8000459c:	60e2                	ld	ra,24(sp)
    8000459e:	6442                	ld	s0,16(sp)
    800045a0:	64a2                	ld	s1,8(sp)
    800045a2:	6902                	ld	s2,0(sp)
    800045a4:	6105                	addi	sp,sp,32
    800045a6:	8082                	ret

00000000800045a8 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    800045a8:	7179                	addi	sp,sp,-48
    800045aa:	f406                	sd	ra,40(sp)
    800045ac:	f022                	sd	s0,32(sp)
    800045ae:	ec26                	sd	s1,24(sp)
    800045b0:	e84a                	sd	s2,16(sp)
    800045b2:	1800                	addi	s0,sp,48
    800045b4:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    800045b6:	00850913          	addi	s2,a0,8
    800045ba:	854a                	mv	a0,s2
    800045bc:	dd4fc0ef          	jal	80000b90 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800045c0:	409c                	lw	a5,0(s1)
    800045c2:	ef81                	bnez	a5,800045da <holdingsleep+0x32>
    800045c4:	4481                	li	s1,0
  release(&lk->lk);
    800045c6:	854a                	mv	a0,s2
    800045c8:	e54fc0ef          	jal	80000c1c <release>
  return r;
}
    800045cc:	8526                	mv	a0,s1
    800045ce:	70a2                	ld	ra,40(sp)
    800045d0:	7402                	ld	s0,32(sp)
    800045d2:	64e2                	ld	s1,24(sp)
    800045d4:	6942                	ld	s2,16(sp)
    800045d6:	6145                	addi	sp,sp,48
    800045d8:	8082                	ret
    800045da:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800045dc:	0284a983          	lw	s3,40(s1)
    800045e0:	ac2fd0ef          	jal	800018a2 <myproc>
    800045e4:	5904                	lw	s1,48(a0)
    800045e6:	413484b3          	sub	s1,s1,s3
    800045ea:	0014b493          	seqz	s1,s1
    800045ee:	69a2                	ld	s3,8(sp)
    800045f0:	bfd9                	j	800045c6 <holdingsleep+0x1e>

00000000800045f2 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800045f2:	1141                	addi	sp,sp,-16
    800045f4:	e406                	sd	ra,8(sp)
    800045f6:	e022                	sd	s0,0(sp)
    800045f8:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800045fa:	00004597          	auipc	a1,0x4
    800045fe:	12e58593          	addi	a1,a1,302 # 80008728 <etext+0x728>
    80004602:	0001f517          	auipc	a0,0x1f
    80004606:	18650513          	addi	a0,a0,390 # 80023788 <ftable>
    8000460a:	d10fc0ef          	jal	80000b1a <initlock>
}
    8000460e:	60a2                	ld	ra,8(sp)
    80004610:	6402                	ld	s0,0(sp)
    80004612:	0141                	addi	sp,sp,16
    80004614:	8082                	ret

0000000080004616 <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    80004616:	1101                	addi	sp,sp,-32
    80004618:	ec06                	sd	ra,24(sp)
    8000461a:	e822                	sd	s0,16(sp)
    8000461c:	e426                	sd	s1,8(sp)
    8000461e:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80004620:	0001f517          	auipc	a0,0x1f
    80004624:	16850513          	addi	a0,a0,360 # 80023788 <ftable>
    80004628:	d68fc0ef          	jal	80000b90 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    8000462c:	0001f497          	auipc	s1,0x1f
    80004630:	17448493          	addi	s1,s1,372 # 800237a0 <ftable+0x18>
    80004634:	00020717          	auipc	a4,0x20
    80004638:	10c70713          	addi	a4,a4,268 # 80024740 <disk>
    if (f->ref == 0) {
    8000463c:	40dc                	lw	a5,4(s1)
    8000463e:	cf89                	beqz	a5,80004658 <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    80004640:	02848493          	addi	s1,s1,40
    80004644:	fee49ce3          	bne	s1,a4,8000463c <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004648:	0001f517          	auipc	a0,0x1f
    8000464c:	14050513          	addi	a0,a0,320 # 80023788 <ftable>
    80004650:	dccfc0ef          	jal	80000c1c <release>
  return 0;
    80004654:	4481                	li	s1,0
    80004656:	a809                	j	80004668 <filealloc+0x52>
      f->ref = 1;
    80004658:	4785                	li	a5,1
    8000465a:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    8000465c:	0001f517          	auipc	a0,0x1f
    80004660:	12c50513          	addi	a0,a0,300 # 80023788 <ftable>
    80004664:	db8fc0ef          	jal	80000c1c <release>
}
    80004668:	8526                	mv	a0,s1
    8000466a:	60e2                	ld	ra,24(sp)
    8000466c:	6442                	ld	s0,16(sp)
    8000466e:	64a2                	ld	s1,8(sp)
    80004670:	6105                	addi	sp,sp,32
    80004672:	8082                	ret

0000000080004674 <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    80004674:	1101                	addi	sp,sp,-32
    80004676:	ec06                	sd	ra,24(sp)
    80004678:	e822                	sd	s0,16(sp)
    8000467a:	e426                	sd	s1,8(sp)
    8000467c:	1000                	addi	s0,sp,32
    8000467e:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004680:	0001f517          	auipc	a0,0x1f
    80004684:	10850513          	addi	a0,a0,264 # 80023788 <ftable>
    80004688:	d08fc0ef          	jal	80000b90 <acquire>
  if (f->ref < 1)
    8000468c:	40dc                	lw	a5,4(s1)
    8000468e:	02f05063          	blez	a5,800046ae <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004692:	2785                	addiw	a5,a5,1
    80004694:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004696:	0001f517          	auipc	a0,0x1f
    8000469a:	0f250513          	addi	a0,a0,242 # 80023788 <ftable>
    8000469e:	d7efc0ef          	jal	80000c1c <release>
  return f;
}
    800046a2:	8526                	mv	a0,s1
    800046a4:	60e2                	ld	ra,24(sp)
    800046a6:	6442                	ld	s0,16(sp)
    800046a8:	64a2                	ld	s1,8(sp)
    800046aa:	6105                	addi	sp,sp,32
    800046ac:	8082                	ret
    panic("filedup");
    800046ae:	00004517          	auipc	a0,0x4
    800046b2:	08250513          	addi	a0,a0,130 # 80008730 <etext+0x730>
    800046b6:	93afc0ef          	jal	800007f0 <panic>

00000000800046ba <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800046ba:	7139                	addi	sp,sp,-64
    800046bc:	fc06                	sd	ra,56(sp)
    800046be:	f822                	sd	s0,48(sp)
    800046c0:	f426                	sd	s1,40(sp)
    800046c2:	0080                	addi	s0,sp,64
    800046c4:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800046c6:	0001f517          	auipc	a0,0x1f
    800046ca:	0c250513          	addi	a0,a0,194 # 80023788 <ftable>
    800046ce:	cc2fc0ef          	jal	80000b90 <acquire>
  if (f->ref < 1)
    800046d2:	40dc                	lw	a5,4(s1)
    800046d4:	04f05a63          	blez	a5,80004728 <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    800046d8:	37fd                	addiw	a5,a5,-1
    800046da:	0007871b          	sext.w	a4,a5
    800046de:	c0dc                	sw	a5,4(s1)
    800046e0:	04e04e63          	bgtz	a4,8000473c <fileclose+0x82>
    800046e4:	f04a                	sd	s2,32(sp)
    800046e6:	ec4e                	sd	s3,24(sp)
    800046e8:	e852                	sd	s4,16(sp)
    800046ea:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800046ec:	0004a903          	lw	s2,0(s1)
    800046f0:	0094ca83          	lbu	s5,9(s1)
    800046f4:	0104ba03          	ld	s4,16(s1)
    800046f8:	0184b983          	ld	s3,24(s1)
  f->ref = 0;
    800046fc:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004700:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004704:	0001f517          	auipc	a0,0x1f
    80004708:	08450513          	addi	a0,a0,132 # 80023788 <ftable>
    8000470c:	d10fc0ef          	jal	80000c1c <release>

  if (ff.type == FD_PIPE) {
    80004710:	4785                	li	a5,1
    80004712:	04f90063          	beq	s2,a5,80004752 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    80004716:	3979                	addiw	s2,s2,-2
    80004718:	4785                	li	a5,1
    8000471a:	0527f563          	bgeu	a5,s2,80004764 <fileclose+0xaa>
    8000471e:	7902                	ld	s2,32(sp)
    80004720:	69e2                	ld	s3,24(sp)
    80004722:	6a42                	ld	s4,16(sp)
    80004724:	6aa2                	ld	s5,8(sp)
    80004726:	a00d                	j	80004748 <fileclose+0x8e>
    80004728:	f04a                	sd	s2,32(sp)
    8000472a:	ec4e                	sd	s3,24(sp)
    8000472c:	e852                	sd	s4,16(sp)
    8000472e:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004730:	00004517          	auipc	a0,0x4
    80004734:	00850513          	addi	a0,a0,8 # 80008738 <etext+0x738>
    80004738:	8b8fc0ef          	jal	800007f0 <panic>
    release(&ftable.lock);
    8000473c:	0001f517          	auipc	a0,0x1f
    80004740:	04c50513          	addi	a0,a0,76 # 80023788 <ftable>
    80004744:	cd8fc0ef          	jal	80000c1c <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80004748:	70e2                	ld	ra,56(sp)
    8000474a:	7442                	ld	s0,48(sp)
    8000474c:	74a2                	ld	s1,40(sp)
    8000474e:	6121                	addi	sp,sp,64
    80004750:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004752:	85d6                	mv	a1,s5
    80004754:	8552                	mv	a0,s4
    80004756:	34c000ef          	jal	80004aa2 <pipeclose>
    8000475a:	7902                	ld	s2,32(sp)
    8000475c:	69e2                	ld	s3,24(sp)
    8000475e:	6a42                	ld	s4,16(sp)
    80004760:	6aa2                	ld	s5,8(sp)
    80004762:	b7dd                	j	80004748 <fileclose+0x8e>
    begin_op();
    80004764:	aabff0ef          	jal	8000420e <begin_op>
    iput(ff.ip);
    80004768:	854e                	mv	a0,s3
    8000476a:	9dcff0ef          	jal	80003946 <iput>
    end_op();
    8000476e:	b27ff0ef          	jal	80004294 <end_op>
    80004772:	7902                	ld	s2,32(sp)
    80004774:	69e2                	ld	s3,24(sp)
    80004776:	6a42                	ld	s4,16(sp)
    80004778:	6aa2                	ld	s5,8(sp)
    8000477a:	b7f9                	j	80004748 <fileclose+0x8e>

000000008000477c <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000477c:	715d                	addi	sp,sp,-80
    8000477e:	e486                	sd	ra,72(sp)
    80004780:	e0a2                	sd	s0,64(sp)
    80004782:	fc26                	sd	s1,56(sp)
    80004784:	f44e                	sd	s3,40(sp)
    80004786:	0880                	addi	s0,sp,80
    80004788:	84aa                	mv	s1,a0
    8000478a:	89ae                	mv	s3,a1
  struct proc *p = myproc();
    8000478c:	916fd0ef          	jal	800018a2 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80004790:	409c                	lw	a5,0(s1)
    80004792:	37f9                	addiw	a5,a5,-2
    80004794:	4705                	li	a4,1
    80004796:	04f76263          	bltu	a4,a5,800047da <filestat+0x5e>
    8000479a:	f84a                	sd	s2,48(sp)
    8000479c:	892a                	mv	s2,a0
    ilock(f->ip);
    8000479e:	6c88                	ld	a0,24(s1)
    800047a0:	824ff0ef          	jal	800037c4 <ilock>
    stati(f->ip, &st);
    800047a4:	fb840593          	addi	a1,s0,-72
    800047a8:	6c88                	ld	a0,24(s1)
    800047aa:	bc8ff0ef          	jal	80003b72 <stati>
    iunlock(f->ip);
    800047ae:	6c88                	ld	a0,24(s1)
    800047b0:	8c2ff0ef          	jal	80003872 <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    800047b4:	4761                	li	a4,24
    800047b6:	fb840693          	addi	a3,s0,-72
    800047ba:	864e                	mv	a2,s3
    800047bc:	04893583          	ld	a1,72(s2)
    800047c0:	05093503          	ld	a0,80(s2)
    800047c4:	d15fc0ef          	jal	800014d8 <copyout>
    800047c8:	41f5551b          	sraiw	a0,a0,0x1f
    800047cc:	7942                	ld	s2,48(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800047ce:	60a6                	ld	ra,72(sp)
    800047d0:	6406                	ld	s0,64(sp)
    800047d2:	74e2                	ld	s1,56(sp)
    800047d4:	79a2                	ld	s3,40(sp)
    800047d6:	6161                	addi	sp,sp,80
    800047d8:	8082                	ret
  return -1;
    800047da:	557d                	li	a0,-1
    800047dc:	bfcd                	j	800047ce <filestat+0x52>

00000000800047de <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800047de:	7179                	addi	sp,sp,-48
    800047e0:	f406                	sd	ra,40(sp)
    800047e2:	f022                	sd	s0,32(sp)
    800047e4:	e84a                	sd	s2,16(sp)
    800047e6:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0 || n < 0)
    800047e8:	00854783          	lbu	a5,8(a0)
    800047ec:	c3c5                	beqz	a5,8000488c <fileread+0xae>
    800047ee:	ec26                	sd	s1,24(sp)
    800047f0:	e44e                	sd	s3,8(sp)
    800047f2:	84aa                	mv	s1,a0
    800047f4:	89ae                	mv	s3,a1
    800047f6:	8932                	mv	s2,a2
    800047f8:	08064c63          	bltz	a2,80004890 <fileread+0xb2>
    return -1;

  if (f->type == FD_PIPE) {
    800047fc:	411c                	lw	a5,0(a0)
    800047fe:	4705                	li	a4,1
    80004800:	04e78363          	beq	a5,a4,80004846 <fileread+0x68>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004804:	470d                	li	a4,3
    80004806:	04e78763          	beq	a5,a4,80004854 <fileread+0x76>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    8000480a:	4709                	li	a4,2
    8000480c:	06e79a63          	bne	a5,a4,80004880 <fileread+0xa2>
    ilock(f->ip);
    80004810:	6d08                	ld	a0,24(a0)
    80004812:	fb3fe0ef          	jal	800037c4 <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004816:	874a                	mv	a4,s2
    80004818:	5094                	lw	a3,32(s1)
    8000481a:	864e                	mv	a2,s3
    8000481c:	4585                	li	a1,1
    8000481e:	6c88                	ld	a0,24(s1)
    80004820:	b7cff0ef          	jal	80003b9c <readi>
    80004824:	892a                	mv	s2,a0
    80004826:	00a05563          	blez	a0,80004830 <fileread+0x52>
      f->off += r;
    8000482a:	509c                	lw	a5,32(s1)
    8000482c:	9fa9                	addw	a5,a5,a0
    8000482e:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004830:	6c88                	ld	a0,24(s1)
    80004832:	840ff0ef          	jal	80003872 <iunlock>
    80004836:	64e2                	ld	s1,24(sp)
    80004838:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000483a:	854a                	mv	a0,s2
    8000483c:	70a2                	ld	ra,40(sp)
    8000483e:	7402                	ld	s0,32(sp)
    80004840:	6942                	ld	s2,16(sp)
    80004842:	6145                	addi	sp,sp,48
    80004844:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004846:	6908                	ld	a0,16(a0)
    80004848:	3b6000ef          	jal	80004bfe <piperead>
    8000484c:	892a                	mv	s2,a0
    8000484e:	64e2                	ld	s1,24(sp)
    80004850:	69a2                	ld	s3,8(sp)
    80004852:	b7e5                	j	8000483a <fileread+0x5c>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004854:	02451783          	lh	a5,36(a0)
    80004858:	03079693          	slli	a3,a5,0x30
    8000485c:	92c1                	srli	a3,a3,0x30
    8000485e:	4725                	li	a4,9
    80004860:	02d76c63          	bltu	a4,a3,80004898 <fileread+0xba>
    80004864:	0792                	slli	a5,a5,0x4
    80004866:	0001f717          	auipc	a4,0x1f
    8000486a:	e8270713          	addi	a4,a4,-382 # 800236e8 <devsw>
    8000486e:	97ba                	add	a5,a5,a4
    80004870:	639c                	ld	a5,0(a5)
    80004872:	c79d                	beqz	a5,800048a0 <fileread+0xc2>
    r = devsw[f->major].read(1, addr, n);
    80004874:	4505                	li	a0,1
    80004876:	9782                	jalr	a5
    80004878:	892a                	mv	s2,a0
    8000487a:	64e2                	ld	s1,24(sp)
    8000487c:	69a2                	ld	s3,8(sp)
    8000487e:	bf75                	j	8000483a <fileread+0x5c>
    panic("fileread");
    80004880:	00004517          	auipc	a0,0x4
    80004884:	ec850513          	addi	a0,a0,-312 # 80008748 <etext+0x748>
    80004888:	f69fb0ef          	jal	800007f0 <panic>
    return -1;
    8000488c:	597d                	li	s2,-1
    8000488e:	b775                	j	8000483a <fileread+0x5c>
    80004890:	597d                	li	s2,-1
    80004892:	64e2                	ld	s1,24(sp)
    80004894:	69a2                	ld	s3,8(sp)
    80004896:	b755                	j	8000483a <fileread+0x5c>
      return -1;
    80004898:	597d                	li	s2,-1
    8000489a:	64e2                	ld	s1,24(sp)
    8000489c:	69a2                	ld	s3,8(sp)
    8000489e:	bf71                	j	8000483a <fileread+0x5c>
    800048a0:	597d                	li	s2,-1
    800048a2:	64e2                	ld	s1,24(sp)
    800048a4:	69a2                	ld	s3,8(sp)
    800048a6:	bf51                	j	8000483a <fileread+0x5c>

00000000800048a8 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0 || n < 0)
    800048a8:	00954783          	lbu	a5,9(a0)
    800048ac:	10078663          	beqz	a5,800049b8 <filewrite+0x110>
{
    800048b0:	715d                	addi	sp,sp,-80
    800048b2:	e486                	sd	ra,72(sp)
    800048b4:	e0a2                	sd	s0,64(sp)
    800048b6:	f84a                	sd	s2,48(sp)
    800048b8:	f052                	sd	s4,32(sp)
    800048ba:	e85a                	sd	s6,16(sp)
    800048bc:	0880                	addi	s0,sp,80
    800048be:	892a                	mv	s2,a0
    800048c0:	8b2e                	mv	s6,a1
    800048c2:	8a32                	mv	s4,a2
  if (f->writable == 0 || n < 0)
    800048c4:	0e064c63          	bltz	a2,800049bc <filewrite+0x114>
    return -1;

  if (f->type == FD_PIPE) {
    800048c8:	411c                	lw	a5,0(a0)
    800048ca:	4705                	li	a4,1
    800048cc:	02e78763          	beq	a5,a4,800048fa <filewrite+0x52>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    800048d0:	470d                	li	a4,3
    800048d2:	02e78863          	beq	a5,a4,80004902 <filewrite+0x5a>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    800048d6:	4709                	li	a4,2
    800048d8:	0ce79563          	bne	a5,a4,800049a2 <filewrite+0xfa>
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    800048dc:	0ec05663          	blez	a2,800049c8 <filewrite+0x120>
    800048e0:	fc26                	sd	s1,56(sp)
    800048e2:	f44e                	sd	s3,40(sp)
    800048e4:	ec56                	sd	s5,24(sp)
    800048e6:	e45e                	sd	s7,8(sp)
    800048e8:	e062                	sd	s8,0(sp)
    int i = 0;
    800048ea:	4981                	li	s3,0
      int n1 = n - i;
      if (n1 > max)
    800048ec:	6b85                	lui	s7,0x1
    800048ee:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800048f2:	6c05                	lui	s8,0x1
    800048f4:	c00c0c1b          	addiw	s8,s8,-1024 # c00 <_entry-0x7ffff400>
    800048f8:	a8b5                	j	80004974 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800048fa:	6908                	ld	a0,16(a0)
    800048fc:	1fe000ef          	jal	80004afa <pipewrite>
    80004900:	a851                	j	80004994 <filewrite+0xec>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004902:	02451783          	lh	a5,36(a0)
    80004906:	03079693          	slli	a3,a5,0x30
    8000490a:	92c1                	srli	a3,a3,0x30
    8000490c:	4725                	li	a4,9
    8000490e:	0ad76963          	bltu	a4,a3,800049c0 <filewrite+0x118>
    80004912:	0792                	slli	a5,a5,0x4
    80004914:	0001f717          	auipc	a4,0x1f
    80004918:	dd470713          	addi	a4,a4,-556 # 800236e8 <devsw>
    8000491c:	97ba                	add	a5,a5,a4
    8000491e:	679c                	ld	a5,8(a5)
    80004920:	c3d5                	beqz	a5,800049c4 <filewrite+0x11c>
    ret = devsw[f->major].write(1, addr, n);
    80004922:	4505                	li	a0,1
    80004924:	9782                	jalr	a5
    80004926:	a0bd                	j	80004994 <filewrite+0xec>
      if (n1 > max)
    80004928:	00048a9b          	sext.w	s5,s1
        n1 = max;

      begin_op();
    8000492c:	8e3ff0ef          	jal	8000420e <begin_op>
      ilock(f->ip);
    80004930:	01893503          	ld	a0,24(s2)
    80004934:	e91fe0ef          	jal	800037c4 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004938:	8756                	mv	a4,s5
    8000493a:	02092683          	lw	a3,32(s2)
    8000493e:	01698633          	add	a2,s3,s6
    80004942:	4585                	li	a1,1
    80004944:	01893503          	ld	a0,24(s2)
    80004948:	b50ff0ef          	jal	80003c98 <writei>
    8000494c:	84aa                	mv	s1,a0
    8000494e:	00a05763          	blez	a0,8000495c <filewrite+0xb4>
        f->off += r;
    80004952:	02092783          	lw	a5,32(s2)
    80004956:	9fa9                	addw	a5,a5,a0
    80004958:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000495c:	01893503          	ld	a0,24(s2)
    80004960:	f13fe0ef          	jal	80003872 <iunlock>
      end_op();
    80004964:	931ff0ef          	jal	80004294 <end_op>

      if (r != n1) {
    80004968:	009a9e63          	bne	s5,s1,80004984 <filewrite+0xdc>
        // error from writei
        break;
      }
      i += r;
    8000496c:	013489bb          	addw	s3,s1,s3
    while (i < n) {
    80004970:	0149da63          	bge	s3,s4,80004984 <filewrite+0xdc>
      int n1 = n - i;
    80004974:	413a04bb          	subw	s1,s4,s3
      if (n1 > max)
    80004978:	0004879b          	sext.w	a5,s1
    8000497c:	fafbd6e3          	bge	s7,a5,80004928 <filewrite+0x80>
    80004980:	84e2                	mv	s1,s8
    80004982:	b75d                	j	80004928 <filewrite+0x80>
    }
    ret = (i == n ? n : -1);
    80004984:	053a1463          	bne	s4,s3,800049cc <filewrite+0x124>
    80004988:	8552                	mv	a0,s4
    8000498a:	74e2                	ld	s1,56(sp)
    8000498c:	79a2                	ld	s3,40(sp)
    8000498e:	6ae2                	ld	s5,24(sp)
    80004990:	6ba2                	ld	s7,8(sp)
    80004992:	6c02                	ld	s8,0(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004994:	60a6                	ld	ra,72(sp)
    80004996:	6406                	ld	s0,64(sp)
    80004998:	7942                	ld	s2,48(sp)
    8000499a:	7a02                	ld	s4,32(sp)
    8000499c:	6b42                	ld	s6,16(sp)
    8000499e:	6161                	addi	sp,sp,80
    800049a0:	8082                	ret
    800049a2:	fc26                	sd	s1,56(sp)
    800049a4:	f44e                	sd	s3,40(sp)
    800049a6:	ec56                	sd	s5,24(sp)
    800049a8:	e45e                	sd	s7,8(sp)
    800049aa:	e062                	sd	s8,0(sp)
    panic("filewrite");
    800049ac:	00004517          	auipc	a0,0x4
    800049b0:	dac50513          	addi	a0,a0,-596 # 80008758 <etext+0x758>
    800049b4:	e3dfb0ef          	jal	800007f0 <panic>
    return -1;
    800049b8:	557d                	li	a0,-1
}
    800049ba:	8082                	ret
    return -1;
    800049bc:	557d                	li	a0,-1
    800049be:	bfd9                	j	80004994 <filewrite+0xec>
      return -1;
    800049c0:	557d                	li	a0,-1
    800049c2:	bfc9                	j	80004994 <filewrite+0xec>
    800049c4:	557d                	li	a0,-1
    800049c6:	b7f9                	j	80004994 <filewrite+0xec>
    ret = (i == n ? n : -1);
    800049c8:	8532                	mv	a0,a2
    800049ca:	b7e9                	j	80004994 <filewrite+0xec>
    800049cc:	557d                	li	a0,-1
    800049ce:	74e2                	ld	s1,56(sp)
    800049d0:	79a2                	ld	s3,40(sp)
    800049d2:	6ae2                	ld	s5,24(sp)
    800049d4:	6ba2                	ld	s7,8(sp)
    800049d6:	6c02                	ld	s8,0(sp)
    800049d8:	bf75                	j	80004994 <filewrite+0xec>

00000000800049da <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800049da:	7179                	addi	sp,sp,-48
    800049dc:	f406                	sd	ra,40(sp)
    800049de:	f022                	sd	s0,32(sp)
    800049e0:	ec26                	sd	s1,24(sp)
    800049e2:	e052                	sd	s4,0(sp)
    800049e4:	1800                	addi	s0,sp,48
    800049e6:	84aa                	mv	s1,a0
    800049e8:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800049ea:	0005b023          	sd	zero,0(a1)
    800049ee:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800049f2:	c25ff0ef          	jal	80004616 <filealloc>
    800049f6:	e088                	sd	a0,0(s1)
    800049f8:	c549                	beqz	a0,80004a82 <pipealloc+0xa8>
    800049fa:	c1dff0ef          	jal	80004616 <filealloc>
    800049fe:	00aa3023          	sd	a0,0(s4)
    80004a02:	cd25                	beqz	a0,80004a7a <pipealloc+0xa0>
    80004a04:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    80004a06:	8c4fc0ef          	jal	80000aca <kalloc>
    80004a0a:	892a                	mv	s2,a0
    80004a0c:	c12d                	beqz	a0,80004a6e <pipealloc+0x94>
    80004a0e:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004a10:	4985                	li	s3,1
    80004a12:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004a16:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004a1a:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004a1e:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004a22:	00004597          	auipc	a1,0x4
    80004a26:	d4658593          	addi	a1,a1,-698 # 80008768 <etext+0x768>
    80004a2a:	8f0fc0ef          	jal	80000b1a <initlock>
  (*f0)->type = FD_PIPE;
    80004a2e:	609c                	ld	a5,0(s1)
    80004a30:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004a34:	609c                	ld	a5,0(s1)
    80004a36:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004a3a:	609c                	ld	a5,0(s1)
    80004a3c:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004a40:	609c                	ld	a5,0(s1)
    80004a42:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004a46:	000a3783          	ld	a5,0(s4)
    80004a4a:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004a4e:	000a3783          	ld	a5,0(s4)
    80004a52:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004a56:	000a3783          	ld	a5,0(s4)
    80004a5a:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004a5e:	000a3783          	ld	a5,0(s4)
    80004a62:	0127b823          	sd	s2,16(a5)
  return 0;
    80004a66:	4501                	li	a0,0
    80004a68:	6942                	ld	s2,16(sp)
    80004a6a:	69a2                	ld	s3,8(sp)
    80004a6c:	a01d                	j	80004a92 <pipealloc+0xb8>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    80004a6e:	6088                	ld	a0,0(s1)
    80004a70:	c119                	beqz	a0,80004a76 <pipealloc+0x9c>
    80004a72:	6942                	ld	s2,16(sp)
    80004a74:	a029                	j	80004a7e <pipealloc+0xa4>
    80004a76:	6942                	ld	s2,16(sp)
    80004a78:	a029                	j	80004a82 <pipealloc+0xa8>
    80004a7a:	6088                	ld	a0,0(s1)
    80004a7c:	c10d                	beqz	a0,80004a9e <pipealloc+0xc4>
    fileclose(*f0);
    80004a7e:	c3dff0ef          	jal	800046ba <fileclose>
  if (*f1)
    80004a82:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004a86:	557d                	li	a0,-1
  if (*f1)
    80004a88:	c789                	beqz	a5,80004a92 <pipealloc+0xb8>
    fileclose(*f1);
    80004a8a:	853e                	mv	a0,a5
    80004a8c:	c2fff0ef          	jal	800046ba <fileclose>
  return -1;
    80004a90:	557d                	li	a0,-1
}
    80004a92:	70a2                	ld	ra,40(sp)
    80004a94:	7402                	ld	s0,32(sp)
    80004a96:	64e2                	ld	s1,24(sp)
    80004a98:	6a02                	ld	s4,0(sp)
    80004a9a:	6145                	addi	sp,sp,48
    80004a9c:	8082                	ret
  return -1;
    80004a9e:	557d                	li	a0,-1
    80004aa0:	bfcd                	j	80004a92 <pipealloc+0xb8>

0000000080004aa2 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004aa2:	1101                	addi	sp,sp,-32
    80004aa4:	ec06                	sd	ra,24(sp)
    80004aa6:	e822                	sd	s0,16(sp)
    80004aa8:	e426                	sd	s1,8(sp)
    80004aaa:	e04a                	sd	s2,0(sp)
    80004aac:	1000                	addi	s0,sp,32
    80004aae:	84aa                	mv	s1,a0
    80004ab0:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004ab2:	8defc0ef          	jal	80000b90 <acquire>
  if (writable) {
    80004ab6:	02090763          	beqz	s2,80004ae4 <pipeclose+0x42>
    pi->writeopen = 0;
    80004aba:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004abe:	21848513          	addi	a0,s1,536
    80004ac2:	c50fd0ef          	jal	80001f12 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    80004ac6:	2204b783          	ld	a5,544(s1)
    80004aca:	e785                	bnez	a5,80004af2 <pipeclose+0x50>
    release(&pi->lock);
    80004acc:	8526                	mv	a0,s1
    80004ace:	94efc0ef          	jal	80000c1c <release>
    kfree((char *)pi);
    80004ad2:	8526                	mv	a0,s1
    80004ad4:	f15fb0ef          	jal	800009e8 <kfree>
  } else
    release(&pi->lock);
}
    80004ad8:	60e2                	ld	ra,24(sp)
    80004ada:	6442                	ld	s0,16(sp)
    80004adc:	64a2                	ld	s1,8(sp)
    80004ade:	6902                	ld	s2,0(sp)
    80004ae0:	6105                	addi	sp,sp,32
    80004ae2:	8082                	ret
    pi->readopen = 0;
    80004ae4:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004ae8:	21c48513          	addi	a0,s1,540
    80004aec:	c26fd0ef          	jal	80001f12 <wakeup>
    80004af0:	bfd9                	j	80004ac6 <pipeclose+0x24>
    release(&pi->lock);
    80004af2:	8526                	mv	a0,s1
    80004af4:	928fc0ef          	jal	80000c1c <release>
}
    80004af8:	b7c5                	j	80004ad8 <pipeclose+0x36>

0000000080004afa <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004afa:	711d                	addi	sp,sp,-96
    80004afc:	ec86                	sd	ra,88(sp)
    80004afe:	e8a2                	sd	s0,80(sp)
    80004b00:	e4a6                	sd	s1,72(sp)
    80004b02:	e0ca                	sd	s2,64(sp)
    80004b04:	fc4e                	sd	s3,56(sp)
    80004b06:	f852                	sd	s4,48(sp)
    80004b08:	f456                	sd	s5,40(sp)
    80004b0a:	1080                	addi	s0,sp,96
    80004b0c:	84aa                	mv	s1,a0
    80004b0e:	8aae                	mv	s5,a1
    80004b10:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004b12:	d91fc0ef          	jal	800018a2 <myproc>
    80004b16:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004b18:	8526                	mv	a0,s1
    80004b1a:	876fc0ef          	jal	80000b90 <acquire>
  while (i < n) {
    80004b1e:	0d405e63          	blez	s4,80004bfa <pipewrite+0x100>
    80004b22:	f05a                	sd	s6,32(sp)
    80004b24:	ec5e                	sd	s7,24(sp)
    80004b26:	e862                	sd	s8,16(sp)
  int i = 0;
    80004b28:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004b2a:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004b2c:	21848c13          	addi	s8,s1,536
      sleep_prepare(&pi->nwrite);
    80004b30:	21c48b93          	addi	s7,s1,540
    80004b34:	a091                	j	80004b78 <pipewrite+0x7e>
      release(&pi->lock);
    80004b36:	8526                	mv	a0,s1
    80004b38:	8e4fc0ef          	jal	80000c1c <release>
      return -1;
    80004b3c:	597d                	li	s2,-1
    80004b3e:	7b02                	ld	s6,32(sp)
    80004b40:	6be2                	ld	s7,24(sp)
    80004b42:	6c42                	ld	s8,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004b44:	854a                	mv	a0,s2
    80004b46:	60e6                	ld	ra,88(sp)
    80004b48:	6446                	ld	s0,80(sp)
    80004b4a:	64a6                	ld	s1,72(sp)
    80004b4c:	6906                	ld	s2,64(sp)
    80004b4e:	79e2                	ld	s3,56(sp)
    80004b50:	7a42                	ld	s4,48(sp)
    80004b52:	7aa2                	ld	s5,40(sp)
    80004b54:	6125                	addi	sp,sp,96
    80004b56:	8082                	ret
      wakeup(&pi->nread);
    80004b58:	8562                	mv	a0,s8
    80004b5a:	bb8fd0ef          	jal	80001f12 <wakeup>
      sleep_prepare(&pi->nwrite);
    80004b5e:	855e                	mv	a0,s7
    80004b60:	b46fd0ef          	jal	80001ea6 <sleep_prepare>
      release(&pi->lock);
    80004b64:	8526                	mv	a0,s1
    80004b66:	8b6fc0ef          	jal	80000c1c <release>
      sleep();
    80004b6a:	b78fd0ef          	jal	80001ee2 <sleep>
      acquire(&pi->lock);
    80004b6e:	8526                	mv	a0,s1
    80004b70:	820fc0ef          	jal	80000b90 <acquire>
  while (i < n) {
    80004b74:	07495863          	bge	s2,s4,80004be4 <pipewrite+0xea>
    if (pi->readopen == 0 || killed(pr)) {
    80004b78:	2204a783          	lw	a5,544(s1)
    80004b7c:	dfcd                	beqz	a5,80004b36 <pipewrite+0x3c>
    80004b7e:	854e                	mv	a0,s3
    80004b80:	d80fd0ef          	jal	80002100 <killed>
    80004b84:	f94d                	bnez	a0,80004b36 <pipewrite+0x3c>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    80004b86:	2184a783          	lw	a5,536(s1)
    80004b8a:	21c4a703          	lw	a4,540(s1)
    80004b8e:	2007879b          	addiw	a5,a5,512
    80004b92:	fcf703e3          	beq	a4,a5,80004b58 <pipewrite+0x5e>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004b96:	4705                	li	a4,1
    80004b98:	015906b3          	add	a3,s2,s5
    80004b9c:	faf40613          	addi	a2,s0,-81
    80004ba0:	0489b583          	ld	a1,72(s3)
    80004ba4:	0509b503          	ld	a0,80(s3)
    80004ba8:	a1dfc0ef          	jal	800015c4 <copyin>
    80004bac:	03650163          	beq	a0,s6,80004bce <pipewrite+0xd4>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004bb0:	21c4a783          	lw	a5,540(s1)
    80004bb4:	0017871b          	addiw	a4,a5,1
    80004bb8:	20e4ae23          	sw	a4,540(s1)
    80004bbc:	1ff7f793          	andi	a5,a5,511
    80004bc0:	97a6                	add	a5,a5,s1
    80004bc2:	faf44703          	lbu	a4,-81(s0)
    80004bc6:	00e78c23          	sb	a4,24(a5)
      i++;
    80004bca:	2905                	addiw	s2,s2,1
    80004bcc:	b765                	j	80004b74 <pipewrite+0x7a>
        if (i == 0)
    80004bce:	00090663          	beqz	s2,80004bda <pipewrite+0xe0>
    80004bd2:	7b02                	ld	s6,32(sp)
    80004bd4:	6be2                	ld	s7,24(sp)
    80004bd6:	6c42                	ld	s8,16(sp)
    80004bd8:	a809                	j	80004bea <pipewrite+0xf0>
          i = -1;
    80004bda:	892a                	mv	s2,a0
        break;
    80004bdc:	7b02                	ld	s6,32(sp)
    80004bde:	6be2                	ld	s7,24(sp)
    80004be0:	6c42                	ld	s8,16(sp)
    80004be2:	a021                	j	80004bea <pipewrite+0xf0>
    80004be4:	7b02                	ld	s6,32(sp)
    80004be6:	6be2                	ld	s7,24(sp)
    80004be8:	6c42                	ld	s8,16(sp)
  wakeup(&pi->nread);
    80004bea:	21848513          	addi	a0,s1,536
    80004bee:	b24fd0ef          	jal	80001f12 <wakeup>
  release(&pi->lock);
    80004bf2:	8526                	mv	a0,s1
    80004bf4:	828fc0ef          	jal	80000c1c <release>
  return i;
    80004bf8:	b7b1                	j	80004b44 <pipewrite+0x4a>
  int i = 0;
    80004bfa:	4901                	li	s2,0
    80004bfc:	b7fd                	j	80004bea <pipewrite+0xf0>

0000000080004bfe <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004bfe:	715d                	addi	sp,sp,-80
    80004c00:	e486                	sd	ra,72(sp)
    80004c02:	e0a2                	sd	s0,64(sp)
    80004c04:	fc26                	sd	s1,56(sp)
    80004c06:	f84a                	sd	s2,48(sp)
    80004c08:	f44e                	sd	s3,40(sp)
    80004c0a:	f052                	sd	s4,32(sp)
    80004c0c:	ec56                	sd	s5,24(sp)
    80004c0e:	0880                	addi	s0,sp,80
    80004c10:	84aa                	mv	s1,a0
    80004c12:	89ae                	mv	s3,a1
    80004c14:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004c16:	c8dfc0ef          	jal	800018a2 <myproc>
    80004c1a:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    80004c1c:	8526                	mv	a0,s1
    80004c1e:	f73fb0ef          	jal	80000b90 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004c22:	2184a703          	lw	a4,536(s1)
    80004c26:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004c2a:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004c2e:	02f71c63          	bne	a4,a5,80004c66 <piperead+0x68>
    80004c32:	2244a783          	lw	a5,548(s1)
    80004c36:	cf9d                	beqz	a5,80004c74 <piperead+0x76>
    if (killed(pr)) {
    80004c38:	854a                	mv	a0,s2
    80004c3a:	cc6fd0ef          	jal	80002100 <killed>
    80004c3e:	e515                	bnez	a0,80004c6a <piperead+0x6c>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004c40:	8552                	mv	a0,s4
    80004c42:	a64fd0ef          	jal	80001ea6 <sleep_prepare>
    release(&pi->lock);
    80004c46:	8526                	mv	a0,s1
    80004c48:	fd5fb0ef          	jal	80000c1c <release>
    sleep();
    80004c4c:	a96fd0ef          	jal	80001ee2 <sleep>
    acquire(&pi->lock);
    80004c50:	8526                	mv	a0,s1
    80004c52:	f3ffb0ef          	jal	80000b90 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004c56:	2184a703          	lw	a4,536(s1)
    80004c5a:	21c4a783          	lw	a5,540(s1)
    80004c5e:	fcf70ae3          	beq	a4,a5,80004c32 <piperead+0x34>
    80004c62:	e85a                	sd	s6,16(sp)
    80004c64:	a809                	j	80004c76 <piperead+0x78>
    80004c66:	e85a                	sd	s6,16(sp)
    80004c68:	a039                	j	80004c76 <piperead+0x78>
      release(&pi->lock);
    80004c6a:	8526                	mv	a0,s1
    80004c6c:	fb1fb0ef          	jal	80000c1c <release>
      return -1;
    80004c70:	5a7d                	li	s4,-1
    80004c72:	a08d                	j	80004cd4 <piperead+0xd6>
    80004c74:	e85a                	sd	s6,16(sp)
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004c76:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004c78:	5b7d                	li	s6,-1
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004c7a:	05505563          	blez	s5,80004cc4 <piperead+0xc6>
    if (pi->nread == pi->nwrite)
    80004c7e:	2184a783          	lw	a5,536(s1)
    80004c82:	21c4a703          	lw	a4,540(s1)
    80004c86:	02f70f63          	beq	a4,a5,80004cc4 <piperead+0xc6>
    ch = pi->data[pi->nread % PIPESIZE];
    80004c8a:	1ff7f793          	andi	a5,a5,511
    80004c8e:	97a6                	add	a5,a5,s1
    80004c90:	0187c783          	lbu	a5,24(a5)
    80004c94:	faf40fa3          	sb	a5,-65(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004c98:	4705                	li	a4,1
    80004c9a:	fbf40693          	addi	a3,s0,-65
    80004c9e:	864e                	mv	a2,s3
    80004ca0:	04893583          	ld	a1,72(s2)
    80004ca4:	05093503          	ld	a0,80(s2)
    80004ca8:	831fc0ef          	jal	800014d8 <copyout>
    80004cac:	03650e63          	beq	a0,s6,80004ce8 <piperead+0xea>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004cb0:	2184a783          	lw	a5,536(s1)
    80004cb4:	2785                	addiw	a5,a5,1
    80004cb6:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004cba:	2a05                	addiw	s4,s4,1
    80004cbc:	0985                	addi	s3,s3,1
    80004cbe:	fd4a90e3          	bne	s5,s4,80004c7e <piperead+0x80>
    80004cc2:	8a56                	mv	s4,s5
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    80004cc4:	21c48513          	addi	a0,s1,540
    80004cc8:	a4afd0ef          	jal	80001f12 <wakeup>
  release(&pi->lock);
    80004ccc:	8526                	mv	a0,s1
    80004cce:	f4ffb0ef          	jal	80000c1c <release>
    80004cd2:	6b42                	ld	s6,16(sp)
  return i;
}
    80004cd4:	8552                	mv	a0,s4
    80004cd6:	60a6                	ld	ra,72(sp)
    80004cd8:	6406                	ld	s0,64(sp)
    80004cda:	74e2                	ld	s1,56(sp)
    80004cdc:	7942                	ld	s2,48(sp)
    80004cde:	79a2                	ld	s3,40(sp)
    80004ce0:	7a02                	ld	s4,32(sp)
    80004ce2:	6ae2                	ld	s5,24(sp)
    80004ce4:	6161                	addi	sp,sp,80
    80004ce6:	8082                	ret
      if (i == 0)
    80004ce8:	fc0a1ee3          	bnez	s4,80004cc4 <piperead+0xc6>
        i = -1;
    80004cec:	8a2a                	mv	s4,a0
    80004cee:	bfd9                	j	80004cc4 <piperead+0xc6>

0000000080004cf0 <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    80004cf0:	1141                	addi	sp,sp,-16
    80004cf2:	e422                	sd	s0,8(sp)
    80004cf4:	0800                	addi	s0,sp,16
    80004cf6:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    80004cf8:	8905                	andi	a0,a0,1
    80004cfa:	050e                	slli	a0,a0,0x3
    perm = PTE_X;
  if (flags & 0x2)
    80004cfc:	8b89                	andi	a5,a5,2
    80004cfe:	c399                	beqz	a5,80004d04 <flags2perm+0x14>
    perm |= PTE_W;
    80004d00:	00456513          	ori	a0,a0,4
  return perm;
}
    80004d04:	6422                	ld	s0,8(sp)
    80004d06:	0141                	addi	sp,sp,16
    80004d08:	8082                	ret

0000000080004d0a <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004d0a:	df010113          	addi	sp,sp,-528
    80004d0e:	20113423          	sd	ra,520(sp)
    80004d12:	20813023          	sd	s0,512(sp)
    80004d16:	ffa6                	sd	s1,504(sp)
    80004d18:	fbca                	sd	s2,496(sp)
    80004d1a:	0c00                	addi	s0,sp,528
    80004d1c:	892a                	mv	s2,a0
    80004d1e:	dea43c23          	sd	a0,-520(s0)
    80004d22:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004d26:	b7dfc0ef          	jal	800018a2 <myproc>
    80004d2a:	84aa                	mv	s1,a0

  begin_op();
    80004d2c:	ce2ff0ef          	jal	8000420e <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    80004d30:	854a                	mv	a0,s2
    80004d32:	b08ff0ef          	jal	8000403a <namei>
    80004d36:	c931                	beqz	a0,80004d8a <kexec+0x80>
    80004d38:	f3d2                	sd	s4,480(sp)
    80004d3a:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004d3c:	a89fe0ef          	jal	800037c4 <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004d40:	04000713          	li	a4,64
    80004d44:	4681                	li	a3,0
    80004d46:	e5040613          	addi	a2,s0,-432
    80004d4a:	4581                	li	a1,0
    80004d4c:	8552                	mv	a0,s4
    80004d4e:	e4ffe0ef          	jal	80003b9c <readi>
    80004d52:	04000793          	li	a5,64
    80004d56:	00f51a63          	bne	a0,a5,80004d6a <kexec+0x60>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    80004d5a:	e5042703          	lw	a4,-432(s0)
    80004d5e:	464c47b7          	lui	a5,0x464c4
    80004d62:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004d66:	02f70663          	beq	a4,a5,80004d92 <kexec+0x88>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    80004d6a:	8552                	mv	a0,s4
    80004d6c:	cabfe0ef          	jal	80003a16 <iunlockput>
    end_op();
    80004d70:	d24ff0ef          	jal	80004294 <end_op>
  }
  return -1;
    80004d74:	557d                	li	a0,-1
    80004d76:	7a1e                	ld	s4,480(sp)
}
    80004d78:	20813083          	ld	ra,520(sp)
    80004d7c:	20013403          	ld	s0,512(sp)
    80004d80:	74fe                	ld	s1,504(sp)
    80004d82:	795e                	ld	s2,496(sp)
    80004d84:	21010113          	addi	sp,sp,528
    80004d88:	8082                	ret
    end_op();
    80004d8a:	d0aff0ef          	jal	80004294 <end_op>
    return -1;
    80004d8e:	557d                	li	a0,-1
    80004d90:	b7e5                	j	80004d78 <kexec+0x6e>
    80004d92:	ebda                	sd	s6,464(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    80004d94:	8526                	mv	a0,s1
    80004d96:	c0ffc0ef          	jal	800019a4 <proc_pagetable>
    80004d9a:	8b2a                	mv	s6,a0
    80004d9c:	2c050963          	beqz	a0,8000506e <kexec+0x364>
    80004da0:	f7ce                	sd	s3,488(sp)
    80004da2:	efd6                	sd	s5,472(sp)
    80004da4:	e7de                	sd	s7,456(sp)
    80004da6:	e3e2                	sd	s8,448(sp)
    80004da8:	ff66                	sd	s9,440(sp)
    80004daa:	fb6a                	sd	s10,432(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004dac:	e7042d03          	lw	s10,-400(s0)
    80004db0:	e8845783          	lhu	a5,-376(s0)
    80004db4:	12078863          	beqz	a5,80004ee4 <kexec+0x1da>
    80004db8:	f76e                	sd	s11,424(sp)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004dba:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004dbc:	4d81                	li	s11,0
    if (ph.vaddr % PGSIZE != 0)
    80004dbe:	6c85                	lui	s9,0x1
    80004dc0:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004dc4:	def43823          	sd	a5,-528(s0)

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    80004dc8:	6a85                	lui	s5,0x1
    80004dca:	a085                	j	80004e2a <kexec+0x120>
      panic("loadseg: address should exist");
    80004dcc:	00004517          	auipc	a0,0x4
    80004dd0:	9a450513          	addi	a0,a0,-1628 # 80008770 <etext+0x770>
    80004dd4:	a1dfb0ef          	jal	800007f0 <panic>
    if (sz - i < PGSIZE)
    80004dd8:	2481                	sext.w	s1,s1
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    80004dda:	8726                	mv	a4,s1
    80004ddc:	012c06bb          	addw	a3,s8,s2
    80004de0:	4581                	li	a1,0
    80004de2:	8552                	mv	a0,s4
    80004de4:	db9fe0ef          	jal	80003b9c <readi>
    80004de8:	2501                	sext.w	a0,a0
    80004dea:	24a49863          	bne	s1,a0,8000503a <kexec+0x330>
  for (i = 0; i < sz; i += PGSIZE) {
    80004dee:	012a893b          	addw	s2,s5,s2
    80004df2:	03397363          	bgeu	s2,s3,80004e18 <kexec+0x10e>
    pa = walkaddr(pagetable, va + i);
    80004df6:	02091593          	slli	a1,s2,0x20
    80004dfa:	9181                	srli	a1,a1,0x20
    80004dfc:	95de                	add	a1,a1,s7
    80004dfe:	855a                	mv	a0,s6
    80004e00:	964fc0ef          	jal	80000f64 <walkaddr>
    80004e04:	862a                	mv	a2,a0
    if (pa == 0)
    80004e06:	d179                	beqz	a0,80004dcc <kexec+0xc2>
    if (sz - i < PGSIZE)
    80004e08:	412984bb          	subw	s1,s3,s2
    80004e0c:	0004879b          	sext.w	a5,s1
    80004e10:	fcfcf4e3          	bgeu	s9,a5,80004dd8 <kexec+0xce>
    80004e14:	84d6                	mv	s1,s5
    80004e16:	b7c9                	j	80004dd8 <kexec+0xce>
    sz = sz1;
    80004e18:	e0843903          	ld	s2,-504(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80004e1c:	2d85                	addiw	s11,s11,1
    80004e1e:	038d0d1b          	addiw	s10,s10,56 # 1038 <_entry-0x7fffefc8>
    80004e22:	e8845783          	lhu	a5,-376(s0)
    80004e26:	08fdd063          	bge	s11,a5,80004ea6 <kexec+0x19c>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004e2a:	2d01                	sext.w	s10,s10
    80004e2c:	03800713          	li	a4,56
    80004e30:	86ea                	mv	a3,s10
    80004e32:	e1840613          	addi	a2,s0,-488
    80004e36:	4581                	li	a1,0
    80004e38:	8552                	mv	a0,s4
    80004e3a:	d63fe0ef          	jal	80003b9c <readi>
    80004e3e:	03800793          	li	a5,56
    80004e42:	1cf51463          	bne	a0,a5,8000500a <kexec+0x300>
    if (ph.type != ELF_PROG_LOAD)
    80004e46:	e1842783          	lw	a5,-488(s0)
    80004e4a:	4705                	li	a4,1
    80004e4c:	fce798e3          	bne	a5,a4,80004e1c <kexec+0x112>
    if (ph.memsz < ph.filesz)
    80004e50:	e4043483          	ld	s1,-448(s0)
    80004e54:	e3843783          	ld	a5,-456(s0)
    80004e58:	1af4ed63          	bltu	s1,a5,80005012 <kexec+0x308>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    80004e5c:	e2843783          	ld	a5,-472(s0)
    80004e60:	94be                	add	s1,s1,a5
    80004e62:	1af4ec63          	bltu	s1,a5,8000501a <kexec+0x310>
    if (ph.vaddr % PGSIZE != 0)
    80004e66:	df043703          	ld	a4,-528(s0)
    80004e6a:	8ff9                	and	a5,a5,a4
    80004e6c:	1a079b63          	bnez	a5,80005022 <kexec+0x318>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    80004e70:	e1c42503          	lw	a0,-484(s0)
    80004e74:	e7dff0ef          	jal	80004cf0 <flags2perm>
    80004e78:	86aa                	mv	a3,a0
    80004e7a:	8626                	mv	a2,s1
    80004e7c:	85ca                	mv	a1,s2
    80004e7e:	855a                	mv	a0,s6
    80004e80:	bbcfc0ef          	jal	8000123c <uvmalloc>
    80004e84:	e0a43423          	sd	a0,-504(s0)
    80004e88:	1a050163          	beqz	a0,8000502a <kexec+0x320>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004e8c:	e2843b83          	ld	s7,-472(s0)
    80004e90:	e2042c03          	lw	s8,-480(s0)
    80004e94:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    80004e98:	00098463          	beqz	s3,80004ea0 <kexec+0x196>
    80004e9c:	4901                	li	s2,0
    80004e9e:	bfa1                	j	80004df6 <kexec+0xec>
    sz = sz1;
    80004ea0:	e0843903          	ld	s2,-504(s0)
    80004ea4:	bfa5                	j	80004e1c <kexec+0x112>
    80004ea6:	7dba                	ld	s11,424(sp)
  iunlockput(ip);
    80004ea8:	8552                	mv	a0,s4
    80004eaa:	b6dfe0ef          	jal	80003a16 <iunlockput>
  end_op();
    80004eae:	be6ff0ef          	jal	80004294 <end_op>
  p = myproc();
    80004eb2:	9f1fc0ef          	jal	800018a2 <myproc>
    80004eb6:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004eb8:	04853a03          	ld	s4,72(a0)
  sz = PGROUNDUP(sz);
    80004ebc:	6b85                	lui	s7,0x1
    80004ebe:	1bfd                	addi	s7,s7,-1 # fff <_entry-0x7ffff001>
    80004ec0:	9bca                	add	s7,s7,s2
    80004ec2:	77fd                	lui	a5,0xfffff
    80004ec4:	00fbfbb3          	and	s7,s7,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    80004ec8:	4691                	li	a3,4
    80004eca:	6609                	lui	a2,0x2
    80004ecc:	965e                	add	a2,a2,s7
    80004ece:	85de                	mv	a1,s7
    80004ed0:	855a                	mv	a0,s6
    80004ed2:	b6afc0ef          	jal	8000123c <uvmalloc>
    80004ed6:	e0a43423          	sd	a0,-504(s0)
    80004eda:	e519                	bnez	a0,80004ee8 <kexec+0x1de>
  if (pagetable)
    80004edc:	e1743423          	sd	s7,-504(s0)
    80004ee0:	4a01                	li	s4,0
    80004ee2:	aaa9                	j	8000503c <kexec+0x332>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004ee4:	4901                	li	s2,0
    80004ee6:	b7c9                	j	80004ea8 <kexec+0x19e>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80004ee8:	75f9                	lui	a1,0xffffe
    80004eea:	8baa                	mv	s7,a0
    80004eec:	95aa                	add	a1,a1,a0
    80004eee:	855a                	mv	a0,s6
    80004ef0:	d22fc0ef          	jal	80001412 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    80004ef4:	7afd                	lui	s5,0xfffff
    80004ef6:	9ade                	add	s5,s5,s7
  for (argc = 0; argv[argc]; argc++) {
    80004ef8:	e0043783          	ld	a5,-512(s0)
    80004efc:	6388                	ld	a0,0(a5)
    80004efe:	c15d                	beqz	a0,80004fa4 <kexec+0x29a>
    80004f00:	e9040913          	addi	s2,s0,-368
    80004f04:	4481                	li	s1,0
    sp -= strlen(argv[argc]) + 1;
    80004f06:	ebffb0ef          	jal	80000dc4 <strlen>
    80004f0a:	0015079b          	addiw	a5,a0,1
    80004f0e:	40fb87b3          	sub	a5,s7,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004f12:	ff07fb93          	andi	s7,a5,-16
    if (sp < stackbase)
    80004f16:	115bee63          	bltu	s7,s5,80005032 <kexec+0x328>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004f1a:	e0043c83          	ld	s9,-512(s0)
    80004f1e:	000cbc03          	ld	s8,0(s9)
    80004f22:	8562                	mv	a0,s8
    80004f24:	ea1fb0ef          	jal	80000dc4 <strlen>
    80004f28:	0015071b          	addiw	a4,a0,1
    80004f2c:	86e2                	mv	a3,s8
    80004f2e:	865e                	mv	a2,s7
    80004f30:	e0843583          	ld	a1,-504(s0)
    80004f34:	855a                	mv	a0,s6
    80004f36:	da2fc0ef          	jal	800014d8 <copyout>
    80004f3a:	0e054e63          	bltz	a0,80005036 <kexec+0x32c>
    ustack[argc] = sp;
    80004f3e:	01793023          	sd	s7,0(s2)
  for (argc = 0; argv[argc]; argc++) {
    80004f42:	0485                	addi	s1,s1,1
    80004f44:	008c8793          	addi	a5,s9,8
    80004f48:	e0f43023          	sd	a5,-512(s0)
    80004f4c:	008cb503          	ld	a0,8(s9)
    80004f50:	0921                	addi	s2,s2,8
    80004f52:	f955                	bnez	a0,80004f06 <kexec+0x1fc>
  ustack[argc] = 0;
    80004f54:	00349793          	slli	a5,s1,0x3
    80004f58:	f9078793          	addi	a5,a5,-112 # ffffffffffffef90 <end+0xffffffff7ffda710>
    80004f5c:	97a2                	add	a5,a5,s0
    80004f5e:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    80004f62:	00148713          	addi	a4,s1,1
    80004f66:	070e                	slli	a4,a4,0x3
    80004f68:	40eb8933          	sub	s2,s7,a4
  sp -= sp % 16;
    80004f6c:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004f70:	e0843583          	ld	a1,-504(s0)
    80004f74:	8bae                	mv	s7,a1
  if (sp < stackbase)
    80004f76:	f75963e3          	bltu	s2,s5,80004edc <kexec+0x1d2>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    80004f7a:	e9040693          	addi	a3,s0,-368
    80004f7e:	864a                	mv	a2,s2
    80004f80:	855a                	mv	a0,s6
    80004f82:	d56fc0ef          	jal	800014d8 <copyout>
    80004f86:	0e054663          	bltz	a0,80005072 <kexec+0x368>
  p->trapframe->a1 = sp;
    80004f8a:	0589b783          	ld	a5,88(s3)
    80004f8e:	0727bc23          	sd	s2,120(a5)
  for (last = s = path; *s; s++)
    80004f92:	df843783          	ld	a5,-520(s0)
    80004f96:	0007c703          	lbu	a4,0(a5)
    80004f9a:	c315                	beqz	a4,80004fbe <kexec+0x2b4>
    80004f9c:	0785                	addi	a5,a5,1
    if (*s == '/')
    80004f9e:	02f00693          	li	a3,47
    80004fa2:	a809                	j	80004fb4 <kexec+0x2aa>
  sp = sz;
    80004fa4:	e0843b83          	ld	s7,-504(s0)
  for (argc = 0; argv[argc]; argc++) {
    80004fa8:	4481                	li	s1,0
    80004faa:	b76d                	j	80004f54 <kexec+0x24a>
  for (last = s = path; *s; s++)
    80004fac:	0785                	addi	a5,a5,1
    80004fae:	fff7c703          	lbu	a4,-1(a5)
    80004fb2:	c711                	beqz	a4,80004fbe <kexec+0x2b4>
    if (*s == '/')
    80004fb4:	fed71ce3          	bne	a4,a3,80004fac <kexec+0x2a2>
      last = s + 1;
    80004fb8:	def43c23          	sd	a5,-520(s0)
    80004fbc:	bfc5                	j	80004fac <kexec+0x2a2>
  safestrcpy(p->name, last, sizeof(p->name));
    80004fbe:	4641                	li	a2,16
    80004fc0:	df843583          	ld	a1,-520(s0)
    80004fc4:	15898513          	addi	a0,s3,344
    80004fc8:	dcbfb0ef          	jal	80000d92 <safestrcpy>
  oldpagetable = p->pagetable;
    80004fcc:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004fd0:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004fd4:	e0843783          	ld	a5,-504(s0)
    80004fd8:	04f9b423          	sd	a5,72(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80004fdc:	0589b783          	ld	a5,88(s3)
    80004fe0:	e6843703          	ld	a4,-408(s0)
    80004fe4:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    80004fe6:	0589b783          	ld	a5,88(s3)
    80004fea:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004fee:	85d2                	mv	a1,s4
    80004ff0:	a39fc0ef          	jal	80001a28 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004ff4:	0004851b          	sext.w	a0,s1
    80004ff8:	79be                	ld	s3,488(sp)
    80004ffa:	7a1e                	ld	s4,480(sp)
    80004ffc:	6afe                	ld	s5,472(sp)
    80004ffe:	6b5e                	ld	s6,464(sp)
    80005000:	6bbe                	ld	s7,456(sp)
    80005002:	6c1e                	ld	s8,448(sp)
    80005004:	7cfa                	ld	s9,440(sp)
    80005006:	7d5a                	ld	s10,432(sp)
    80005008:	bb85                	j	80004d78 <kexec+0x6e>
    8000500a:	e1243423          	sd	s2,-504(s0)
    8000500e:	7dba                	ld	s11,424(sp)
    80005010:	a035                	j	8000503c <kexec+0x332>
    80005012:	e1243423          	sd	s2,-504(s0)
    80005016:	7dba                	ld	s11,424(sp)
    80005018:	a015                	j	8000503c <kexec+0x332>
    8000501a:	e1243423          	sd	s2,-504(s0)
    8000501e:	7dba                	ld	s11,424(sp)
    80005020:	a831                	j	8000503c <kexec+0x332>
    80005022:	e1243423          	sd	s2,-504(s0)
    80005026:	7dba                	ld	s11,424(sp)
    80005028:	a811                	j	8000503c <kexec+0x332>
    8000502a:	e1243423          	sd	s2,-504(s0)
    8000502e:	7dba                	ld	s11,424(sp)
    80005030:	a031                	j	8000503c <kexec+0x332>
  ip = 0;
    80005032:	4a01                	li	s4,0
    80005034:	a021                	j	8000503c <kexec+0x332>
    80005036:	4a01                	li	s4,0
  if (pagetable)
    80005038:	a011                	j	8000503c <kexec+0x332>
    8000503a:	7dba                	ld	s11,424(sp)
    proc_freepagetable(pagetable, sz);
    8000503c:	e0843583          	ld	a1,-504(s0)
    80005040:	855a                	mv	a0,s6
    80005042:	9e7fc0ef          	jal	80001a28 <proc_freepagetable>
  return -1;
    80005046:	557d                	li	a0,-1
  if (ip) {
    80005048:	000a1b63          	bnez	s4,8000505e <kexec+0x354>
    8000504c:	79be                	ld	s3,488(sp)
    8000504e:	7a1e                	ld	s4,480(sp)
    80005050:	6afe                	ld	s5,472(sp)
    80005052:	6b5e                	ld	s6,464(sp)
    80005054:	6bbe                	ld	s7,456(sp)
    80005056:	6c1e                	ld	s8,448(sp)
    80005058:	7cfa                	ld	s9,440(sp)
    8000505a:	7d5a                	ld	s10,432(sp)
    8000505c:	bb31                	j	80004d78 <kexec+0x6e>
    8000505e:	79be                	ld	s3,488(sp)
    80005060:	6afe                	ld	s5,472(sp)
    80005062:	6b5e                	ld	s6,464(sp)
    80005064:	6bbe                	ld	s7,456(sp)
    80005066:	6c1e                	ld	s8,448(sp)
    80005068:	7cfa                	ld	s9,440(sp)
    8000506a:	7d5a                	ld	s10,432(sp)
    8000506c:	b9fd                	j	80004d6a <kexec+0x60>
    8000506e:	6b5e                	ld	s6,464(sp)
    80005070:	b9ed                	j	80004d6a <kexec+0x60>
  sz = sz1;
    80005072:	e0843b83          	ld	s7,-504(s0)
    80005076:	b59d                	j	80004edc <kexec+0x1d2>

0000000080005078 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80005078:	7179                	addi	sp,sp,-48
    8000507a:	f406                	sd	ra,40(sp)
    8000507c:	f022                	sd	s0,32(sp)
    8000507e:	ec26                	sd	s1,24(sp)
    80005080:	e84a                	sd	s2,16(sp)
    80005082:	1800                	addi	s0,sp,48
    80005084:	892e                	mv	s2,a1
    80005086:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80005088:	fdc40593          	addi	a1,s0,-36
    8000508c:	f50fd0ef          	jal	800027dc <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    80005090:	fdc42703          	lw	a4,-36(s0)
    80005094:	47bd                	li	a5,15
    80005096:	02e7e963          	bltu	a5,a4,800050c8 <argfd+0x50>
    8000509a:	809fc0ef          	jal	800018a2 <myproc>
    8000509e:	fdc42703          	lw	a4,-36(s0)
    800050a2:	01a70793          	addi	a5,a4,26
    800050a6:	078e                	slli	a5,a5,0x3
    800050a8:	953e                	add	a0,a0,a5
    800050aa:	611c                	ld	a5,0(a0)
    800050ac:	c385                	beqz	a5,800050cc <argfd+0x54>
    return -1;
  if (pfd)
    800050ae:	00090463          	beqz	s2,800050b6 <argfd+0x3e>
    *pfd = fd;
    800050b2:	00e92023          	sw	a4,0(s2)
  if (pf)
    *pf = f;
  return 0;
    800050b6:	4501                	li	a0,0
  if (pf)
    800050b8:	c091                	beqz	s1,800050bc <argfd+0x44>
    *pf = f;
    800050ba:	e09c                	sd	a5,0(s1)
}
    800050bc:	70a2                	ld	ra,40(sp)
    800050be:	7402                	ld	s0,32(sp)
    800050c0:	64e2                	ld	s1,24(sp)
    800050c2:	6942                	ld	s2,16(sp)
    800050c4:	6145                	addi	sp,sp,48
    800050c6:	8082                	ret
    return -1;
    800050c8:	557d                	li	a0,-1
    800050ca:	bfcd                	j	800050bc <argfd+0x44>
    800050cc:	557d                	li	a0,-1
    800050ce:	b7fd                	j	800050bc <argfd+0x44>

00000000800050d0 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    800050d0:	1101                	addi	sp,sp,-32
    800050d2:	ec06                	sd	ra,24(sp)
    800050d4:	e822                	sd	s0,16(sp)
    800050d6:	e426                	sd	s1,8(sp)
    800050d8:	1000                	addi	s0,sp,32
    800050da:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    800050dc:	fc6fc0ef          	jal	800018a2 <myproc>
    800050e0:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    800050e2:	0d050793          	addi	a5,a0,208
    800050e6:	4501                	li	a0,0
    800050e8:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    800050ea:	6398                	ld	a4,0(a5)
    800050ec:	cb19                	beqz	a4,80005102 <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    800050ee:	2505                	addiw	a0,a0,1
    800050f0:	07a1                	addi	a5,a5,8
    800050f2:	fed51ce3          	bne	a0,a3,800050ea <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    800050f6:	557d                	li	a0,-1
}
    800050f8:	60e2                	ld	ra,24(sp)
    800050fa:	6442                	ld	s0,16(sp)
    800050fc:	64a2                	ld	s1,8(sp)
    800050fe:	6105                	addi	sp,sp,32
    80005100:	8082                	ret
      p->ofile[fd] = f;
    80005102:	01a50793          	addi	a5,a0,26
    80005106:	078e                	slli	a5,a5,0x3
    80005108:	963e                	add	a2,a2,a5
    8000510a:	e204                	sd	s1,0(a2)
      return fd;
    8000510c:	b7f5                	j	800050f8 <fdalloc+0x28>

000000008000510e <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    8000510e:	715d                	addi	sp,sp,-80
    80005110:	e486                	sd	ra,72(sp)
    80005112:	e0a2                	sd	s0,64(sp)
    80005114:	fc26                	sd	s1,56(sp)
    80005116:	f84a                	sd	s2,48(sp)
    80005118:	f44e                	sd	s3,40(sp)
    8000511a:	f052                	sd	s4,32(sp)
    8000511c:	ec56                	sd	s5,24(sp)
    8000511e:	0880                	addi	s0,sp,80
    80005120:	892e                	mv	s2,a1
    80005122:	89b2                	mv	s3,a2
    80005124:	8a36                	mv	s4,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80005126:	fb040593          	addi	a1,s0,-80
    8000512a:	f2bfe0ef          	jal	80004054 <nameiparent>
    8000512e:	8aaa                	mv	s5,a0
    80005130:	cd45                	beqz	a0,800051e8 <create+0xda>
    return 0;

  ilock(dp);
    80005132:	e92fe0ef          	jal	800037c4 <ilock>

  if (dp->nlink == 0) {
    80005136:	04aa9783          	lh	a5,74(s5) # fffffffffffff04a <end+0xffffffff7ffda7ca>
    8000513a:	cf8d                	beqz	a5,80005174 <create+0x66>
    iunlockput(dp);
    return 0;
  }

  // a new directory's ".." would push dp->nlink past its maximum
  if (type == T_DIR && dp->nlink >= NLINK_MAX) {
    8000513c:	4705                	li	a4,1
    8000513e:	04e91563          	bne	s2,a4,80005188 <create+0x7a>
    80005142:	6721                	lui	a4,0x8
    80005144:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80005146:	02e78c63          	beq	a5,a4,8000517e <create+0x70>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    8000514a:	4601                	li	a2,0
    8000514c:	fb040593          	addi	a1,s0,-80
    80005150:	8556                	mv	a0,s5
    80005152:	c71fe0ef          	jal	80003dc2 <dirlookup>
    80005156:	84aa                	mv	s1,a0
    80005158:	e951                	bnez	a0,800051ec <create+0xde>
      return ip;
    iunlockput(ip);
    return 0;
  }

  if ((ip = ialloc(dp->dev, type)) == 0) {
    8000515a:	85ca                	mv	a1,s2
    8000515c:	000aa503          	lw	a0,0(s5)
    80005160:	cf4fe0ef          	jal	80003654 <ialloc>
    80005164:	84aa                	mv	s1,a0
    80005166:	0c051e63          	bnez	a0,80005242 <create+0x134>
    iunlockput(dp);
    8000516a:	8556                	mv	a0,s5
    8000516c:	8abfe0ef          	jal	80003a16 <iunlockput>
    return 0;
    80005170:	4481                	li	s1,0
    80005172:	a0a1                	j	800051ba <create+0xac>
    iunlockput(dp);
    80005174:	8556                	mv	a0,s5
    80005176:	8a1fe0ef          	jal	80003a16 <iunlockput>
    return 0;
    8000517a:	4481                	li	s1,0
    8000517c:	a83d                	j	800051ba <create+0xac>
    iunlockput(dp);
    8000517e:	8556                	mv	a0,s5
    80005180:	897fe0ef          	jal	80003a16 <iunlockput>
    return 0;
    80005184:	4481                	li	s1,0
    80005186:	a815                	j	800051ba <create+0xac>
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80005188:	4601                	li	a2,0
    8000518a:	fb040593          	addi	a1,s0,-80
    8000518e:	8556                	mv	a0,s5
    80005190:	c33fe0ef          	jal	80003dc2 <dirlookup>
    80005194:	84aa                	mv	s1,a0
    80005196:	c535                	beqz	a0,80005202 <create+0xf4>
    iunlockput(dp);
    80005198:	8556                	mv	a0,s5
    8000519a:	87dfe0ef          	jal	80003a16 <iunlockput>
    ilock(ip);
    8000519e:	8526                	mv	a0,s1
    800051a0:	e24fe0ef          	jal	800037c4 <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    800051a4:	4789                	li	a5,2
    800051a6:	04f91963          	bne	s2,a5,800051f8 <create+0xea>
    800051aa:	0444d783          	lhu	a5,68(s1)
    800051ae:	37f9                	addiw	a5,a5,-2
    800051b0:	17c2                	slli	a5,a5,0x30
    800051b2:	93c1                	srli	a5,a5,0x30
    800051b4:	4705                	li	a4,1
    800051b6:	04f76163          	bltu	a4,a5,800051f8 <create+0xea>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    800051ba:	8526                	mv	a0,s1
    800051bc:	60a6                	ld	ra,72(sp)
    800051be:	6406                	ld	s0,64(sp)
    800051c0:	74e2                	ld	s1,56(sp)
    800051c2:	7942                	ld	s2,48(sp)
    800051c4:	79a2                	ld	s3,40(sp)
    800051c6:	7a02                	ld	s4,32(sp)
    800051c8:	6ae2                	ld	s5,24(sp)
    800051ca:	6161                	addi	sp,sp,80
    800051cc:	8082                	ret
  ip->nlink = 0;
    800051ce:	04049523          	sh	zero,74(s1)
  iupdate(ip);
    800051d2:	8526                	mv	a0,s1
    800051d4:	d3cfe0ef          	jal	80003710 <iupdate>
  iunlockput(ip);
    800051d8:	8526                	mv	a0,s1
    800051da:	83dfe0ef          	jal	80003a16 <iunlockput>
  iunlockput(dp);
    800051de:	8556                	mv	a0,s5
    800051e0:	837fe0ef          	jal	80003a16 <iunlockput>
  return 0;
    800051e4:	4481                	li	s1,0
    800051e6:	bfd1                	j	800051ba <create+0xac>
    return 0;
    800051e8:	84aa                	mv	s1,a0
    800051ea:	bfc1                	j	800051ba <create+0xac>
    iunlockput(dp);
    800051ec:	8556                	mv	a0,s5
    800051ee:	829fe0ef          	jal	80003a16 <iunlockput>
    ilock(ip);
    800051f2:	8526                	mv	a0,s1
    800051f4:	dd0fe0ef          	jal	800037c4 <ilock>
    iunlockput(ip);
    800051f8:	8526                	mv	a0,s1
    800051fa:	81dfe0ef          	jal	80003a16 <iunlockput>
    return 0;
    800051fe:	4481                	li	s1,0
    80005200:	bf6d                	j	800051ba <create+0xac>
  if ((ip = ialloc(dp->dev, type)) == 0) {
    80005202:	85ca                	mv	a1,s2
    80005204:	000aa503          	lw	a0,0(s5)
    80005208:	c4cfe0ef          	jal	80003654 <ialloc>
    8000520c:	84aa                	mv	s1,a0
    8000520e:	dd31                	beqz	a0,8000516a <create+0x5c>
  ilock(ip);
    80005210:	8526                	mv	a0,s1
    80005212:	db2fe0ef          	jal	800037c4 <ilock>
  ip->major = major;
    80005216:	05349323          	sh	s3,70(s1)
  ip->minor = minor;
    8000521a:	05449423          	sh	s4,72(s1)
  ip->nlink = 1;
    8000521e:	4785                	li	a5,1
    80005220:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005224:	8526                	mv	a0,s1
    80005226:	ceafe0ef          	jal	80003710 <iupdate>
  if (dirlink(dp, name, ip->inum) < 0)
    8000522a:	40d0                	lw	a2,4(s1)
    8000522c:	fb040593          	addi	a1,s0,-80
    80005230:	8556                	mv	a0,s5
    80005232:	d6ffe0ef          	jal	80003fa0 <dirlink>
    80005236:	f8054ce3          	bltz	a0,800051ce <create+0xc0>
  iunlockput(dp);
    8000523a:	8556                	mv	a0,s5
    8000523c:	fdafe0ef          	jal	80003a16 <iunlockput>
  return ip;
    80005240:	bfad                	j	800051ba <create+0xac>
  ilock(ip);
    80005242:	8526                	mv	a0,s1
    80005244:	d80fe0ef          	jal	800037c4 <ilock>
  ip->major = major;
    80005248:	05349323          	sh	s3,70(s1)
  ip->minor = minor;
    8000524c:	05449423          	sh	s4,72(s1)
  ip->nlink = 1;
    80005250:	4785                	li	a5,1
    80005252:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005256:	8526                	mv	a0,s1
    80005258:	cb8fe0ef          	jal	80003710 <iupdate>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    8000525c:	40d0                	lw	a2,4(s1)
    8000525e:	00003597          	auipc	a1,0x3
    80005262:	53a58593          	addi	a1,a1,1338 # 80008798 <etext+0x798>
    80005266:	8526                	mv	a0,s1
    80005268:	d39fe0ef          	jal	80003fa0 <dirlink>
    8000526c:	f60541e3          	bltz	a0,800051ce <create+0xc0>
    80005270:	004aa603          	lw	a2,4(s5)
    80005274:	00003597          	auipc	a1,0x3
    80005278:	51c58593          	addi	a1,a1,1308 # 80008790 <etext+0x790>
    8000527c:	8526                	mv	a0,s1
    8000527e:	d23fe0ef          	jal	80003fa0 <dirlink>
    80005282:	f40546e3          	bltz	a0,800051ce <create+0xc0>
  if (dirlink(dp, name, ip->inum) < 0)
    80005286:	40d0                	lw	a2,4(s1)
    80005288:	fb040593          	addi	a1,s0,-80
    8000528c:	8556                	mv	a0,s5
    8000528e:	d13fe0ef          	jal	80003fa0 <dirlink>
    80005292:	f2054ee3          	bltz	a0,800051ce <create+0xc0>
    dp->nlink++; // for ".."
    80005296:	04aad783          	lhu	a5,74(s5)
    8000529a:	2785                	addiw	a5,a5,1
    8000529c:	04fa9523          	sh	a5,74(s5)
    iupdate(dp);
    800052a0:	8556                	mv	a0,s5
    800052a2:	c6efe0ef          	jal	80003710 <iupdate>
    800052a6:	bf51                	j	8000523a <create+0x12c>

00000000800052a8 <sys_dup>:
{
    800052a8:	7179                	addi	sp,sp,-48
    800052aa:	f406                	sd	ra,40(sp)
    800052ac:	f022                	sd	s0,32(sp)
    800052ae:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    800052b0:	fd840613          	addi	a2,s0,-40
    800052b4:	4581                	li	a1,0
    800052b6:	4501                	li	a0,0
    800052b8:	dc1ff0ef          	jal	80005078 <argfd>
    return -1;
    800052bc:	57fd                	li	a5,-1
  if (argfd(0, 0, &f) < 0)
    800052be:	02054363          	bltz	a0,800052e4 <sys_dup+0x3c>
    800052c2:	ec26                	sd	s1,24(sp)
    800052c4:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    800052c6:	fd843903          	ld	s2,-40(s0)
    800052ca:	854a                	mv	a0,s2
    800052cc:	e05ff0ef          	jal	800050d0 <fdalloc>
    800052d0:	84aa                	mv	s1,a0
    return -1;
    800052d2:	57fd                	li	a5,-1
  if ((fd = fdalloc(f)) < 0)
    800052d4:	00054d63          	bltz	a0,800052ee <sys_dup+0x46>
  filedup(f);
    800052d8:	854a                	mv	a0,s2
    800052da:	b9aff0ef          	jal	80004674 <filedup>
  return fd;
    800052de:	87a6                	mv	a5,s1
    800052e0:	64e2                	ld	s1,24(sp)
    800052e2:	6942                	ld	s2,16(sp)
}
    800052e4:	853e                	mv	a0,a5
    800052e6:	70a2                	ld	ra,40(sp)
    800052e8:	7402                	ld	s0,32(sp)
    800052ea:	6145                	addi	sp,sp,48
    800052ec:	8082                	ret
    800052ee:	64e2                	ld	s1,24(sp)
    800052f0:	6942                	ld	s2,16(sp)
    800052f2:	bfcd                	j	800052e4 <sys_dup+0x3c>

00000000800052f4 <sys_read>:
{
    800052f4:	7179                	addi	sp,sp,-48
    800052f6:	f406                	sd	ra,40(sp)
    800052f8:	f022                	sd	s0,32(sp)
    800052fa:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800052fc:	fd840593          	addi	a1,s0,-40
    80005300:	4505                	li	a0,1
    80005302:	cf6fd0ef          	jal	800027f8 <argaddr>
  argint(2, &n);
    80005306:	fe440593          	addi	a1,s0,-28
    8000530a:	4509                	li	a0,2
    8000530c:	cd0fd0ef          	jal	800027dc <argint>
  if (argfd(0, 0, &f) < 0)
    80005310:	fe840613          	addi	a2,s0,-24
    80005314:	4581                	li	a1,0
    80005316:	4501                	li	a0,0
    80005318:	d61ff0ef          	jal	80005078 <argfd>
    8000531c:	87aa                	mv	a5,a0
    return -1;
    8000531e:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80005320:	0007ca63          	bltz	a5,80005334 <sys_read+0x40>
  return fileread(f, p, n);
    80005324:	fe442603          	lw	a2,-28(s0)
    80005328:	fd843583          	ld	a1,-40(s0)
    8000532c:	fe843503          	ld	a0,-24(s0)
    80005330:	caeff0ef          	jal	800047de <fileread>
}
    80005334:	70a2                	ld	ra,40(sp)
    80005336:	7402                	ld	s0,32(sp)
    80005338:	6145                	addi	sp,sp,48
    8000533a:	8082                	ret

000000008000533c <sys_write>:
{
    8000533c:	7179                	addi	sp,sp,-48
    8000533e:	f406                	sd	ra,40(sp)
    80005340:	f022                	sd	s0,32(sp)
    80005342:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005344:	fd840593          	addi	a1,s0,-40
    80005348:	4505                	li	a0,1
    8000534a:	caefd0ef          	jal	800027f8 <argaddr>
  argint(2, &n);
    8000534e:	fe440593          	addi	a1,s0,-28
    80005352:	4509                	li	a0,2
    80005354:	c88fd0ef          	jal	800027dc <argint>
  if (argfd(0, 0, &f) < 0)
    80005358:	fe840613          	addi	a2,s0,-24
    8000535c:	4581                	li	a1,0
    8000535e:	4501                	li	a0,0
    80005360:	d19ff0ef          	jal	80005078 <argfd>
    80005364:	87aa                	mv	a5,a0
    return -1;
    80005366:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    80005368:	0007ca63          	bltz	a5,8000537c <sys_write+0x40>
  return filewrite(f, p, n);
    8000536c:	fe442603          	lw	a2,-28(s0)
    80005370:	fd843583          	ld	a1,-40(s0)
    80005374:	fe843503          	ld	a0,-24(s0)
    80005378:	d30ff0ef          	jal	800048a8 <filewrite>
}
    8000537c:	70a2                	ld	ra,40(sp)
    8000537e:	7402                	ld	s0,32(sp)
    80005380:	6145                	addi	sp,sp,48
    80005382:	8082                	ret

0000000080005384 <sys_close>:
{
    80005384:	1101                	addi	sp,sp,-32
    80005386:	ec06                	sd	ra,24(sp)
    80005388:	e822                	sd	s0,16(sp)
    8000538a:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    8000538c:	fe040613          	addi	a2,s0,-32
    80005390:	fec40593          	addi	a1,s0,-20
    80005394:	4501                	li	a0,0
    80005396:	ce3ff0ef          	jal	80005078 <argfd>
    return -1;
    8000539a:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    8000539c:	02054063          	bltz	a0,800053bc <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    800053a0:	d02fc0ef          	jal	800018a2 <myproc>
    800053a4:	fec42783          	lw	a5,-20(s0)
    800053a8:	07e9                	addi	a5,a5,26
    800053aa:	078e                	slli	a5,a5,0x3
    800053ac:	953e                	add	a0,a0,a5
    800053ae:	00053023          	sd	zero,0(a0)
  fileclose(f);
    800053b2:	fe043503          	ld	a0,-32(s0)
    800053b6:	b04ff0ef          	jal	800046ba <fileclose>
  return 0;
    800053ba:	4781                	li	a5,0
}
    800053bc:	853e                	mv	a0,a5
    800053be:	60e2                	ld	ra,24(sp)
    800053c0:	6442                	ld	s0,16(sp)
    800053c2:	6105                	addi	sp,sp,32
    800053c4:	8082                	ret

00000000800053c6 <sys_fstat>:
{
    800053c6:	1101                	addi	sp,sp,-32
    800053c8:	ec06                	sd	ra,24(sp)
    800053ca:	e822                	sd	s0,16(sp)
    800053cc:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    800053ce:	fe040593          	addi	a1,s0,-32
    800053d2:	4505                	li	a0,1
    800053d4:	c24fd0ef          	jal	800027f8 <argaddr>
  if (argfd(0, 0, &f) < 0)
    800053d8:	fe840613          	addi	a2,s0,-24
    800053dc:	4581                	li	a1,0
    800053de:	4501                	li	a0,0
    800053e0:	c99ff0ef          	jal	80005078 <argfd>
    800053e4:	87aa                	mv	a5,a0
    return -1;
    800053e6:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    800053e8:	0007c863          	bltz	a5,800053f8 <sys_fstat+0x32>
  return filestat(f, st);
    800053ec:	fe043583          	ld	a1,-32(s0)
    800053f0:	fe843503          	ld	a0,-24(s0)
    800053f4:	b88ff0ef          	jal	8000477c <filestat>
}
    800053f8:	60e2                	ld	ra,24(sp)
    800053fa:	6442                	ld	s0,16(sp)
    800053fc:	6105                	addi	sp,sp,32
    800053fe:	8082                	ret

0000000080005400 <sys_link>:
{
    80005400:	7169                	addi	sp,sp,-304
    80005402:	f606                	sd	ra,296(sp)
    80005404:	f222                	sd	s0,288(sp)
    80005406:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005408:	08000613          	li	a2,128
    8000540c:	ed040593          	addi	a1,s0,-304
    80005410:	4501                	li	a0,0
    80005412:	c02fd0ef          	jal	80002814 <argstr>
    return -1;
    80005416:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80005418:	10054163          	bltz	a0,8000551a <sys_link+0x11a>
    8000541c:	08000613          	li	a2,128
    80005420:	f5040593          	addi	a1,s0,-176
    80005424:	4505                	li	a0,1
    80005426:	beefd0ef          	jal	80002814 <argstr>
    return -1;
    8000542a:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000542c:	0e054763          	bltz	a0,8000551a <sys_link+0x11a>
    80005430:	ee26                	sd	s1,280(sp)
  begin_op();
    80005432:	dddfe0ef          	jal	8000420e <begin_op>
  if ((ip = namei(old)) == 0) {
    80005436:	ed040513          	addi	a0,s0,-304
    8000543a:	c01fe0ef          	jal	8000403a <namei>
    8000543e:	84aa                	mv	s1,a0
    80005440:	cd35                	beqz	a0,800054bc <sys_link+0xbc>
  ilock(ip);
    80005442:	b82fe0ef          	jal	800037c4 <ilock>
  if (ip->type == T_DIR) {
    80005446:	04449703          	lh	a4,68(s1)
    8000544a:	4785                	li	a5,1
    8000544c:	06f70d63          	beq	a4,a5,800054c6 <sys_link+0xc6>
  if (ip->nlink >= NLINK_MAX) {
    80005450:	04a49783          	lh	a5,74(s1)
    80005454:	6721                	lui	a4,0x8
    80005456:	177d                	addi	a4,a4,-1 # 7fff <_entry-0x7fff8001>
    80005458:	06e78f63          	beq	a5,a4,800054d6 <sys_link+0xd6>
    8000545c:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    8000545e:	2785                	addiw	a5,a5,1
    80005460:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005464:	8526                	mv	a0,s1
    80005466:	aaafe0ef          	jal	80003710 <iupdate>
  iunlock(ip);
    8000546a:	8526                	mv	a0,s1
    8000546c:	c06fe0ef          	jal	80003872 <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    80005470:	fd040593          	addi	a1,s0,-48
    80005474:	f5040513          	addi	a0,s0,-176
    80005478:	bddfe0ef          	jal	80004054 <nameiparent>
    8000547c:	892a                	mv	s2,a0
    8000547e:	c93d                	beqz	a0,800054f4 <sys_link+0xf4>
  ilock(dp);
    80005480:	b44fe0ef          	jal	800037c4 <ilock>
  if (dp->nlink == 0) {
    80005484:	04a91783          	lh	a5,74(s2)
    80005488:	cfb9                	beqz	a5,800054e6 <sys_link+0xe6>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    8000548a:	00092703          	lw	a4,0(s2)
    8000548e:	409c                	lw	a5,0(s1)
    80005490:	04f71f63          	bne	a4,a5,800054ee <sys_link+0xee>
    80005494:	40d0                	lw	a2,4(s1)
    80005496:	fd040593          	addi	a1,s0,-48
    8000549a:	854a                	mv	a0,s2
    8000549c:	b05fe0ef          	jal	80003fa0 <dirlink>
    800054a0:	04054763          	bltz	a0,800054ee <sys_link+0xee>
  iunlockput(dp);
    800054a4:	854a                	mv	a0,s2
    800054a6:	d70fe0ef          	jal	80003a16 <iunlockput>
  iput(ip);
    800054aa:	8526                	mv	a0,s1
    800054ac:	c9afe0ef          	jal	80003946 <iput>
  end_op();
    800054b0:	de5fe0ef          	jal	80004294 <end_op>
  return 0;
    800054b4:	4781                	li	a5,0
    800054b6:	64f2                	ld	s1,280(sp)
    800054b8:	6952                	ld	s2,272(sp)
    800054ba:	a085                	j	8000551a <sys_link+0x11a>
    end_op();
    800054bc:	dd9fe0ef          	jal	80004294 <end_op>
    return -1;
    800054c0:	57fd                	li	a5,-1
    800054c2:	64f2                	ld	s1,280(sp)
    800054c4:	a899                	j	8000551a <sys_link+0x11a>
    iunlockput(ip);
    800054c6:	8526                	mv	a0,s1
    800054c8:	d4efe0ef          	jal	80003a16 <iunlockput>
    end_op();
    800054cc:	dc9fe0ef          	jal	80004294 <end_op>
    return -1;
    800054d0:	57fd                	li	a5,-1
    800054d2:	64f2                	ld	s1,280(sp)
    800054d4:	a099                	j	8000551a <sys_link+0x11a>
    iunlockput(ip);
    800054d6:	8526                	mv	a0,s1
    800054d8:	d3efe0ef          	jal	80003a16 <iunlockput>
    end_op();
    800054dc:	db9fe0ef          	jal	80004294 <end_op>
    return -1;
    800054e0:	57fd                	li	a5,-1
    800054e2:	64f2                	ld	s1,280(sp)
    800054e4:	a81d                	j	8000551a <sys_link+0x11a>
    iunlockput(dp);
    800054e6:	854a                	mv	a0,s2
    800054e8:	d2efe0ef          	jal	80003a16 <iunlockput>
    goto bad;
    800054ec:	a021                	j	800054f4 <sys_link+0xf4>
    iunlockput(dp);
    800054ee:	854a                	mv	a0,s2
    800054f0:	d26fe0ef          	jal	80003a16 <iunlockput>
  ilock(ip);
    800054f4:	8526                	mv	a0,s1
    800054f6:	acefe0ef          	jal	800037c4 <ilock>
  ip->nlink--;
    800054fa:	04a4d783          	lhu	a5,74(s1)
    800054fe:	37fd                	addiw	a5,a5,-1
    80005500:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005504:	8526                	mv	a0,s1
    80005506:	a0afe0ef          	jal	80003710 <iupdate>
  iunlockput(ip);
    8000550a:	8526                	mv	a0,s1
    8000550c:	d0afe0ef          	jal	80003a16 <iunlockput>
  end_op();
    80005510:	d85fe0ef          	jal	80004294 <end_op>
  return -1;
    80005514:	57fd                	li	a5,-1
    80005516:	64f2                	ld	s1,280(sp)
    80005518:	6952                	ld	s2,272(sp)
}
    8000551a:	853e                	mv	a0,a5
    8000551c:	70b2                	ld	ra,296(sp)
    8000551e:	7412                	ld	s0,288(sp)
    80005520:	6155                	addi	sp,sp,304
    80005522:	8082                	ret

0000000080005524 <sys_unlink>:
{
    80005524:	7151                	addi	sp,sp,-240
    80005526:	f586                	sd	ra,232(sp)
    80005528:	f1a2                	sd	s0,224(sp)
    8000552a:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    8000552c:	08000613          	li	a2,128
    80005530:	f3040593          	addi	a1,s0,-208
    80005534:	4501                	li	a0,0
    80005536:	adefd0ef          	jal	80002814 <argstr>
    8000553a:	16054063          	bltz	a0,8000569a <sys_unlink+0x176>
    8000553e:	eda6                	sd	s1,216(sp)
  begin_op();
    80005540:	ccffe0ef          	jal	8000420e <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    80005544:	fb040593          	addi	a1,s0,-80
    80005548:	f3040513          	addi	a0,s0,-208
    8000554c:	b09fe0ef          	jal	80004054 <nameiparent>
    80005550:	84aa                	mv	s1,a0
    80005552:	c945                	beqz	a0,80005602 <sys_unlink+0xde>
  ilock(dp);
    80005554:	a70fe0ef          	jal	800037c4 <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005558:	00003597          	auipc	a1,0x3
    8000555c:	24058593          	addi	a1,a1,576 # 80008798 <etext+0x798>
    80005560:	fb040513          	addi	a0,s0,-80
    80005564:	849fe0ef          	jal	80003dac <namecmp>
    80005568:	10050e63          	beqz	a0,80005684 <sys_unlink+0x160>
    8000556c:	00003597          	auipc	a1,0x3
    80005570:	22458593          	addi	a1,a1,548 # 80008790 <etext+0x790>
    80005574:	fb040513          	addi	a0,s0,-80
    80005578:	835fe0ef          	jal	80003dac <namecmp>
    8000557c:	10050463          	beqz	a0,80005684 <sys_unlink+0x160>
    80005580:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    80005582:	f2c40613          	addi	a2,s0,-212
    80005586:	fb040593          	addi	a1,s0,-80
    8000558a:	8526                	mv	a0,s1
    8000558c:	837fe0ef          	jal	80003dc2 <dirlookup>
    80005590:	892a                	mv	s2,a0
    80005592:	0e050863          	beqz	a0,80005682 <sys_unlink+0x15e>
  ilock(ip);
    80005596:	a2efe0ef          	jal	800037c4 <ilock>
  if (ip->nlink < 1)
    8000559a:	04a91783          	lh	a5,74(s2)
    8000559e:	06f05763          	blez	a5,8000560c <sys_unlink+0xe8>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    800055a2:	04491703          	lh	a4,68(s2)
    800055a6:	4785                	li	a5,1
    800055a8:	06f70963          	beq	a4,a5,8000561a <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    800055ac:	4641                	li	a2,16
    800055ae:	4581                	li	a1,0
    800055b0:	fc040513          	addi	a0,s0,-64
    800055b4:	ea0fb0ef          	jal	80000c54 <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800055b8:	4741                	li	a4,16
    800055ba:	f2c42683          	lw	a3,-212(s0)
    800055be:	fc040613          	addi	a2,s0,-64
    800055c2:	4581                	li	a1,0
    800055c4:	8526                	mv	a0,s1
    800055c6:	ed2fe0ef          	jal	80003c98 <writei>
    800055ca:	47c1                	li	a5,16
    800055cc:	08f51b63          	bne	a0,a5,80005662 <sys_unlink+0x13e>
  if (ip->type == T_DIR) {
    800055d0:	04491703          	lh	a4,68(s2)
    800055d4:	4785                	li	a5,1
    800055d6:	08f70d63          	beq	a4,a5,80005670 <sys_unlink+0x14c>
  iunlockput(dp);
    800055da:	8526                	mv	a0,s1
    800055dc:	c3afe0ef          	jal	80003a16 <iunlockput>
  ip->nlink--;
    800055e0:	04a95783          	lhu	a5,74(s2)
    800055e4:	37fd                	addiw	a5,a5,-1
    800055e6:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    800055ea:	854a                	mv	a0,s2
    800055ec:	924fe0ef          	jal	80003710 <iupdate>
  iunlockput(ip);
    800055f0:	854a                	mv	a0,s2
    800055f2:	c24fe0ef          	jal	80003a16 <iunlockput>
  end_op();
    800055f6:	c9ffe0ef          	jal	80004294 <end_op>
  return 0;
    800055fa:	4501                	li	a0,0
    800055fc:	64ee                	ld	s1,216(sp)
    800055fe:	694e                	ld	s2,208(sp)
    80005600:	a849                	j	80005692 <sys_unlink+0x16e>
    end_op();
    80005602:	c93fe0ef          	jal	80004294 <end_op>
    return -1;
    80005606:	557d                	li	a0,-1
    80005608:	64ee                	ld	s1,216(sp)
    8000560a:	a061                	j	80005692 <sys_unlink+0x16e>
    8000560c:	e5ce                	sd	s3,200(sp)
    panic("unlink: nlink < 1");
    8000560e:	00003517          	auipc	a0,0x3
    80005612:	19250513          	addi	a0,a0,402 # 800087a0 <etext+0x7a0>
    80005616:	9dafb0ef          	jal	800007f0 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    8000561a:	04c92703          	lw	a4,76(s2)
    8000561e:	02000793          	li	a5,32
    80005622:	f8e7f5e3          	bgeu	a5,a4,800055ac <sys_unlink+0x88>
    80005626:	e5ce                	sd	s3,200(sp)
    80005628:	02000993          	li	s3,32
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000562c:	4741                	li	a4,16
    8000562e:	86ce                	mv	a3,s3
    80005630:	f1840613          	addi	a2,s0,-232
    80005634:	4581                	li	a1,0
    80005636:	854a                	mv	a0,s2
    80005638:	d64fe0ef          	jal	80003b9c <readi>
    8000563c:	47c1                	li	a5,16
    8000563e:	00f51c63          	bne	a0,a5,80005656 <sys_unlink+0x132>
    if (de.inum != 0)
    80005642:	f1845783          	lhu	a5,-232(s0)
    80005646:	efa1                	bnez	a5,8000569e <sys_unlink+0x17a>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    80005648:	29c1                	addiw	s3,s3,16
    8000564a:	04c92783          	lw	a5,76(s2)
    8000564e:	fcf9efe3          	bltu	s3,a5,8000562c <sys_unlink+0x108>
    80005652:	69ae                	ld	s3,200(sp)
    80005654:	bfa1                	j	800055ac <sys_unlink+0x88>
      panic("isdirempty: readi");
    80005656:	00003517          	auipc	a0,0x3
    8000565a:	16250513          	addi	a0,a0,354 # 800087b8 <etext+0x7b8>
    8000565e:	992fb0ef          	jal	800007f0 <panic>
    80005662:	e5ce                	sd	s3,200(sp)
    panic("unlink: writei");
    80005664:	00003517          	auipc	a0,0x3
    80005668:	16c50513          	addi	a0,a0,364 # 800087d0 <etext+0x7d0>
    8000566c:	984fb0ef          	jal	800007f0 <panic>
    dp->nlink--;
    80005670:	04a4d783          	lhu	a5,74(s1)
    80005674:	37fd                	addiw	a5,a5,-1
    80005676:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    8000567a:	8526                	mv	a0,s1
    8000567c:	894fe0ef          	jal	80003710 <iupdate>
    80005680:	bfa9                	j	800055da <sys_unlink+0xb6>
    80005682:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80005684:	8526                	mv	a0,s1
    80005686:	b90fe0ef          	jal	80003a16 <iunlockput>
  end_op();
    8000568a:	c0bfe0ef          	jal	80004294 <end_op>
  return -1;
    8000568e:	557d                	li	a0,-1
    80005690:	64ee                	ld	s1,216(sp)
}
    80005692:	70ae                	ld	ra,232(sp)
    80005694:	740e                	ld	s0,224(sp)
    80005696:	616d                	addi	sp,sp,240
    80005698:	8082                	ret
    return -1;
    8000569a:	557d                	li	a0,-1
    8000569c:	bfdd                	j	80005692 <sys_unlink+0x16e>
    iunlockput(ip);
    8000569e:	854a                	mv	a0,s2
    800056a0:	b76fe0ef          	jal	80003a16 <iunlockput>
    goto bad;
    800056a4:	694e                	ld	s2,208(sp)
    800056a6:	69ae                	ld	s3,200(sp)
    800056a8:	bff1                	j	80005684 <sys_unlink+0x160>

00000000800056aa <sys_open>:

uint64
sys_open(void)
{
    800056aa:	7131                	addi	sp,sp,-192
    800056ac:	fd06                	sd	ra,184(sp)
    800056ae:	f922                	sd	s0,176(sp)
    800056b0:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800056b2:	f4c40593          	addi	a1,s0,-180
    800056b6:	4505                	li	a0,1
    800056b8:	924fd0ef          	jal	800027dc <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    800056bc:	08000613          	li	a2,128
    800056c0:	f5040593          	addi	a1,s0,-176
    800056c4:	4501                	li	a0,0
    800056c6:	94efd0ef          	jal	80002814 <argstr>
    800056ca:	87aa                	mv	a5,a0
    return -1;
    800056cc:	557d                	li	a0,-1
  if ((n = argstr(0, path, MAXPATH)) < 0)
    800056ce:	0a07c263          	bltz	a5,80005772 <sys_open+0xc8>
    800056d2:	f526                	sd	s1,168(sp)

  begin_op();
    800056d4:	b3bfe0ef          	jal	8000420e <begin_op>

  if (omode & O_CREATE) {
    800056d8:	f4c42783          	lw	a5,-180(s0)
    800056dc:	2007f793          	andi	a5,a5,512
    800056e0:	c3d5                	beqz	a5,80005784 <sys_open+0xda>
    ip = create(path, T_FILE, 0, 0);
    800056e2:	4681                	li	a3,0
    800056e4:	4601                	li	a2,0
    800056e6:	4589                	li	a1,2
    800056e8:	f5040513          	addi	a0,s0,-176
    800056ec:	a23ff0ef          	jal	8000510e <create>
    800056f0:	84aa                	mv	s1,a0
    if (ip == 0) {
    800056f2:	c541                	beqz	a0,8000577a <sys_open+0xd0>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    800056f4:	04449703          	lh	a4,68(s1)
    800056f8:	478d                	li	a5,3
    800056fa:	00f71763          	bne	a4,a5,80005708 <sys_open+0x5e>
    800056fe:	0464d703          	lhu	a4,70(s1)
    80005702:	47a5                	li	a5,9
    80005704:	0ae7ed63          	bltu	a5,a4,800057be <sys_open+0x114>
    80005708:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    8000570a:	f0dfe0ef          	jal	80004616 <filealloc>
    8000570e:	892a                	mv	s2,a0
    80005710:	c179                	beqz	a0,800057d6 <sys_open+0x12c>
    80005712:	ed4e                	sd	s3,152(sp)
    80005714:	9bdff0ef          	jal	800050d0 <fdalloc>
    80005718:	89aa                	mv	s3,a0
    8000571a:	0a054a63          	bltz	a0,800057ce <sys_open+0x124>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    8000571e:	04449703          	lh	a4,68(s1)
    80005722:	478d                	li	a5,3
    80005724:	0cf70263          	beq	a4,a5,800057e8 <sys_open+0x13e>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005728:	4789                	li	a5,2
    8000572a:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    8000572e:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80005732:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80005736:	f4c42783          	lw	a5,-180(s0)
    8000573a:	0017c713          	xori	a4,a5,1
    8000573e:	8b05                	andi	a4,a4,1
    80005740:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80005744:	0037f713          	andi	a4,a5,3
    80005748:	00e03733          	snez	a4,a4
    8000574c:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    80005750:	4007f793          	andi	a5,a5,1024
    80005754:	c791                	beqz	a5,80005760 <sys_open+0xb6>
    80005756:	04449703          	lh	a4,68(s1)
    8000575a:	4789                	li	a5,2
    8000575c:	08f70d63          	beq	a4,a5,800057f6 <sys_open+0x14c>
    itrunc(ip);
  }

  iunlock(ip);
    80005760:	8526                	mv	a0,s1
    80005762:	910fe0ef          	jal	80003872 <iunlock>
  end_op();
    80005766:	b2ffe0ef          	jal	80004294 <end_op>

  return fd;
    8000576a:	854e                	mv	a0,s3
    8000576c:	74aa                	ld	s1,168(sp)
    8000576e:	790a                	ld	s2,160(sp)
    80005770:	69ea                	ld	s3,152(sp)
}
    80005772:	70ea                	ld	ra,184(sp)
    80005774:	744a                	ld	s0,176(sp)
    80005776:	6129                	addi	sp,sp,192
    80005778:	8082                	ret
      end_op();
    8000577a:	b1bfe0ef          	jal	80004294 <end_op>
      return -1;
    8000577e:	557d                	li	a0,-1
    80005780:	74aa                	ld	s1,168(sp)
    80005782:	bfc5                	j	80005772 <sys_open+0xc8>
    if ((ip = namei(path)) == 0) {
    80005784:	f5040513          	addi	a0,s0,-176
    80005788:	8b3fe0ef          	jal	8000403a <namei>
    8000578c:	84aa                	mv	s1,a0
    8000578e:	c11d                	beqz	a0,800057b4 <sys_open+0x10a>
    ilock(ip);
    80005790:	834fe0ef          	jal	800037c4 <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    80005794:	04449703          	lh	a4,68(s1)
    80005798:	4785                	li	a5,1
    8000579a:	f4f71de3          	bne	a4,a5,800056f4 <sys_open+0x4a>
    8000579e:	f4c42783          	lw	a5,-180(s0)
    800057a2:	d3bd                	beqz	a5,80005708 <sys_open+0x5e>
      iunlockput(ip);
    800057a4:	8526                	mv	a0,s1
    800057a6:	a70fe0ef          	jal	80003a16 <iunlockput>
      end_op();
    800057aa:	aebfe0ef          	jal	80004294 <end_op>
      return -1;
    800057ae:	557d                	li	a0,-1
    800057b0:	74aa                	ld	s1,168(sp)
    800057b2:	b7c1                	j	80005772 <sys_open+0xc8>
      end_op();
    800057b4:	ae1fe0ef          	jal	80004294 <end_op>
      return -1;
    800057b8:	557d                	li	a0,-1
    800057ba:	74aa                	ld	s1,168(sp)
    800057bc:	bf5d                	j	80005772 <sys_open+0xc8>
    iunlockput(ip);
    800057be:	8526                	mv	a0,s1
    800057c0:	a56fe0ef          	jal	80003a16 <iunlockput>
    end_op();
    800057c4:	ad1fe0ef          	jal	80004294 <end_op>
    return -1;
    800057c8:	557d                	li	a0,-1
    800057ca:	74aa                	ld	s1,168(sp)
    800057cc:	b75d                	j	80005772 <sys_open+0xc8>
      fileclose(f);
    800057ce:	854a                	mv	a0,s2
    800057d0:	eebfe0ef          	jal	800046ba <fileclose>
    800057d4:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    800057d6:	8526                	mv	a0,s1
    800057d8:	a3efe0ef          	jal	80003a16 <iunlockput>
    end_op();
    800057dc:	ab9fe0ef          	jal	80004294 <end_op>
    return -1;
    800057e0:	557d                	li	a0,-1
    800057e2:	74aa                	ld	s1,168(sp)
    800057e4:	790a                	ld	s2,160(sp)
    800057e6:	b771                	j	80005772 <sys_open+0xc8>
    f->type = FD_DEVICE;
    800057e8:	00f92023          	sw	a5,0(s2)
    f->major = ip->major;
    800057ec:	04649783          	lh	a5,70(s1)
    800057f0:	02f91223          	sh	a5,36(s2)
    800057f4:	bf3d                	j	80005732 <sys_open+0x88>
    itrunc(ip);
    800057f6:	8526                	mv	a0,s1
    800057f8:	8bafe0ef          	jal	800038b2 <itrunc>
    800057fc:	b795                	j	80005760 <sys_open+0xb6>

00000000800057fe <sys_mkdir>:

uint64
sys_mkdir(void)
{
    800057fe:	7175                	addi	sp,sp,-144
    80005800:	e506                	sd	ra,136(sp)
    80005802:	e122                	sd	s0,128(sp)
    80005804:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005806:	a09fe0ef          	jal	8000420e <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    8000580a:	08000613          	li	a2,128
    8000580e:	f7040593          	addi	a1,s0,-144
    80005812:	4501                	li	a0,0
    80005814:	800fd0ef          	jal	80002814 <argstr>
    80005818:	02054363          	bltz	a0,8000583e <sys_mkdir+0x40>
    8000581c:	4681                	li	a3,0
    8000581e:	4601                	li	a2,0
    80005820:	4585                	li	a1,1
    80005822:	f7040513          	addi	a0,s0,-144
    80005826:	8e9ff0ef          	jal	8000510e <create>
    8000582a:	c911                	beqz	a0,8000583e <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000582c:	9eafe0ef          	jal	80003a16 <iunlockput>
  end_op();
    80005830:	a65fe0ef          	jal	80004294 <end_op>
  return 0;
    80005834:	4501                	li	a0,0
}
    80005836:	60aa                	ld	ra,136(sp)
    80005838:	640a                	ld	s0,128(sp)
    8000583a:	6149                	addi	sp,sp,144
    8000583c:	8082                	ret
    end_op();
    8000583e:	a57fe0ef          	jal	80004294 <end_op>
    return -1;
    80005842:	557d                	li	a0,-1
    80005844:	bfcd                	j	80005836 <sys_mkdir+0x38>

0000000080005846 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005846:	7135                	addi	sp,sp,-160
    80005848:	ed06                	sd	ra,152(sp)
    8000584a:	e922                	sd	s0,144(sp)
    8000584c:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    8000584e:	9c1fe0ef          	jal	8000420e <begin_op>
  argint(1, &major);
    80005852:	f6c40593          	addi	a1,s0,-148
    80005856:	4505                	li	a0,1
    80005858:	f85fc0ef          	jal	800027dc <argint>
  argint(2, &minor);
    8000585c:	f6840593          	addi	a1,s0,-152
    80005860:	4509                	li	a0,2
    80005862:	f7bfc0ef          	jal	800027dc <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005866:	08000613          	li	a2,128
    8000586a:	f7040593          	addi	a1,s0,-144
    8000586e:	4501                	li	a0,0
    80005870:	fa5fc0ef          	jal	80002814 <argstr>
    80005874:	02054563          	bltz	a0,8000589e <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    80005878:	f6841683          	lh	a3,-152(s0)
    8000587c:	f6c41603          	lh	a2,-148(s0)
    80005880:	458d                	li	a1,3
    80005882:	f7040513          	addi	a0,s0,-144
    80005886:	889ff0ef          	jal	8000510e <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    8000588a:	c911                	beqz	a0,8000589e <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    8000588c:	98afe0ef          	jal	80003a16 <iunlockput>
  end_op();
    80005890:	a05fe0ef          	jal	80004294 <end_op>
  return 0;
    80005894:	4501                	li	a0,0
}
    80005896:	60ea                	ld	ra,152(sp)
    80005898:	644a                	ld	s0,144(sp)
    8000589a:	610d                	addi	sp,sp,160
    8000589c:	8082                	ret
    end_op();
    8000589e:	9f7fe0ef          	jal	80004294 <end_op>
    return -1;
    800058a2:	557d                	li	a0,-1
    800058a4:	bfcd                	j	80005896 <sys_mknod+0x50>

00000000800058a6 <sys_chdir>:

uint64
sys_chdir(void)
{
    800058a6:	7135                	addi	sp,sp,-160
    800058a8:	ed06                	sd	ra,152(sp)
    800058aa:	e922                	sd	s0,144(sp)
    800058ac:	e14a                	sd	s2,128(sp)
    800058ae:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800058b0:	ff3fb0ef          	jal	800018a2 <myproc>
    800058b4:	892a                	mv	s2,a0

  begin_op();
    800058b6:	959fe0ef          	jal	8000420e <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    800058ba:	08000613          	li	a2,128
    800058be:	f6040593          	addi	a1,s0,-160
    800058c2:	4501                	li	a0,0
    800058c4:	f51fc0ef          	jal	80002814 <argstr>
    800058c8:	04054363          	bltz	a0,8000590e <sys_chdir+0x68>
    800058cc:	e526                	sd	s1,136(sp)
    800058ce:	f6040513          	addi	a0,s0,-160
    800058d2:	f68fe0ef          	jal	8000403a <namei>
    800058d6:	84aa                	mv	s1,a0
    800058d8:	c915                	beqz	a0,8000590c <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    800058da:	eebfd0ef          	jal	800037c4 <ilock>
  if (ip->type != T_DIR) {
    800058de:	04449703          	lh	a4,68(s1)
    800058e2:	4785                	li	a5,1
    800058e4:	02f71963          	bne	a4,a5,80005916 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800058e8:	8526                	mv	a0,s1
    800058ea:	f89fd0ef          	jal	80003872 <iunlock>
  iput(p->cwd);
    800058ee:	15093503          	ld	a0,336(s2)
    800058f2:	854fe0ef          	jal	80003946 <iput>
  end_op();
    800058f6:	99ffe0ef          	jal	80004294 <end_op>
  p->cwd = ip;
    800058fa:	14993823          	sd	s1,336(s2)
  return 0;
    800058fe:	4501                	li	a0,0
    80005900:	64aa                	ld	s1,136(sp)
}
    80005902:	60ea                	ld	ra,152(sp)
    80005904:	644a                	ld	s0,144(sp)
    80005906:	690a                	ld	s2,128(sp)
    80005908:	610d                	addi	sp,sp,160
    8000590a:	8082                	ret
    8000590c:	64aa                	ld	s1,136(sp)
    end_op();
    8000590e:	987fe0ef          	jal	80004294 <end_op>
    return -1;
    80005912:	557d                	li	a0,-1
    80005914:	b7fd                	j	80005902 <sys_chdir+0x5c>
    iunlockput(ip);
    80005916:	8526                	mv	a0,s1
    80005918:	8fefe0ef          	jal	80003a16 <iunlockput>
    end_op();
    8000591c:	979fe0ef          	jal	80004294 <end_op>
    return -1;
    80005920:	557d                	li	a0,-1
    80005922:	64aa                	ld	s1,136(sp)
    80005924:	bff9                	j	80005902 <sys_chdir+0x5c>

0000000080005926 <sys_exec>:

uint64
sys_exec(void)
{
    80005926:	7121                	addi	sp,sp,-448
    80005928:	ff06                	sd	ra,440(sp)
    8000592a:	fb22                	sd	s0,432(sp)
    8000592c:	0380                	addi	s0,sp,448
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    8000592e:	e4840593          	addi	a1,s0,-440
    80005932:	4505                	li	a0,1
    80005934:	ec5fc0ef          	jal	800027f8 <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    80005938:	08000613          	li	a2,128
    8000593c:	f5040593          	addi	a1,s0,-176
    80005940:	4501                	li	a0,0
    80005942:	ed3fc0ef          	jal	80002814 <argstr>
    80005946:	87aa                	mv	a5,a0
    return -1;
    80005948:	557d                	li	a0,-1
  if (argstr(0, path, MAXPATH) < 0) {
    8000594a:	0c07c463          	bltz	a5,80005a12 <sys_exec+0xec>
    8000594e:	f726                	sd	s1,424(sp)
    80005950:	f34a                	sd	s2,416(sp)
    80005952:	ef4e                	sd	s3,408(sp)
    80005954:	eb52                	sd	s4,400(sp)
  }
  memset(argv, 0, sizeof(argv));
    80005956:	10000613          	li	a2,256
    8000595a:	4581                	li	a1,0
    8000595c:	e5040513          	addi	a0,s0,-432
    80005960:	af4fb0ef          	jal	80000c54 <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    80005964:	e5040493          	addi	s1,s0,-432
  memset(argv, 0, sizeof(argv));
    80005968:	89a6                	mv	s3,s1
    8000596a:	4901                	li	s2,0
    if (i >= NELEM(argv)) {
    8000596c:	02000a13          	li	s4,32
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    80005970:	00391513          	slli	a0,s2,0x3
    80005974:	e4040593          	addi	a1,s0,-448
    80005978:	e4843783          	ld	a5,-440(s0)
    8000597c:	953e                	add	a0,a0,a5
    8000597e:	dd3fc0ef          	jal	80002750 <fetchaddr>
    80005982:	02054663          	bltz	a0,800059ae <sys_exec+0x88>
      goto bad;
    }
    if (uarg == 0) {
    80005986:	e4043783          	ld	a5,-448(s0)
    8000598a:	c3a9                	beqz	a5,800059cc <sys_exec+0xa6>
      argv[i] = 0;
      break;
    }
    argv[i] = kalloc();
    8000598c:	93efb0ef          	jal	80000aca <kalloc>
    80005990:	85aa                	mv	a1,a0
    80005992:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    80005996:	cd01                	beqz	a0,800059ae <sys_exec+0x88>
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005998:	6605                	lui	a2,0x1
    8000599a:	e4043503          	ld	a0,-448(s0)
    8000599e:	dfdfc0ef          	jal	8000279a <fetchstr>
    800059a2:	00054663          	bltz	a0,800059ae <sys_exec+0x88>
    if (i >= NELEM(argv)) {
    800059a6:	0905                	addi	s2,s2,1
    800059a8:	09a1                	addi	s3,s3,8
    800059aa:	fd4913e3          	bne	s2,s4,80005970 <sys_exec+0x4a>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800059ae:	f5040913          	addi	s2,s0,-176
    800059b2:	6088                	ld	a0,0(s1)
    800059b4:	c931                	beqz	a0,80005a08 <sys_exec+0xe2>
    kfree(argv[i]);
    800059b6:	832fb0ef          	jal	800009e8 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800059ba:	04a1                	addi	s1,s1,8
    800059bc:	ff249be3          	bne	s1,s2,800059b2 <sys_exec+0x8c>
  return -1;
    800059c0:	557d                	li	a0,-1
    800059c2:	74ba                	ld	s1,424(sp)
    800059c4:	791a                	ld	s2,416(sp)
    800059c6:	69fa                	ld	s3,408(sp)
    800059c8:	6a5a                	ld	s4,400(sp)
    800059ca:	a0a1                	j	80005a12 <sys_exec+0xec>
      argv[i] = 0;
    800059cc:	0009079b          	sext.w	a5,s2
    800059d0:	078e                	slli	a5,a5,0x3
    800059d2:	fd078793          	addi	a5,a5,-48
    800059d6:	97a2                	add	a5,a5,s0
    800059d8:	e807b023          	sd	zero,-384(a5)
  int ret = kexec(path, argv);
    800059dc:	e5040593          	addi	a1,s0,-432
    800059e0:	f5040513          	addi	a0,s0,-176
    800059e4:	b26ff0ef          	jal	80004d0a <kexec>
    800059e8:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800059ea:	f5040993          	addi	s3,s0,-176
    800059ee:	6088                	ld	a0,0(s1)
    800059f0:	c511                	beqz	a0,800059fc <sys_exec+0xd6>
    kfree(argv[i]);
    800059f2:	ff7fa0ef          	jal	800009e8 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800059f6:	04a1                	addi	s1,s1,8
    800059f8:	ff349be3          	bne	s1,s3,800059ee <sys_exec+0xc8>
  return ret;
    800059fc:	854a                	mv	a0,s2
    800059fe:	74ba                	ld	s1,424(sp)
    80005a00:	791a                	ld	s2,416(sp)
    80005a02:	69fa                	ld	s3,408(sp)
    80005a04:	6a5a                	ld	s4,400(sp)
    80005a06:	a031                	j	80005a12 <sys_exec+0xec>
  return -1;
    80005a08:	557d                	li	a0,-1
    80005a0a:	74ba                	ld	s1,424(sp)
    80005a0c:	791a                	ld	s2,416(sp)
    80005a0e:	69fa                	ld	s3,408(sp)
    80005a10:	6a5a                	ld	s4,400(sp)
}
    80005a12:	70fa                	ld	ra,440(sp)
    80005a14:	745a                	ld	s0,432(sp)
    80005a16:	6139                	addi	sp,sp,448
    80005a18:	8082                	ret

0000000080005a1a <sys_pipe>:

uint64
sys_pipe(void)
{
    80005a1a:	7139                	addi	sp,sp,-64
    80005a1c:	fc06                	sd	ra,56(sp)
    80005a1e:	f822                	sd	s0,48(sp)
    80005a20:	f426                	sd	s1,40(sp)
    80005a22:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005a24:	e7ffb0ef          	jal	800018a2 <myproc>
    80005a28:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005a2a:	fd840593          	addi	a1,s0,-40
    80005a2e:	4501                	li	a0,0
    80005a30:	dc9fc0ef          	jal	800027f8 <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    80005a34:	fc840593          	addi	a1,s0,-56
    80005a38:	fd040513          	addi	a0,s0,-48
    80005a3c:	f9ffe0ef          	jal	800049da <pipealloc>
    return -1;
    80005a40:	57fd                	li	a5,-1
  if (pipealloc(&rf, &wf) < 0)
    80005a42:	0a054663          	bltz	a0,80005aee <sys_pipe+0xd4>
  fd0 = -1;
    80005a46:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    80005a4a:	fd043503          	ld	a0,-48(s0)
    80005a4e:	e82ff0ef          	jal	800050d0 <fdalloc>
    80005a52:	fca42223          	sw	a0,-60(s0)
    80005a56:	08054363          	bltz	a0,80005adc <sys_pipe+0xc2>
    80005a5a:	fc843503          	ld	a0,-56(s0)
    80005a5e:	e72ff0ef          	jal	800050d0 <fdalloc>
    80005a62:	fca42023          	sw	a0,-64(s0)
    80005a66:	06054263          	bltz	a0,80005aca <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80005a6a:	4711                	li	a4,4
    80005a6c:	fc440693          	addi	a3,s0,-60
    80005a70:	fd843603          	ld	a2,-40(s0)
    80005a74:	64ac                	ld	a1,72(s1)
    80005a76:	68a8                	ld	a0,80(s1)
    80005a78:	a61fb0ef          	jal	800014d8 <copyout>
    80005a7c:	00054f63          	bltz	a0,80005a9a <sys_pipe+0x80>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    80005a80:	4711                	li	a4,4
    80005a82:	fc040693          	addi	a3,s0,-64
    80005a86:	fd843603          	ld	a2,-40(s0)
    80005a8a:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005a8c:	64ac                	ld	a1,72(s1)
    80005a8e:	68a8                	ld	a0,80(s1)
    80005a90:	a49fb0ef          	jal	800014d8 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005a94:	4781                	li	a5,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80005a96:	04055c63          	bgez	a0,80005aee <sys_pipe+0xd4>
    p->ofile[fd0] = 0;
    80005a9a:	fc442783          	lw	a5,-60(s0)
    80005a9e:	07e9                	addi	a5,a5,26
    80005aa0:	078e                	slli	a5,a5,0x3
    80005aa2:	97a6                	add	a5,a5,s1
    80005aa4:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005aa8:	fc042783          	lw	a5,-64(s0)
    80005aac:	07e9                	addi	a5,a5,26
    80005aae:	078e                	slli	a5,a5,0x3
    80005ab0:	94be                	add	s1,s1,a5
    80005ab2:	0004b023          	sd	zero,0(s1)
    fileclose(rf);
    80005ab6:	fd043503          	ld	a0,-48(s0)
    80005aba:	c01fe0ef          	jal	800046ba <fileclose>
    fileclose(wf);
    80005abe:	fc843503          	ld	a0,-56(s0)
    80005ac2:	bf9fe0ef          	jal	800046ba <fileclose>
    return -1;
    80005ac6:	57fd                	li	a5,-1
    80005ac8:	a01d                	j	80005aee <sys_pipe+0xd4>
    if (fd0 >= 0)
    80005aca:	fc442783          	lw	a5,-60(s0)
    80005ace:	0007c763          	bltz	a5,80005adc <sys_pipe+0xc2>
      p->ofile[fd0] = 0;
    80005ad2:	07e9                	addi	a5,a5,26
    80005ad4:	078e                	slli	a5,a5,0x3
    80005ad6:	97a6                	add	a5,a5,s1
    80005ad8:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005adc:	fd043503          	ld	a0,-48(s0)
    80005ae0:	bdbfe0ef          	jal	800046ba <fileclose>
    fileclose(wf);
    80005ae4:	fc843503          	ld	a0,-56(s0)
    80005ae8:	bd3fe0ef          	jal	800046ba <fileclose>
    return -1;
    80005aec:	57fd                	li	a5,-1
}
    80005aee:	853e                	mv	a0,a5
    80005af0:	70e2                	ld	ra,56(sp)
    80005af2:	7442                	ld	s0,48(sp)
    80005af4:	74a2                	ld	s1,40(sp)
    80005af6:	6121                	addi	sp,sp,64
    80005af8:	8082                	ret
    80005afa:	0000                	unimp
    80005afc:	0000                	unimp
	...

0000000080005b00 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005b00:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005b02:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005b04:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005b06:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005b08:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    80005b0a:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    80005b0c:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005b0e:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005b10:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005b12:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005b14:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005b16:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005b18:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    80005b1a:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    80005b1c:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005b1e:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005b20:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005b22:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005b24:	b3dfc0ef          	jal	80002660 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    80005b28:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    80005b2a:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    80005b2c:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005b2e:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005b30:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005b32:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005b34:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005b36:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    80005b38:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    80005b3a:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    80005b3c:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005b3e:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005b40:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005b42:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005b44:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005b46:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    80005b48:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    80005b4a:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    80005b4c:	10200073          	sret
	...

0000000080005b5e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80005b5e:	1141                	addi	sp,sp,-16
    80005b60:	e422                	sd	s0,8(sp)
    80005b62:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(volatile uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    80005b64:	0c0007b7          	lui	a5,0xc000
    80005b68:	4705                	li	a4,1
    80005b6a:	d798                	sw	a4,40(a5)
  *(volatile uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    80005b6c:	0c0007b7          	lui	a5,0xc000
    80005b70:	c3d8                	sw	a4,4(a5)
}
    80005b72:	6422                	ld	s0,8(sp)
    80005b74:	0141                	addi	sp,sp,16
    80005b76:	8082                	ret

0000000080005b78 <plicinithart>:

void
plicinithart(void)
{
    80005b78:	1141                	addi	sp,sp,-16
    80005b7a:	e406                	sd	ra,8(sp)
    80005b7c:	e022                	sd	s0,0(sp)
    80005b7e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005b80:	cf7fb0ef          	jal	80001876 <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(volatile uint32 *)PLIC_SENABLE(hart) =
    80005b84:	0085179b          	slliw	a5,a0,0x8
    80005b88:	0c002737          	lui	a4,0xc002
    80005b8c:	08070713          	addi	a4,a4,128 # c002080 <_entry-0x73ffdf80>
    80005b90:	97ba                	add	a5,a5,a4
    80005b92:	40200713          	li	a4,1026
    80005b96:	c398                	sw	a4,0(a5)
    (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);

  // set this hart's S-mode priority threshold to 0.
  *(volatile uint32 *)PLIC_SPRIORITY(hart) = 0;
    80005b98:	00d5151b          	slliw	a0,a0,0xd
    80005b9c:	0c2017b7          	lui	a5,0xc201
    80005ba0:	953e                	add	a0,a0,a5
    80005ba2:	00052023          	sw	zero,0(a0)
}
    80005ba6:	60a2                	ld	ra,8(sp)
    80005ba8:	6402                	ld	s0,0(sp)
    80005baa:	0141                	addi	sp,sp,16
    80005bac:	8082                	ret

0000000080005bae <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005bae:	1141                	addi	sp,sp,-16
    80005bb0:	e406                	sd	ra,8(sp)
    80005bb2:	e022                	sd	s0,0(sp)
    80005bb4:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005bb6:	cc1fb0ef          	jal	80001876 <cpuid>
  int irq = *(volatile uint32 *)PLIC_SCLAIM(hart);
    80005bba:	00d5151b          	slliw	a0,a0,0xd
    80005bbe:	0c2017b7          	lui	a5,0xc201
    80005bc2:	0791                	addi	a5,a5,4 # c201004 <_entry-0x73dfeffc>
    80005bc4:	953e                	add	a0,a0,a5
    80005bc6:	4108                	lw	a0,0(a0)
  return irq;
}
    80005bc8:	60a2                	ld	ra,8(sp)
    80005bca:	6402                	ld	s0,0(sp)
    80005bcc:	0141                	addi	sp,sp,16
    80005bce:	8082                	ret

0000000080005bd0 <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005bd0:	1101                	addi	sp,sp,-32
    80005bd2:	ec06                	sd	ra,24(sp)
    80005bd4:	e822                	sd	s0,16(sp)
    80005bd6:	e426                	sd	s1,8(sp)
    80005bd8:	1000                	addi	s0,sp,32
    80005bda:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005bdc:	c9bfb0ef          	jal	80001876 <cpuid>
  *(volatile uint32 *)PLIC_SCLAIM(hart) = irq;
    80005be0:	00d5179b          	slliw	a5,a0,0xd
    80005be4:	0c201737          	lui	a4,0xc201
    80005be8:	0711                	addi	a4,a4,4 # c201004 <_entry-0x73dfeffc>
    80005bea:	97ba                	add	a5,a5,a4
    80005bec:	2481                	sext.w	s1,s1
    80005bee:	c384                	sw	s1,0(a5)
}
    80005bf0:	60e2                	ld	ra,24(sp)
    80005bf2:	6442                	ld	s0,16(sp)
    80005bf4:	64a2                	ld	s1,8(sp)
    80005bf6:	6105                	addi	sp,sp,32
    80005bf8:	8082                	ret

0000000080005bfa <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005bfa:	1141                	addi	sp,sp,-16
    80005bfc:	e406                	sd	ra,8(sp)
    80005bfe:	e022                	sd	s0,0(sp)
    80005c00:	0800                	addi	s0,sp,16
  if (i >= NUM)
    80005c02:	479d                	li	a5,7
    80005c04:	04a7ca63          	blt	a5,a0,80005c58 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005c08:	0001f797          	auipc	a5,0x1f
    80005c0c:	b3878793          	addi	a5,a5,-1224 # 80024740 <disk>
    80005c10:	97aa                	add	a5,a5,a0
    80005c12:	0187c783          	lbu	a5,24(a5)
    80005c16:	e7b9                	bnez	a5,80005c64 <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005c18:	00451693          	slli	a3,a0,0x4
    80005c1c:	0001f797          	auipc	a5,0x1f
    80005c20:	b2478793          	addi	a5,a5,-1244 # 80024740 <disk>
    80005c24:	6398                	ld	a4,0(a5)
    80005c26:	9736                	add	a4,a4,a3
    80005c28:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005c2c:	6398                	ld	a4,0(a5)
    80005c2e:	9736                	add	a4,a4,a3
    80005c30:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005c34:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005c38:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005c3c:	97aa                	add	a5,a5,a0
    80005c3e:	4705                	li	a4,1
    80005c40:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005c44:	0001f517          	auipc	a0,0x1f
    80005c48:	b1450513          	addi	a0,a0,-1260 # 80024758 <disk+0x18>
    80005c4c:	ac6fc0ef          	jal	80001f12 <wakeup>
}
    80005c50:	60a2                	ld	ra,8(sp)
    80005c52:	6402                	ld	s0,0(sp)
    80005c54:	0141                	addi	sp,sp,16
    80005c56:	8082                	ret
    panic("free_desc 1");
    80005c58:	00003517          	auipc	a0,0x3
    80005c5c:	b8850513          	addi	a0,a0,-1144 # 800087e0 <etext+0x7e0>
    80005c60:	b91fa0ef          	jal	800007f0 <panic>
    panic("free_desc 2");
    80005c64:	00003517          	auipc	a0,0x3
    80005c68:	b8c50513          	addi	a0,a0,-1140 # 800087f0 <etext+0x7f0>
    80005c6c:	b85fa0ef          	jal	800007f0 <panic>

0000000080005c70 <virtio_disk_init>:
{
    80005c70:	1101                	addi	sp,sp,-32
    80005c72:	ec06                	sd	ra,24(sp)
    80005c74:	e822                	sd	s0,16(sp)
    80005c76:	e426                	sd	s1,8(sp)
    80005c78:	e04a                	sd	s2,0(sp)
    80005c7a:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005c7c:	00003597          	auipc	a1,0x3
    80005c80:	b8458593          	addi	a1,a1,-1148 # 80008800 <etext+0x800>
    80005c84:	0001f517          	auipc	a0,0x1f
    80005c88:	be450513          	addi	a0,a0,-1052 # 80024868 <disk+0x128>
    80005c8c:	e8ffa0ef          	jal	80000b1a <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005c90:	100017b7          	lui	a5,0x10001
    80005c94:	4398                	lw	a4,0(a5)
    80005c96:	2701                	sext.w	a4,a4
    80005c98:	747277b7          	lui	a5,0x74727
    80005c9c:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005ca0:	18f71063          	bne	a4,a5,80005e20 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005ca4:	100017b7          	lui	a5,0x10001
    80005ca8:	0791                	addi	a5,a5,4 # 10001004 <_entry-0x6fffeffc>
    80005caa:	439c                	lw	a5,0(a5)
    80005cac:	2781                	sext.w	a5,a5
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005cae:	4709                	li	a4,2
    80005cb0:	16e79863          	bne	a5,a4,80005e20 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005cb4:	100017b7          	lui	a5,0x10001
    80005cb8:	07a1                	addi	a5,a5,8 # 10001008 <_entry-0x6fffeff8>
    80005cba:	439c                	lw	a5,0(a5)
    80005cbc:	2781                	sext.w	a5,a5
    80005cbe:	16e79163          	bne	a5,a4,80005e20 <virtio_disk_init+0x1b0>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    80005cc2:	100017b7          	lui	a5,0x10001
    80005cc6:	47d8                	lw	a4,12(a5)
    80005cc8:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005cca:	554d47b7          	lui	a5,0x554d4
    80005cce:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005cd2:	14f71763          	bne	a4,a5,80005e20 <virtio_disk_init+0x1b0>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005cd6:	100017b7          	lui	a5,0x10001
    80005cda:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005cde:	4705                	li	a4,1
    80005ce0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005ce2:	470d                	li	a4,3
    80005ce4:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005ce6:	10001737          	lui	a4,0x10001
    80005cea:	4b14                	lw	a3,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005cec:	c7ffe737          	lui	a4,0xc7ffe
    80005cf0:	55f70713          	addi	a4,a4,1375 # ffffffffc7ffe55f <end+0xffffffff47fd9cdf>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005cf4:	8ef9                	and	a3,a3,a4
    80005cf6:	10001737          	lui	a4,0x10001
    80005cfa:	d314                	sw	a3,32(a4)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005cfc:	472d                	li	a4,11
    80005cfe:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005d00:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005d04:	439c                	lw	a5,0(a5)
    80005d06:	0007891b          	sext.w	s2,a5
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005d0a:	8ba1                	andi	a5,a5,8
    80005d0c:	12078063          	beqz	a5,80005e2c <virtio_disk_init+0x1bc>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005d10:	100017b7          	lui	a5,0x10001
    80005d14:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005d18:	100017b7          	lui	a5,0x10001
    80005d1c:	04478793          	addi	a5,a5,68 # 10001044 <_entry-0x6fffefbc>
    80005d20:	439c                	lw	a5,0(a5)
    80005d22:	2781                	sext.w	a5,a5
    80005d24:	10079a63          	bnez	a5,80005e38 <virtio_disk_init+0x1c8>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005d28:	100017b7          	lui	a5,0x10001
    80005d2c:	03478793          	addi	a5,a5,52 # 10001034 <_entry-0x6fffefcc>
    80005d30:	439c                	lw	a5,0(a5)
    80005d32:	2781                	sext.w	a5,a5
  if (max == 0)
    80005d34:	10078863          	beqz	a5,80005e44 <virtio_disk_init+0x1d4>
  if (max < NUM)
    80005d38:	471d                	li	a4,7
    80005d3a:	10f77b63          	bgeu	a4,a5,80005e50 <virtio_disk_init+0x1e0>
  disk.desc = kalloc();
    80005d3e:	d8dfa0ef          	jal	80000aca <kalloc>
    80005d42:	0001f497          	auipc	s1,0x1f
    80005d46:	9fe48493          	addi	s1,s1,-1538 # 80024740 <disk>
    80005d4a:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005d4c:	d7ffa0ef          	jal	80000aca <kalloc>
    80005d50:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005d52:	d79fa0ef          	jal	80000aca <kalloc>
    80005d56:	87aa                	mv	a5,a0
    80005d58:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    80005d5a:	6088                	ld	a0,0(s1)
    80005d5c:	10050063          	beqz	a0,80005e5c <virtio_disk_init+0x1ec>
    80005d60:	0001f717          	auipc	a4,0x1f
    80005d64:	9e873703          	ld	a4,-1560(a4) # 80024748 <disk+0x8>
    80005d68:	0e070a63          	beqz	a4,80005e5c <virtio_disk_init+0x1ec>
    80005d6c:	0e078863          	beqz	a5,80005e5c <virtio_disk_init+0x1ec>
  memset(disk.desc, 0, PGSIZE);
    80005d70:	6605                	lui	a2,0x1
    80005d72:	4581                	li	a1,0
    80005d74:	ee1fa0ef          	jal	80000c54 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005d78:	0001f497          	auipc	s1,0x1f
    80005d7c:	9c848493          	addi	s1,s1,-1592 # 80024740 <disk>
    80005d80:	6605                	lui	a2,0x1
    80005d82:	4581                	li	a1,0
    80005d84:	6488                	ld	a0,8(s1)
    80005d86:	ecffa0ef          	jal	80000c54 <memset>
  memset(disk.used, 0, PGSIZE);
    80005d8a:	6605                	lui	a2,0x1
    80005d8c:	4581                	li	a1,0
    80005d8e:	6888                	ld	a0,16(s1)
    80005d90:	ec5fa0ef          	jal	80000c54 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005d94:	100017b7          	lui	a5,0x10001
    80005d98:	4721                	li	a4,8
    80005d9a:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80005d9c:	4098                	lw	a4,0(s1)
    80005d9e:	100017b7          	lui	a5,0x10001
    80005da2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005da6:	40d8                	lw	a4,4(s1)
    80005da8:	100017b7          	lui	a5,0x10001
    80005dac:	08e7a223          	sw	a4,132(a5) # 10001084 <_entry-0x6fffef7c>
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005db0:	649c                	ld	a5,8(s1)
    80005db2:	0007869b          	sext.w	a3,a5
    80005db6:	10001737          	lui	a4,0x10001
    80005dba:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005dbe:	9781                	srai	a5,a5,0x20
    80005dc0:	10001737          	lui	a4,0x10001
    80005dc4:	08f72a23          	sw	a5,148(a4) # 10001094 <_entry-0x6fffef6c>
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005dc8:	689c                	ld	a5,16(s1)
    80005dca:	0007869b          	sext.w	a3,a5
    80005dce:	10001737          	lui	a4,0x10001
    80005dd2:	0ad72023          	sw	a3,160(a4) # 100010a0 <_entry-0x6fffef60>
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80005dd6:	9781                	srai	a5,a5,0x20
    80005dd8:	10001737          	lui	a4,0x10001
    80005ddc:	0af72223          	sw	a5,164(a4) # 100010a4 <_entry-0x6fffef5c>
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005de0:	10001737          	lui	a4,0x10001
    80005de4:	4785                	li	a5,1
    80005de6:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005de8:	00f48c23          	sb	a5,24(s1)
    80005dec:	00f48ca3          	sb	a5,25(s1)
    80005df0:	00f48d23          	sb	a5,26(s1)
    80005df4:	00f48da3          	sb	a5,27(s1)
    80005df8:	00f48e23          	sb	a5,28(s1)
    80005dfc:	00f48ea3          	sb	a5,29(s1)
    80005e00:	00f48f23          	sb	a5,30(s1)
    80005e04:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005e08:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005e0c:	100017b7          	lui	a5,0x10001
    80005e10:	0727a823          	sw	s2,112(a5) # 10001070 <_entry-0x6fffef90>
}
    80005e14:	60e2                	ld	ra,24(sp)
    80005e16:	6442                	ld	s0,16(sp)
    80005e18:	64a2                	ld	s1,8(sp)
    80005e1a:	6902                	ld	s2,0(sp)
    80005e1c:	6105                	addi	sp,sp,32
    80005e1e:	8082                	ret
    panic("could not find virtio disk");
    80005e20:	00003517          	auipc	a0,0x3
    80005e24:	9f050513          	addi	a0,a0,-1552 # 80008810 <etext+0x810>
    80005e28:	9c9fa0ef          	jal	800007f0 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005e2c:	00003517          	auipc	a0,0x3
    80005e30:	a0450513          	addi	a0,a0,-1532 # 80008830 <etext+0x830>
    80005e34:	9bdfa0ef          	jal	800007f0 <panic>
    panic("virtio disk should not be ready");
    80005e38:	00003517          	auipc	a0,0x3
    80005e3c:	a1850513          	addi	a0,a0,-1512 # 80008850 <etext+0x850>
    80005e40:	9b1fa0ef          	jal	800007f0 <panic>
    panic("virtio disk has no queue 0");
    80005e44:	00003517          	auipc	a0,0x3
    80005e48:	a2c50513          	addi	a0,a0,-1492 # 80008870 <etext+0x870>
    80005e4c:	9a5fa0ef          	jal	800007f0 <panic>
    panic("virtio disk max queue too short");
    80005e50:	00003517          	auipc	a0,0x3
    80005e54:	a4050513          	addi	a0,a0,-1472 # 80008890 <etext+0x890>
    80005e58:	999fa0ef          	jal	800007f0 <panic>
    panic("virtio disk kalloc");
    80005e5c:	00003517          	auipc	a0,0x3
    80005e60:	a5450513          	addi	a0,a0,-1452 # 800088b0 <etext+0x8b0>
    80005e64:	98dfa0ef          	jal	800007f0 <panic>

0000000080005e68 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005e68:	7159                	addi	sp,sp,-112
    80005e6a:	f486                	sd	ra,104(sp)
    80005e6c:	f0a2                	sd	s0,96(sp)
    80005e6e:	eca6                	sd	s1,88(sp)
    80005e70:	e8ca                	sd	s2,80(sp)
    80005e72:	e4ce                	sd	s3,72(sp)
    80005e74:	e0d2                	sd	s4,64(sp)
    80005e76:	fc56                	sd	s5,56(sp)
    80005e78:	f85a                	sd	s6,48(sp)
    80005e7a:	f45e                	sd	s7,40(sp)
    80005e7c:	f062                	sd	s8,32(sp)
    80005e7e:	ec66                	sd	s9,24(sp)
    80005e80:	1880                	addi	s0,sp,112
    80005e82:	8a2a                	mv	s4,a0
    80005e84:	8bae                	mv	s7,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    80005e86:	00c52c83          	lw	s9,12(a0)
    80005e8a:	001c9c9b          	slliw	s9,s9,0x1
    80005e8e:	1c82                	slli	s9,s9,0x20
    80005e90:	020cdc93          	srli	s9,s9,0x20

  acquire(&disk.vdisk_lock);
    80005e94:	0001f517          	auipc	a0,0x1f
    80005e98:	9d450513          	addi	a0,a0,-1580 # 80024868 <disk+0x128>
    80005e9c:	cf5fa0ef          	jal	80000b90 <acquire>
  for (int i = 0; i < 3; i++) {
    80005ea0:	4981                	li	s3,0
  for (int i = 0; i < NUM; i++) {
    80005ea2:	44a1                	li	s1,8
      disk.free[i] = 0;
    80005ea4:	0001fb17          	auipc	s6,0x1f
    80005ea8:	89cb0b13          	addi	s6,s6,-1892 # 80024740 <disk>
  for (int i = 0; i < 3; i++) {
    80005eac:	4a8d                	li	s5,3
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80005eae:	0001fc17          	auipc	s8,0x1f
    80005eb2:	8aac0c13          	addi	s8,s8,-1878 # 80024758 <disk+0x18>
    80005eb6:	a0bd                	j	80005f24 <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    80005eb8:	00fb0733          	add	a4,s6,a5
    80005ebc:	00070c23          	sb	zero,24(a4) # 10001018 <_entry-0x6fffefe8>
    idx[i] = alloc_desc();
    80005ec0:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    80005ec2:	0207c563          	bltz	a5,80005eec <virtio_disk_rw+0x84>
  for (int i = 0; i < 3; i++) {
    80005ec6:	2905                	addiw	s2,s2,1
    80005ec8:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80005eca:	07590163          	beq	s2,s5,80005f2c <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    80005ece:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    80005ed0:	0001f717          	auipc	a4,0x1f
    80005ed4:	87070713          	addi	a4,a4,-1936 # 80024740 <disk>
    80005ed8:	87ce                	mv	a5,s3
    if (disk.free[i]) {
    80005eda:	01874683          	lbu	a3,24(a4)
    80005ede:	fee9                	bnez	a3,80005eb8 <virtio_disk_rw+0x50>
  for (int i = 0; i < NUM; i++) {
    80005ee0:	2785                	addiw	a5,a5,1
    80005ee2:	0705                	addi	a4,a4,1
    80005ee4:	fe979be3          	bne	a5,s1,80005eda <virtio_disk_rw+0x72>
    idx[i] = alloc_desc();
    80005ee8:	57fd                	li	a5,-1
    80005eea:	c19c                	sw	a5,0(a1)
      for (int j = 0; j < i; j++)
    80005eec:	01205d63          	blez	s2,80005f06 <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005ef0:	f9042503          	lw	a0,-112(s0)
    80005ef4:	d07ff0ef          	jal	80005bfa <free_desc>
      for (int j = 0; j < i; j++)
    80005ef8:	4785                	li	a5,1
    80005efa:	0127d663          	bge	a5,s2,80005f06 <virtio_disk_rw+0x9e>
        free_desc(idx[j]);
    80005efe:	f9442503          	lw	a0,-108(s0)
    80005f02:	cf9ff0ef          	jal	80005bfa <free_desc>
    sleep_prepare(&disk.free[0]);
    80005f06:	8562                	mv	a0,s8
    80005f08:	f9ffb0ef          	jal	80001ea6 <sleep_prepare>
    release(&disk.vdisk_lock);
    80005f0c:	0001f917          	auipc	s2,0x1f
    80005f10:	95c90913          	addi	s2,s2,-1700 # 80024868 <disk+0x128>
    80005f14:	854a                	mv	a0,s2
    80005f16:	d07fa0ef          	jal	80000c1c <release>
    sleep();
    80005f1a:	fc9fb0ef          	jal	80001ee2 <sleep>
    acquire(&disk.vdisk_lock);
    80005f1e:	854a                	mv	a0,s2
    80005f20:	c71fa0ef          	jal	80000b90 <acquire>
  for (int i = 0; i < 3; i++) {
    80005f24:	f9040613          	addi	a2,s0,-112
    80005f28:	894e                	mv	s2,s3
    80005f2a:	b755                	j	80005ece <virtio_disk_rw+0x66>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005f2c:	f9042503          	lw	a0,-112(s0)
    80005f30:	00451693          	slli	a3,a0,0x4

  if (write)
    80005f34:	0001f797          	auipc	a5,0x1f
    80005f38:	80c78793          	addi	a5,a5,-2036 # 80024740 <disk>
    80005f3c:	00a50713          	addi	a4,a0,10
    80005f40:	0712                	slli	a4,a4,0x4
    80005f42:	973e                	add	a4,a4,a5
    80005f44:	01703633          	snez	a2,s7
    80005f48:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005f4a:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005f4e:	01973823          	sd	s9,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    80005f52:	6398                	ld	a4,0(a5)
    80005f54:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005f56:	0a868613          	addi	a2,a3,168
    80005f5a:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    80005f5c:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005f5e:	6390                	ld	a2,0(a5)
    80005f60:	00d605b3          	add	a1,a2,a3
    80005f64:	4741                	li	a4,16
    80005f66:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005f68:	4805                	li	a6,1
    80005f6a:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005f6e:	f9442703          	lw	a4,-108(s0)
    80005f72:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80005f76:	0712                	slli	a4,a4,0x4
    80005f78:	963a                	add	a2,a2,a4
    80005f7a:	058a0593          	addi	a1,s4,88
    80005f7e:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005f80:	0007b883          	ld	a7,0(a5)
    80005f84:	9746                	add	a4,a4,a7
    80005f86:	40000613          	li	a2,1024
    80005f8a:	c710                	sw	a2,8(a4)
  if (write)
    80005f8c:	001bb613          	seqz	a2,s7
    80005f90:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80005f94:	00166613          	ori	a2,a2,1
    80005f98:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005f9c:	f9842583          	lw	a1,-104(s0)
    80005fa0:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80005fa4:	00250613          	addi	a2,a0,2
    80005fa8:	0612                	slli	a2,a2,0x4
    80005faa:	963e                	add	a2,a2,a5
    80005fac:	577d                	li	a4,-1
    80005fae:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80005fb2:	0592                	slli	a1,a1,0x4
    80005fb4:	98ae                	add	a7,a7,a1
    80005fb6:	03068713          	addi	a4,a3,48
    80005fba:	973e                	add	a4,a4,a5
    80005fbc:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005fc0:	6398                	ld	a4,0(a5)
    80005fc2:	972e                	add	a4,a4,a1
    80005fc4:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005fc8:	4689                	li	a3,2
    80005fca:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005fce:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80005fd2:	010a2223          	sw	a6,4(s4)
  disk.info[idx[0]].b = b;
    80005fd6:	01463423          	sd	s4,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005fda:	6794                	ld	a3,8(a5)
    80005fdc:	0026d703          	lhu	a4,2(a3)
    80005fe0:	8b1d                	andi	a4,a4,7
    80005fe2:	0706                	slli	a4,a4,0x1
    80005fe4:	96ba                	add	a3,a3,a4
    80005fe6:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80005fea:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005fee:	6798                	ld	a4,8(a5)
    80005ff0:	00275783          	lhu	a5,2(a4)
    80005ff4:	2785                	addiw	a5,a5,1
    80005ff6:	00f71123          	sh	a5,2(a4)
    80005ffa:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005ffe:	100017b7          	lui	a5,0x10001
    80006002:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80006006:	004a2783          	lw	a5,4(s4)
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    8000600a:	0001f497          	auipc	s1,0x1f
    8000600e:	85e48493          	addi	s1,s1,-1954 # 80024868 <disk+0x128>
  while (b->disk == 1) {
    80006012:	4905                	li	s2,1
    80006014:	03079163          	bne	a5,a6,80006036 <virtio_disk_rw+0x1ce>
    sleep_prepare(b);
    80006018:	8552                	mv	a0,s4
    8000601a:	e8dfb0ef          	jal	80001ea6 <sleep_prepare>
    release(&disk.vdisk_lock);
    8000601e:	8526                	mv	a0,s1
    80006020:	bfdfa0ef          	jal	80000c1c <release>
    sleep();
    80006024:	ebffb0ef          	jal	80001ee2 <sleep>
    acquire(&disk.vdisk_lock);
    80006028:	8526                	mv	a0,s1
    8000602a:	b67fa0ef          	jal	80000b90 <acquire>
  while (b->disk == 1) {
    8000602e:	004a2783          	lw	a5,4(s4)
    80006032:	ff2783e3          	beq	a5,s2,80006018 <virtio_disk_rw+0x1b0>
  }

  disk.info[idx[0]].b = 0;
    80006036:	f9042903          	lw	s2,-112(s0)
    8000603a:	00290713          	addi	a4,s2,2
    8000603e:	0712                	slli	a4,a4,0x4
    80006040:	0001e797          	auipc	a5,0x1e
    80006044:	70078793          	addi	a5,a5,1792 # 80024740 <disk>
    80006048:	97ba                	add	a5,a5,a4
    8000604a:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    8000604e:	0001e997          	auipc	s3,0x1e
    80006052:	6f298993          	addi	s3,s3,1778 # 80024740 <disk>
    80006056:	00491713          	slli	a4,s2,0x4
    8000605a:	0009b783          	ld	a5,0(s3)
    8000605e:	97ba                	add	a5,a5,a4
    80006060:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80006064:	854a                	mv	a0,s2
    80006066:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    8000606a:	b91ff0ef          	jal	80005bfa <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    8000606e:	8885                	andi	s1,s1,1
    80006070:	f0fd                	bnez	s1,80006056 <virtio_disk_rw+0x1ee>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80006072:	0001e517          	auipc	a0,0x1e
    80006076:	7f650513          	addi	a0,a0,2038 # 80024868 <disk+0x128>
    8000607a:	ba3fa0ef          	jal	80000c1c <release>
}
    8000607e:	70a6                	ld	ra,104(sp)
    80006080:	7406                	ld	s0,96(sp)
    80006082:	64e6                	ld	s1,88(sp)
    80006084:	6946                	ld	s2,80(sp)
    80006086:	69a6                	ld	s3,72(sp)
    80006088:	6a06                	ld	s4,64(sp)
    8000608a:	7ae2                	ld	s5,56(sp)
    8000608c:	7b42                	ld	s6,48(sp)
    8000608e:	7ba2                	ld	s7,40(sp)
    80006090:	7c02                	ld	s8,32(sp)
    80006092:	6ce2                	ld	s9,24(sp)
    80006094:	6165                	addi	sp,sp,112
    80006096:	8082                	ret

0000000080006098 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80006098:	1101                	addi	sp,sp,-32
    8000609a:	ec06                	sd	ra,24(sp)
    8000609c:	e822                	sd	s0,16(sp)
    8000609e:	e426                	sd	s1,8(sp)
    800060a0:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    800060a2:	0001e497          	auipc	s1,0x1e
    800060a6:	69e48493          	addi	s1,s1,1694 # 80024740 <disk>
    800060aa:	0001e517          	auipc	a0,0x1e
    800060ae:	7be50513          	addi	a0,a0,1982 # 80024868 <disk+0x128>
    800060b2:	adffa0ef          	jal	80000b90 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800060b6:	100017b7          	lui	a5,0x10001
    800060ba:	53b8                	lw	a4,96(a5)
    800060bc:	8b0d                	andi	a4,a4,3
    800060be:	100017b7          	lui	a5,0x10001
    800060c2:	d3f8                	sw	a4,100(a5)
    800060c4:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    800060c8:	689c                	ld	a5,16(s1)
    800060ca:	0204d703          	lhu	a4,32(s1)
    800060ce:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    800060d2:	04f70663          	beq	a4,a5,8000611e <virtio_disk_intr+0x86>
    800060d6:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    800060da:	6898                	ld	a4,16(s1)
    800060dc:	0204d783          	lhu	a5,32(s1)
    800060e0:	8b9d                	andi	a5,a5,7
    800060e2:	078e                	slli	a5,a5,0x3
    800060e4:	97ba                	add	a5,a5,a4
    800060e6:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    800060e8:	00278713          	addi	a4,a5,2
    800060ec:	0712                	slli	a4,a4,0x4
    800060ee:	9726                	add	a4,a4,s1
    800060f0:	01074703          	lbu	a4,16(a4)
    800060f4:	e321                	bnez	a4,80006134 <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    800060f6:	0789                	addi	a5,a5,2
    800060f8:	0792                	slli	a5,a5,0x4
    800060fa:	97a6                	add	a5,a5,s1
    800060fc:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    800060fe:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80006102:	e11fb0ef          	jal	80001f12 <wakeup>

    disk.used_idx += 1;
    80006106:	0204d783          	lhu	a5,32(s1)
    8000610a:	2785                	addiw	a5,a5,1
    8000610c:	17c2                	slli	a5,a5,0x30
    8000610e:	93c1                	srli	a5,a5,0x30
    80006110:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    80006114:	6898                	ld	a4,16(s1)
    80006116:	00275703          	lhu	a4,2(a4)
    8000611a:	faf71ee3          	bne	a4,a5,800060d6 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    8000611e:	0001e517          	auipc	a0,0x1e
    80006122:	74a50513          	addi	a0,a0,1866 # 80024868 <disk+0x128>
    80006126:	af7fa0ef          	jal	80000c1c <release>
}
    8000612a:	60e2                	ld	ra,24(sp)
    8000612c:	6442                	ld	s0,16(sp)
    8000612e:	64a2                	ld	s1,8(sp)
    80006130:	6105                	addi	sp,sp,32
    80006132:	8082                	ret
      panic("virtio_disk_intr status");
    80006134:	00002517          	auipc	a0,0x2
    80006138:	79450513          	addi	a0,a0,1940 # 800088c8 <etext+0x8c8>
    8000613c:	eb4fa0ef          	jal	800007f0 <panic>
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	9282                	jalr	t0

000000008000709c <userret>:
    8000709c:	0000100f          	fence.i
    800070a0:	12000073          	sfence.vma
    800070a4:	18051073          	csrw	satp,a0
    800070a8:	12000073          	sfence.vma
    800070ac:	02000537          	lui	a0,0x2000
    800070b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070b2:	0536                	slli	a0,a0,0xd
    800070b4:	02853083          	ld	ra,40(a0)
    800070b8:	03053103          	ld	sp,48(a0)
    800070bc:	03853183          	ld	gp,56(a0)
    800070c0:	04053203          	ld	tp,64(a0)
    800070c4:	04853283          	ld	t0,72(a0)
    800070c8:	05053303          	ld	t1,80(a0)
    800070cc:	05853383          	ld	t2,88(a0)
    800070d0:	7120                	ld	s0,96(a0)
    800070d2:	7524                	ld	s1,104(a0)
    800070d4:	7d2c                	ld	a1,120(a0)
    800070d6:	6150                	ld	a2,128(a0)
    800070d8:	6554                	ld	a3,136(a0)
    800070da:	6958                	ld	a4,144(a0)
    800070dc:	6d5c                	ld	a5,152(a0)
    800070de:	0a053803          	ld	a6,160(a0)
    800070e2:	0a853883          	ld	a7,168(a0)
    800070e6:	0b053903          	ld	s2,176(a0)
    800070ea:	0b853983          	ld	s3,184(a0)
    800070ee:	0c053a03          	ld	s4,192(a0)
    800070f2:	0c853a83          	ld	s5,200(a0)
    800070f6:	0d053b03          	ld	s6,208(a0)
    800070fa:	0d853b83          	ld	s7,216(a0)
    800070fe:	0e053c03          	ld	s8,224(a0)
    80007102:	0e853c83          	ld	s9,232(a0)
    80007106:	0f053d03          	ld	s10,240(a0)
    8000710a:	0f853d83          	ld	s11,248(a0)
    8000710e:	10053e03          	ld	t3,256(a0)
    80007112:	10853e83          	ld	t4,264(a0)
    80007116:	11053f03          	ld	t5,272(a0)
    8000711a:	11853f83          	ld	t6,280(a0)
    8000711e:	7928                	ld	a0,112(a0)
    80007120:	10200073          	sret
	...
